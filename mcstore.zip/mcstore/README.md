# McStore para PS4 (homebrew)

App PKG para PS4 con jailbreak que **busca y descarga add-ons de Minecraft Bedrock**
(`.mcpack`, `.mcaddon`, `.mcworld`, `.mctemplate`) desde un servidor pequeño en tu PC.

Dos fuentes de contenido (se elige en **Triángulo → Ajustes**):
- **GitHub (sin PC, por defecto):** la app lee `catalog.json` de *tu* repositorio por HTTPS y descarga los add-ons desde ahí.
- **PC en tu red:** `server/server.py` busca (carpeta `files/`, `catalog.json`, CurseForge) y la PS4 le habla por HTTP.

```
PS4 (McStore) --HTTPS--> raw.githubusercontent.com/TU_USUARIO/TU_REPO/main/catalog.json  (+ addons/...)
PS4 (McStore) --HTTP---> PC (server/server.py)                                           (opcional)
```

## Aviso importante
- **Minecraft de PS4 no lee estos archivos desde ninguna carpeta.** La app los deja en `/data/mcstore/downloads/`;
  meterlos en el juego (p. ej. dentro de un mundo y restaurar su savedata) es un paso aparte y depende de tu firmware/exploit.
- Descarga solo contenido que tengas derecho a usar. El servidor usa la API oficial de CurseForge y respeta
  los add-ons cuyo autor bloquea la descarga externa (no aparecen).
- Estado de las pruebas: el flujo completo (servidor + lista + teclado + ajustes + descarga) está probado en PC con una
  plataforma simulada, y la capa de PS4 se comprobó contra las cabeceras de OpenOrbis. **No se ha compilado el PKG ni
  probado en una consola real**; si el compilador marca algún detalle de API, será en `app/src/platform_ps4.cpp`.

## 0. Contenido en GitHub (sin PC)
La carpeta `ejemplo_repo/` trae un `catalog.json` y un pack de prueba propio (`addons/prueba_mcstore.mcpack`, vacío).
1. En tu repositorio sube `catalog.json` a la raíz y los add-ons a la carpeta `addons/`
   (desde el celular: `github.com/USUARIO/REPO/upload/main/addons`, y el catálogo con `/upload/main`).
2. Cada entrada de `catalog.json`: `name`, `summary`, `url` (ruta dentro del repo, p. ej. `addons/mi_pack.mcpack`, o un
   enlace `https://` directo), y opcionalmente `file` (nombre al guardar) y `size`. Evita espacios en los nombres.
3. En la app: **Options** recarga el catálogo. GitHub puede tardar unos minutos en mostrar cambios.
4. Compila con GitHub Actions: el `Makefile` toma la URL del catálogo de tu propio repositorio (`GITHUB_REPOSITORY`).
   En local: `make CATALOG_URL=https://raw.githubusercontent.com/USUARIO/REPO/main/catalog.json`.
   También puedes cambiarlo sin recompilar con un archivo `/data/mcstore/source.txt` (primera línea = URL del catálogo).
5. Límites de GitHub: 25 MB por archivo subido desde la web (100 MB por git). Sube solo contenido que tengas derecho a compartir.
6. Seguridad: la app acepta cualquier certificado HTTPS (la PS4 trae autoridades antiguas), igual que el ejemplo oficial de OpenOrbis.

## 1. Servidor (PC, opcional)
Requiere Python 3.8+. Para ver las **miniaturas** instala Pillow una vez: `pip install pillow` (sin Pillow todo funciona, solo sin imagen).
```
cd server
export CF_API_KEY=tu_clave        # gratis en console.curseforge.com
python3 server.py                 # puerto 8080
```
Que hace (parte 1, probado en PC con un CurseForge simulado):
- **Explorar sin escribir**: `/browse` lista lo mas popular de CurseForge Bedrock, 24 por pagina, con `page`, `sort` (popular, downloads, updated, new, name) y `cat` (categoria; ver `/categories`).
- **Rapido**: resultados en cache 10 min; miniaturas y archivos se preparan en segundo plano (8 hilos) mientras ves la lista y la descripcion.
- **Miniatura**: `/thumb/<id>?s=96|256` entrega la imagen ya reducida en formato crudo para la PS4 (sin decodificar PNG/JPG en la consola). Los archivos de `files/` usan el `pack_icon.png` de dentro del propio `.mcpack`.
- **Descripcion**: `/detail/<id>` trae autor, descargas, version y la descripcion completa en texto limpio.
- **Descarga automatica**: `/download/<id>` baja el archivo mas nuevo y lo deja listo: un `.zip` con `manifest.json` pasa a `.mcpack`; si el manifest esta dentro de una carpeta, lo re-empaqueta; si trae un pack dentro, lo saca; varios packs -> `.mcaddon`.
- Los add-ons cuyo autor **bloquea la descarga fuera de CurseForge** no aparecen (limite de la API oficial).
- Siguen funcionando `files/` y `catalog.json`. Prueba sin internet: `tools/host_test/mock_curseforge.py` (usar `CF_API_BASE=http://127.0.0.1:9100`).

Estado: la app ya usa estas funciones (parte 2, ver Uso).

## 2. App (compilar el PKG)
1. Descarga el **release** de [OpenOrbis PS4 Toolchain](https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain/releases)
   (el repositorio sin release no trae las herramientas `PkgTool.Core`, `create-fself` ni las librerías).
2. `export OO_PS4_TOOLCHAIN=/ruta/al/toolchain` (necesitas también `clang` y `ld.lld`).
3. `cd app && make` → genera `IV0000-MCST00001_00-MCSTORE000000000.pkg`.
4. Instala el PKG con tu método habitual en la PS4 liberada.
   (El Makefile copia solo `libc.prx` y `libSceFios2.prx` del toolchain al paquete; sin ellos la PS4 muestra
   "los datos de la aplicación están dañados".)

## 3. Uso
- Arranca directo en el catalogo de GitHub. **Triangulo → Ajustes**: elige la fuente y, si usas PC, su IP y puerto (X guarda).
- **Cuadricula de tarjetas** (4x4) con foto, nombre, autor, descargas y tamano. Con la fuente **PC** la foto viene de CurseForge; con GitHub se muestra un recuadro de color con la inicial.
- **X** abre el **detalle** (foto grande, autor, descargas, fecha, version y descripcion completa; Arriba/Abajo para leer). En el detalle **X** descarga (el servidor ya la va preparando) y **R2** abre la instalacion. **Circulo** vuelve.
- **L1/R1** cambian de pagina (fuente PC, 24 por pagina) · **Circulo** (en la lista) cambia el orden: Popular, Mas bajado, Actualizado, Nuevo, Nombre · **Cuadrado** buscar · **Options** recargar · **L2** bajar novedades · **L3** actualizar la app · **R2** instalar · **Triangulo** ajustes.
- Archivos en `/data/mcstore/downloads/` (copialos por FTP). Configuracion en `/data/mcstore/config.txt`.
- La red corre en segundo plano (las fotos tambien): la pantalla sigue respondiendo y **Circulo** cancela una carga o descarga.
- Pruebas en PC: `tools/host_test/run_test.py` (flujo completo) y `run_test2.py` (tarjetas, detalle, paginas, con capturas).

## 4. Instalar .mcpack en Minecraft (R2)

En la lista pulsa **R2** para abrir "Instalar en Minecraft". Muestra lo descargado en `/data/mcstore/downloads/`.

- **Ruta detectada, no fija**: `/app_tmp/<CUSA>/user<ID>/games/com.mojang/`. Se buscan los CUSA de la lista
  `MC_CUSA_LIST` (arriba de `app/src/install.h`: America `CUSA00744`, Europa/Asia `CUSA00265`, Japon `CUSA00283`;
  agrega una linea para ampliar), luego las carpetas `user*` con `resource_packs/` y `behavior_packs/`.
  Si no hay ninguna, cualquier carpeta de `/app_tmp` con `games/com.mojang`. Si hay varios `user*`, instala en todos.
  Si no aparece nada: "Abre Minecraft primero y vuelve a intentarlo" y no se copia nada.
- **Que carpeta**: se lee `manifest.json` DENTRO del .mcpack (sin extraerlo): `resources` -> `resource_packs/`,
  `data`/`script` -> `behavior_packs/`. Se copia tal cual, con extension `.mcpack`. Otros tipos o packs que mezclan
  ambos se rechazan con un aviso. `.mcaddon` queda pendiente.
- **Ya existe**: pregunta si reemplazar. **Version**: si el manifest pide un `min_engine_version` mayor que el de tu
  consola, avisa. Para eso crea `/data/mcstore/mcversion.txt` con tu version (ej. `1.26.51`); sin ese archivo solo
  muestra lo que pide el pack.
- Tras copiar: cierra y reabre Minecraft y activa el pack en el mundo. Lo instalado se pierde al cerrar el juego o
  apagar la consola: vuelve a instalar.
- Sin verificar en consola: como poner la app en segundo plano, si la escritura directa en `/app_tmp` funciona (aqui es
  escritura directa; no hay FTP) y si Minecraft acepta el .mcpack sin extraer.

## Prueba en PC (sin PS4)
`python3 tools/host_test/run_test.py /tmp/prueba` compila la app con una plataforma simulada, levanta el servidor,
navega, busca, descarga, verifica el hash del archivo y deja capturas PNG. La fuente se regenera con `tools/gen_font.py`.

## Compilar con GitHub (sin instalar nada)
1. Sube todo el proyecto a tu repositorio (la carpeta `.github/workflows/build-pkg.yml` incluida). Sirve subirlo suelto o como `mcstore.zip`: el workflow lo detecta solo (busca `app/fixgp4.py`).
2. **Actions → Build PKG → Run workflow** (tambien corre solo en cada subida de codigo a `main`; subir add-ons, `catalog.json` o `.md` NO lo dispara).
3. Descarga el `.pkg` desde **Artifacts → McStore-PKG**.
4. **Actualizaciones automaticas**: cada compilacion en `main` usa la version `1.<numero de build>`, copia el PKG a la raiz de tu repo como `McStore.pkg` y escribe `app_update.json`. En la consola, la app avisa sola al abrir ("Nueva version X (L3)") y **L3** baja el PKG a `/data/pkg/`; lo instalas desde GoldHEN: Debug Settings > Package Installer. (Si el PKG pesa mas de 95 MB GitHub no lo acepta y se omite este paso.)
5. Si subes un tag (`git tag v1.0 && git push --tags`) tambien se publica en **Releases**.
El workflow no se ha podido probar en GitHub desde aqui; si falla, el log dice el paso.

## Suspension de Minecraft (R2)

- Uso: abre Minecraft hasta el menu, pulsa PS (queda suspendido) y abre McStore. La carpeta `/app_tmp/CUSA.../` debe seguir montada.
- La app comprueba `sceSystemServiceGetAppIdOfBigApp()` para avisar mejor si no ve Minecraft.
- Al terminar, TRIANGULO llama a `sceSystemServiceLaunchApp(CUSA)` para volver a Minecraft (el CUSA sale de la ruta detectada, no esta fijo).
- SIN PROBAR en consola real: (1) que `/app_tmp` de Minecraft siga montado con McStore abierto, (2) que la consola no cierre Minecraft al abrir McStore, (3) que LaunchApp lo reanude. La API OpenOrbis no trae una funcion segura para suspender otra app desde la app, por eso la suspension la hace el boton PS.
- Makefile: se anadio `-lSceSystemService`.

## Convivir con Minecraft (param.sfo)

El PKG usa `ATTRIBUTE=32` y `CATEGORY=gde`, igual que Homebrew Store (LightningMods/PS4-Store), que en una consola real aparece junto a Minecraft. Antes era `ATTRIBUTE=0` y `CATEGORY=gd`, y la PS4 pedia cerrar Minecraft al abrir McStore. SIN PROBAR si este cambio basta.

## Acceso a /app_tmp (jailbreak de la app)

Sin salir del sandbox, McStore no puede listar `/app_tmp` (se vio en consola: "ilegible"). Al arrancar carga `Media/jb.prx` y llama `jailbreak_me()`, igual que Homebrew Store. El `jb.prx` viene de https://github.com/LightningMods/PS4-Store (GPLv3; basado en libjbc). Si falla, el aviso de error muestra `jailbreak=<codigo>`. SIN PROBAR si con esto ya se ve `/app_tmp`.

## Actualizar el catalogo (Options)

Options vuelve a bajar `catalog.json` de GitHub y avisa cuantos add-ons son **nuevos** o estan **actualizados** (cambio de tamano `size` o entrada nueva). Se marcan en la lista con `[NUEVO]` / `[ACTUALIZADO]`. Al abrir la app compara con la lista guardada en `/data/mcstore/catalog_seen.txt` (la primera vez solo la crea). Para que se detecte una actualizacion, cambia el `size` del add-on en `catalog.json`.

## Bajar todas las novedades (L2)

Despues de **Options** (que marca `[NUEVO]` / `[ACTUALIZADO]`), **L2** descarga uno tras otro todos los add-ons marcados a `/data/mcstore/downloads`. Cada uno que baja pierde su marca; si uno falla, la cadena se detiene. Luego **R2** para instalar en Minecraft. Para que un add-on cuente como "actualizado", cambia su `size` en `catalog.json`.

## Marcas de estado (fuente PC)
La app guarda en `/data/mcstore/got.txt` lo que descargas. En la lista: `[DESCARGADO]` (al dia) o `[HAY UPDATE]` (el servidor tiene otra fecha o tamano). **L2** baja de una vez todas las `[HAY UPDATE]` de la pagina. En la fuente GitHub siguen `[NUEVO]` / `[ACTUALIZADO]`.

## Categorias (fuente PC)
**Cuadrado** (buscar) → **L1/R1** elige la categoria de CurseForge (Addons, Texture Packs...) → **Options** busca. La categoria queda en la cabecera de la lista.

## Buscar actualizacion de la app (L3)

En la lista, **L3** (pulsar el stick izquierdo) lee `app_update.json` de tu repo GitHub (junto a `catalog.json`) y compara `name` con la version de la app (`VERSION` del Makefile). Si es mayor, avisa; pulsando **L3** otra vez baja el PKG a `/data/pkg/McStore-<version>.pkg`, y lo instalas desde GoldHEN: Debug Settings > Package Installer. La app NO se instala sola.

Para publicar una nueva: sube el `.pkg` a tu repo y edita `app_update.json` con `name` (la version, p. ej. `1.01`), `summary` (que cambia), `url` (ruta relativa o completa del PKG) y `size`.

## Subir packs desde el telefono (v10.5)
En la app: Ajustes (Triangulo) > Preferencias (Cuadrado) > ultima fila "Subir packs desde el telefono" (X).
La PS4 muestra una direccion `http://IP:8080`. Abrela en Safari (misma red wifi), elige los .mcpack/.mcaddon y toca Subir.
Caen en `downloads/` y se instalan con R2. No hace falta GitHub ni server.py.

El server.py (para PC) tambien tiene la pagina de subida: abre http://IP-del-PC:8080 en el telefono y los packs caen en server/files/.

## Modo creador (v11.5): publicar para todos desde el telefono
1. En la pagina de subida (la que abre la PS4), abre "Modo creador" y pega tu token de GitHub (fine-grained, solo tu repo, Contents: Read and write). Se guarda en la PS4 (`github_token.txt`), nunca en el repo.
2. Marca "Publicar tambien para TODOS" y sube. La PS4 manda el pack a `addons/` en GitHub; 'Build catalog' lo agrega solo al catalogo.
Quien no pegue un token no ve nada de esto: el modo creador es solo del dueno.

## Modo creador desde el PC (v12.0)
`python3 server.py` y abre `http://IP-del-PC:8080` en el navegador. En "Modo creador" pega tu token de GitHub (o define la variable GITHUB_TOKEN) y marca "Publicar tambien para TODOS": el pack va a `addons/` del repo (variable MCSTORE_REPO para otro repo) y entra solo al catalogo.
