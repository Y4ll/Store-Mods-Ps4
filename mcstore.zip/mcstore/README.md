# McStore para PS4 (homebrew)

App PKG para PS4 con jailbreak que **busca y descarga add-ons de Minecraft Bedrock**
(`.mcpack`, `.mcaddon`, `.mcworld`, `.mctemplate`) desde un servidor pequeño en tu PC.

Dos fuentes de contenido (se elige en **Triángulo → Ajustes**):
- **GitHub (sin PC, por defecto):** la app lee `catalog.json` de *tu* repositorio por HTTPS y descarga los add-ons desde ahí.
- **PC en tu red:** `server/server.py` busca (carpeta `files/`, `catalog.json`, CurseForge) y la PS4 le habla por HTTP.

```
PS4 (McStore) --HTTPS--> raw.githubusercontent.com/TU_USUARIO/TU_REPO/main/catalog.json  (+ addons/...)
PS4 (McStore) --HTTP---> PC (server/server.py)                                           (opcional)
```

## Aviso importante
- **Minecraft de PS4 no lee estos archivos desde ninguna carpeta.** La app los deja en `/data/mcstore/downloads/`;
  meterlos en el juego (p. ej. dentro de un mundo y restaurar su savedata) es un paso aparte y depende de tu firmware/exploit.
- Descarga solo contenido que tengas derecho a usar. El servidor usa la API oficial de CurseForge y respeta
  los add-ons cuyo autor bloquea la descarga externa (no aparecen).
- Estado de las pruebas: el flujo completo (servidor + lista + teclado + ajustes + descarga) está probado en PC con una
  plataforma simulada, y la capa de PS4 se comprobó contra las cabeceras de OpenOrbis. **No se ha compilado el PKG ni
  probado en una consola real**; si el compilador marca algún detalle de API, será en `app/src/platform_ps4.cpp`.

## 0. Contenido en GitHub (sin PC)
La carpeta `ejemplo_repo/` trae un `catalog.json` y un pack de prueba propio (`addons/prueba_mcstore.mcpack`, vacío).
1. En tu repositorio sube `catalog.json` a la raíz y los add-ons a la carpeta `addons/`
   (desde el celular: `github.com/USUARIO/REPO/upload/main/addons`, y el catálogo con `/upload/main`).
2. Cada entrada de `catalog.json`: `name`, `summary`, `url` (ruta dentro del repo, p. ej. `addons/mi_pack.mcpack`, o un
   enlace `https://` directo), y opcionalmente `file` (nombre al guardar) y `size`. Evita espacios en los nombres.
3. En la app: **Options** recarga el catálogo. GitHub puede tardar unos minutos en mostrar cambios.
4. Compila con GitHub Actions: el `Makefile` toma la URL del catálogo de tu propio repositorio (`GITHUB_REPOSITORY`).
   En local: `make CATALOG_URL=https://raw.githubusercontent.com/USUARIO/REPO/main/catalog.json`.
   También puedes cambiarlo sin recompilar con un archivo `/data/mcstore/source.txt` (primera línea = URL del catálogo).
5. Límites de GitHub: 25 MB por archivo subido desde la web (100 MB por git). Sube solo contenido que tengas derecho a compartir.
6. Seguridad: la app acepta cualquier certificado HTTPS (la PS4 trae autoridades antiguas), igual que el ejemplo oficial de OpenOrbis.

## 1. Servidor (PC, opcional)
Requiere Python 3.8+ (sin dependencias).
```
cd server
python3 server.py            # puerto 8080
```
Contenido, en cualquier combinación:
1. **Carpeta `server/files/`**: copia ahí tus `.mcpack/.mcaddon/.mcworld` y aparecen en la app.
2. **`server/catalog.json`**: enlaces directos (formato en `catalog.example.json`).
3. **CurseForge**: `export CF_API_KEY=tu_clave` (gratis en console.curseforge.com). Si el ID de juego no es
   el de Minecraft Bedrock, cámbialo con `CF_GAME_ID` (se consulta en `https://api.curseforge.com/v1/games`).

Averigua la IP del PC (`ipconfig` / `ip a`) y permite el puerto 8080 en el firewall.

## 2. App (compilar el PKG)
1. Descarga el **release** de [OpenOrbis PS4 Toolchain](https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain/releases)
   (el repositorio sin release no trae las herramientas `PkgTool.Core`, `create-fself` ni las librerías).
2. `export OO_PS4_TOOLCHAIN=/ruta/al/toolchain` (necesitas también `clang` y `ld.lld`).
3. `cd app && make` → genera `IV0000-MCST00001_00-MCSTORE000000000.pkg`.
4. Instala el PKG con tu método habitual en la PS4 liberada.
   (El Makefile copia solo `libc.prx` y `libSceFios2.prx` del toolchain al paquete; sin ellos la PS4 muestra
   "los datos de la aplicación están dañados".)

## 3. Uso
- Arranca directo en el catálogo de GitHub. **Triángulo → Ajustes**: elige la fuente y, si usas PC, su IP y puerto (X guarda).
- **X** descargar · **Cuadrado** buscar (teclado en pantalla) · **Triángulo** servidor · **Options** recargar ·
  **L1/R1** cambiar de página · **Círculo** cancela una búsqueda o descarga.
- Archivos en `/data/mcstore/downloads/` (cópialos por FTP). Configuración en `/data/mcstore/config.txt`.
- La red corre en segundo plano: si algo tarda, la pantalla sigue respondiendo y puedes cancelar.

## Prueba en PC (sin PS4)
`python3 tools/host_test/run_test.py /tmp/prueba` compila la app con una plataforma simulada, levanta el servidor,
navega, busca, descarga, verifica el hash del archivo y deja capturas PNG. La fuente se regenera con `tools/gen_font.py`.

## Compilar con GitHub (sin instalar nada)
1. Crea un repositorio en GitHub y sube esta carpeta (el workflow está en `.github/workflows/build-pkg.yml`).
2. Pestaña **Actions → Build PKG → Run workflow** (o cada `git push` a `main`).
3. Al terminar, descarga el `.pkg` desde **Artifacts → McStore-PKG**. Si subes un tag (`git tag v1.0 && git push --tags`)
   también se publica en **Releases**.
El workflow no se ha podido probar aquí; si falla, el log dirá qué paso (normalmente la descarga/extracción del toolchain).
