# McStore para PS4 (homebrew)

App PKG para PS4 con jailbreak que **busca y descarga add-ons de Minecraft Bedrock**
(`.mcpack`, `.mcaddon`, `.mcworld`, `.mctemplate`) desde un servidor pequeño en tu PC.

```
PS4 (app McStore)  <--HTTP, red local-->  PC (server/server.py)  -->  carpeta files/ · catalog.json · CurseForge
```

La PS4 no maneja bien HTTPS/JSON de webs modernas, así que el PC hace la búsqueda y la PS4 solo habla HTTP plano con él.

## Aviso importante
- **Minecraft de PS4 no lee estos archivos desde ninguna carpeta.** La app los deja en `/data/mcstore/downloads/`;
  meterlos en el juego (p. ej. dentro de un mundo y restaurar su savedata) es un paso aparte y depende de tu firmware/exploit.
- Descarga solo contenido que tengas derecho a usar. El servidor usa la API oficial de CurseForge y respeta
  los add-ons cuyo autor bloquea la descarga externa (no aparecen).
- Estado de las pruebas: el flujo completo (servidor + lista + teclado + ajustes + descarga) está probado en PC con una
  plataforma simulada, y la capa de PS4 se comprobó contra las cabeceras de OpenOrbis. **No se ha compilado el PKG ni
  probado en una consola real**; si el compilador marca algún detalle de API, será en `app/src/platform_ps4.cpp`.

## 1. Servidor (PC)
Requiere Python 3.8+ (sin dependencias).
```
cd server
python3 server.py            # puerto 8080
```
Contenido, en cualquier combinación:
1. **Carpeta `server/files/`**: copia ahí tus `.mcpack/.mcaddon/.mcworld` y aparecen en la app.
2. **`server/catalog.json`**: enlaces directos (formato en `catalog.example.json`).
3. **CurseForge**: `export CF_API_KEY=tu_clave` (gratis en console.curseforge.com). Si el ID de juego no es
   el de Minecraft Bedrock, cámbialo con `CF_GAME_ID` (se consulta en `https://api.curseforge.com/v1/games`).

Averigua la IP del PC (`ipconfig` / `ip a`) y permite el puerto 8080 en el firewall.

## 2. App (compilar el PKG)
1. Descarga el **release** de [OpenOrbis PS4 Toolchain](https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain/releases)
   (el repositorio sin release no trae las herramientas `PkgTool.Core`, `create-fself` ni las librerías).
2. `export OO_PS4_TOOLCHAIN=/ruta/al/toolchain` (necesitas también `clang` y `ld.lld`).
3. `cd app && make` → genera `IV0000-MCST00001_00-MCSTORE000000000.pkg`.
4. Instala el PKG con tu método habitual en la PS4 liberada.
   (El Makefile copia solo `libc.prx` y `libSceFios2.prx` del toolchain al paquete; sin ellos la PS4 muestra
   "los datos de la aplicación están dañados".)

## 3. Uso
- Primera vez: pantalla de ajustes → pon la IP del PC y el puerto con la cruceta (X guarda).
- **X** descargar · **Cuadrado** buscar (teclado en pantalla) · **Triángulo** servidor · **Options** recargar ·
  **L1/R1** cambiar de página · **Círculo** cancela una descarga.
- Archivos en `/data/mcstore/downloads/` (cópialos por FTP). Configuración en `/data/mcstore/config.txt`.
- Si la IP es incorrecta, la app espera hasta 15 s antes de mostrar el error.

## Prueba en PC (sin PS4)
`python3 tools/host_test/run_test.py /tmp/prueba` compila la app con una plataforma simulada, levanta el servidor,
navega, busca, descarga, verifica el hash del archivo y deja capturas PNG. La fuente se regenera con `tools/gen_font.py`.

## Compilar con GitHub (sin instalar nada)
1. Crea un repositorio en GitHub y sube esta carpeta (el workflow está en `.github/workflows/build-pkg.yml`).
2. Pestaña **Actions → Build PKG → Run workflow** (o cada `git push` a `main`).
3. Al terminar, descarga el `.pkg` desde **Artifacts → McStore-PKG**. Si subes un tag (`git tag v1.0 && git push --tags`)
   también se publica en **Releases**.
El workflow no se ha podido probar aquí; si falla, el log dirá qué paso (normalmente la descarga/extracción del toolchain).
