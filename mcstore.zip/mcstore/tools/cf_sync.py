#!/usr/bin/env python3
"""Baja el catalogo de Minecraft Bedrock de CurseForge y lo deja en el formato que lee McStore.

Se ejecuta en GitHub Actions (ver .github/workflows/sync-catalog.yml); no necesita PC.
Solo biblioteca estandar de Python.

    CF_API_KEY=... python3 tools/cf_sync.py --out site/catalog

Variables opcionales:
    CF_GAME_ID        id del juego en CurseForge (si no se da, se busca "minecraft-bedrock" por la API)
    CF_API_BASE       por defecto https://api.curseforge.com (cambiala solo para pruebas)
    MAX_PER_CLASS     maximo de add-ons por categoria (por defecto 5000; la API permite hasta 10000)
    CF_SLEEP          pausa entre peticiones en segundos (por defecto 0.2)

Salida (carpeta --out):
    meta.tsv      version del formato, fecha y las categorias (class <tab> clave <tab> nombre <tab> cantidad <tab> paginas)
    <k><n>.tsv    paginas de 40 add-ons de la categoria <k>, ordenados por descargas (la app las carga a medida que bajas)
    index.tsv     un renglon por add-on para la busqueda: clave <tab> pagina <tab> posicion <tab> descargas <tab> version <tab> nombre

Cada renglon de una pagina:
    id <tab> nombre <tab> autor <tab> descargas <tab> version <tab> tamano <tab> archivo <tab> url <tab> miniatura <tab> descripcion

Todo se limpia a ASCII (la fuente de la app no tiene acentos ni emojis) y sin tabuladores ni saltos de linea.
Solo se incluyen add-ons que CurseForge deja descargar (con downloadUrl y allowModDistribution distinto de false).
"""
import argparse
import datetime
import html
import json
import os
import re
import shutil
import sys
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request

PAGE = 40
API = os.environ.get("CF_API_BASE", "https://api.curseforge.com").rstrip("/")
KEY = os.environ.get("CF_API_KEY", "")
SLEEP = float(os.environ.get("CF_SLEEP", "0.2"))
MAX_PER_CLASS = int(os.environ.get("MAX_PER_CLASS", "5000"))
EXTS = (".mcpack", ".mcaddon", ".mcworld", ".mctemplate")

# Nombres en espanol para las categorias conocidas (por slug); el resto usa el nombre de CurseForge.
ES_NAMES = {
    "addons": "Add-ons", "add-ons": "Add-ons", "texture-packs": "Texturas", "resource-packs": "Texturas",
    "maps": "Mundos", "worlds": "Mundos", "skins": "Skins", "skin-packs": "Skins", "scripts": "Scripts",
    "mods": "Mods", "modpacks": "Modpacks", "shaders": "Shaders", "templates": "Plantillas",
}
# Orden de las pestanas: lo mas usado primero.
ORDER_HINTS = ["addon", "add-on", "texture", "resource", "map", "world", "skin", "script", "template", "shader"]


def clean(s, limit):
    s = html.unescape(str(s or ""))
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = s.encode("ascii", "ignore").decode("ascii")
    s = re.sub(r"[\x00-\x1f\x7f]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s[:limit].strip()


def clean_url(u):
    u = str(u or "").strip()
    if not u.lower().startswith(("http://", "https://")):
        return ""
    return re.sub(r"[\x00-\x20\x7f]", lambda m: "%%%02X" % ord(m.group(0)), u)


def get(path, params=None):
    url = API + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    last = None
    for attempt in range(7):
        req = urllib.request.Request(url, headers={"x-api-key": KEY, "Accept": "application/json", "User-Agent": "McStore-sync/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                data = json.loads(r.read().decode("utf-8"))
            time.sleep(SLEEP)
            return data
        except urllib.error.HTTPError as e:
            last = e
            if e.code in (401, 403):
                sys.exit("CurseForge rechazo la clave (HTTP %d). Revisa el secreto CF_API_KEY." % e.code)
            wait = 2 ** attempt
            if e.code == 429:
                try:
                    wait = max(wait, int(e.headers.get("Retry-After", "5")))
                except ValueError:
                    wait = max(wait, 5)
            print("  aviso: HTTP %d en %s, reintento en %ds" % (e.code, path, wait), file=sys.stderr)
            time.sleep(wait)
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as e:
            last = e
            print("  aviso: %s en %s, reintento" % (e, path), file=sys.stderr)
            time.sleep(2 ** attempt)
    sys.exit("No se pudo leer %s: %s" % (path, last))


def find_game():
    gid = os.environ.get("CF_GAME_ID")
    if gid:
        return int(gid)
    idx, seen = 0, []
    while True:
        d = get("/v1/games", {"index": idx, "pageSize": 50})
        for g in d.get("data", []):
            seen.append("%s=%s" % (g.get("id"), g.get("slug")))
            if g.get("slug") == "minecraft-bedrock" or "bedrock" in str(g.get("name", "")).lower():
                print("Juego:", g.get("name"), g.get("id"))
                return int(g["id"])
        p = d.get("pagination", {})
        idx += 50
        if idx >= p.get("totalCount", 0) or not d.get("data"):
            break
    sys.exit("No encontre Minecraft Bedrock en CurseForge. Juegos vistos: " + ", ".join(seen) + ". Pon CF_GAME_ID.")


def class_rank(c):
    s = (c.get("slug") or c.get("name") or "").lower()
    for i, h in enumerate(ORDER_HINTS):
        if h in s:
            return (i, s)
    return (len(ORDER_HINTS), s)


def get_classes(gid):
    d = get("/v1/categories", {"gameId": gid, "classesOnly": "true"})
    cs = [c for c in d.get("data", []) if c.get("isClass", True)]
    if not cs:
        sys.exit("CurseForge no devolvio categorias para el juego %s." % gid)
    cs.sort(key=class_rank)
    out = []
    for i, c in enumerate(cs):
        slug = (c.get("slug") or "").lower()
        name = clean(ES_NAMES.get(slug) or c.get("name") or slug or "Otros", 24) or "Otros"
        out.append({"id": c["id"], "key": chr(ord("a") + i), "name": name})
    return out


def pick_version(file_obj):
    best = None
    for v in file_obj.get("gameVersions") or []:
        m = re.search(r"\d+(?:\.\d+){1,3}", str(v))
        if m:
            t = tuple(int(x) for x in m.group(0).split("."))
            if best is None or t > best[0]:
                best = (t, m.group(0))
    return best[1] if best else ""


def to_record(mod):
    if mod.get("allowModDistribution") is False:
        return None
    files = [f for f in (mod.get("latestFiles") or [])
             if f.get("isAvailable", True) and f.get("downloadUrl") and str(f.get("fileName", "")).lower().endswith(EXTS)]
    if not files:
        return None
    f = max(files, key=lambda x: (str(x.get("fileDate", "")), int(x.get("id", 0))))
    url = clean_url(f["downloadUrl"])
    if not url:
        return None
    logo = mod.get("logo") or {}
    authors = mod.get("authors") or []
    name = clean(mod.get("name"), 54) or clean(mod.get("slug"), 54) or ("mod-%s" % mod.get("id"))
    fname = clean(f.get("fileName"), 90).replace("/", "_").replace("\\", "_") or ("%s.mcpack" % mod.get("id"))
    return {
        "id": int(mod["id"]),
        "name": name,
        "author": clean(authors[0].get("name") if authors else "", 30),
        "dl": int(mod.get("downloadCount") or 0),
        "ver": pick_version(f),
        "size": int(f.get("fileLength") or 0),
        "file": fname,
        "url": url,
        "thumb": clean_url(logo.get("thumbnailUrl") or logo.get("url")),
        "summary": clean(mod.get("summary"), 230),
    }


def fetch_class(gid, cls, seen_ids):
    got, idx, fetched = [], 0, 0
    while len(got) < MAX_PER_CLASS and idx + 50 <= 10000:
        d = get("/v1/mods/search", {"gameId": gid, "classId": cls["id"], "sortField": 6, "sortOrder": "desc",
                                    "pageSize": 50, "index": idx})
        data = d.get("data") or []
        if not data:
            break
        for mod in data:
            fetched += 1
            if mod["id"] in seen_ids:
                continue
            r = to_record(mod)
            if r:
                seen_ids.add(mod["id"])
                got.append(r)
        idx += len(data)
        total = (d.get("pagination") or {}).get("totalCount", 0)
        if idx >= total:
            break
        if (idx // 50) % 10 == 0:
            print("  %s: %d revisados, %d descargables" % (cls["name"], fetched, len(got)))
    print("%s: %d revisados, %d descargables" % (cls["name"], fetched, len(got)))
    return got[:MAX_PER_CLASS]


def row(*cols):
    return "\t".join(str(c) for c in cols) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    if not KEY:
        sys.exit("Falta CF_API_KEY (secreto del repositorio).")

    gid = find_game()
    classes = get_classes(gid)
    print("Categorias:", ", ".join("%s(%s)" % (c["name"], c["id"]) for c in classes))

    seen, per_class = set(), []
    for c in classes:
        per_class.append((c, fetch_class(gid, c, seen)))
    total = sum(len(r) for _, r in per_class)
    if total == 0:
        sys.exit("No salio ningun add-on descargable: no se actualiza el catalogo.")

    out = args.out
    tmp = out.rstrip("/\\") + ".tmp"
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    index_lines, meta_lines = [], []
    for c, recs in per_class:
        if not recs:
            continue
        pages = (len(recs) + PAGE - 1) // PAGE
        meta_lines.append(row("class", c["key"], c["name"], len(recs), pages))
        for p in range(pages):
            chunk = recs[p * PAGE:(p + 1) * PAGE]
            with open(os.path.join(tmp, "%s%d.tsv" % (c["key"], p + 1)), "w", encoding="ascii", newline="\n") as f:
                for r in chunk:
                    f.write(row(r["id"], r["name"], r["author"], r["dl"], r["ver"], r["size"], r["file"], r["url"], r["thumb"], r["summary"]))
            for slot, r in enumerate(chunk):
                index_lines.append(row(c["key"], p + 1, slot, r["dl"], r["ver"], r["name"]))
    with open(os.path.join(tmp, "index.tsv"), "w", encoding="ascii", newline="\n") as f:
        f.writelines(index_lines)
    with open(os.path.join(tmp, "meta.tsv"), "w", encoding="ascii", newline="\n") as f:
        f.write(row("v", 2))
        f.write(row("generated", datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")))
        f.write(row("total", total))
        f.writelines(meta_lines)
    with open(os.path.join(tmp, "NOTICE.txt"), "w", encoding="ascii") as f:
        f.write("Datos y archivos de CurseForge (https://www.curseforge.com/minecraft-bedrock). Cada add-on es de su autor.\n"
                "McStore solo lista los que CurseForge permite descargar desde aplicaciones de terceros.\n")
    shutil.rmtree(out, ignore_errors=True)
    os.rename(tmp, out)
    print("Listo: %d add-ons en %d categorias -> %s" % (total, len(meta_lines), out))


if __name__ == "__main__":
    main()
