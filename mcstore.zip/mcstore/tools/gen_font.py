#!/usr/bin/env python3
"""Genera app/src/font.h (fuente bitmap 8x16, ASCII 32..126) desde DejaVu Sans Mono.
Uso: python3 tools/gen_font.py [ruta_ttf] > app/src/font.h
"""
import sys
from PIL import Image, ImageDraw, ImageFont

TTF = sys.argv[1] if len(sys.argv) > 1 else "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
font = ImageFont.truetype(TTF, 13)
rows = []
for code in range(32, 127):
    img = Image.new("L", (8, 16), 0)
    ImageDraw.Draw(img).text((0, 0), chr(code), font=font, fill=255, anchor="la")
    rows.append([sum((1 << (7 - x)) for x in range(8) if img.getpixel((x, y)) > 110) for y in range(16)])

print("// Generado por tools/gen_font.py (DejaVu Sans Mono, licencia Bitstream Vera). No editar.")
print("#pragma once")
print("static const unsigned char FONT8X16[95][16] = {")
for code, r in zip(range(32, 127), rows):
    c = chr(code).replace("\\", "\\\\").replace("*/", "* /")
    print("    {%s}, // %r" % (",".join("0x%02X" % b for b in r), c))
print("};")
