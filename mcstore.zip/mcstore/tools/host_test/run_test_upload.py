#!/usr/bin/env python3
"""Subida desde el telefono: abre la pantalla, sube archivos por HTTP como lo haria Safari y revisa lo guardado.
Uso: python3 tools/host_test/run_test_upload.py <carpeta>"""
import os, shutil, subprocess, sys, time, urllib.request, urllib.error, urllib.parse
from PIL import Image
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
work = os.path.abspath(sys.argv[1]); shutil.rmtree(work, ignore_errors=True)
shots, data = os.path.join(work, "shots"), os.path.join(work, "data")
os.makedirs(shots); os.makedirs(data)
open(os.path.join(data, "prefs.txt"), "w").write("help=1\n")
exe = os.path.join(work, "app")
subprocess.check_call(["g++", "-std=c++17", "-O1", "-pthread", "-w", "-DCATALOG_URL=\"http://127.0.0.1:1/c.json\"", "-o", exe,
                       os.path.join(ROOT, "app/src/main.cpp"), os.path.join(ROOT, "tools/host_test/platform_host.cpp")])
FAIL = []
def check(ok, msg):
    print(("   OK  " if ok else "   MAL ") + msg)
    if not ok: FAIL.append(msg)
lines, fr = [], [3]
def press(*b): lines.append("%d hold %s" % (fr[0], "+".join(b))); lines.append("%d hold NONE" % (fr[0] + 2)); fr[0] += 5
press("CROSS"); fr[0] += 30          # inicio -> lista
press("TRIANGLE"); press("SQUARE")    # ajustes -> preferencias
for _ in range(5): press("DOWN")
lines.append("%d shot u0_prefs" % fr[0]); fr[0] += 3
press("CROSS"); fr[0] += 20
lines.append("%d shot u1_espera" % fr[0]); fr[0] += 700   # tiempo para que el cliente suba
lines.append("%d shot u2_recibido" % fr[0]); fr[0] += 3
press("CIRCLE")
lines.append("%d exit x" % fr[0])
sp = os.path.join(work, "u.script"); open(sp, "w").write("\n".join(lines) + "\n")
env = dict(os.environ, MCSTORE_SCRIPT=sp, MCSTORE_OUT=shots, MCSTORE_DATA=data)
proc = subprocess.Popen([exe], env=env)
base = None
t0 = time.time()
while time.time() - t0 < 60 and base is None:
    for port in range(8080, 8090):
        try:
            urllib.request.urlopen("http://127.0.0.1:%d/" % port, timeout=2).read(); base = "http://127.0.0.1:%d" % port; break
        except Exception: pass
    time.sleep(0.3)
check(base is not None, "el servidor abre un puerto")
if base:
    html = urllib.request.urlopen(base + "/").read().decode()
    check("McStore" in html and "XMLHttpRequest" in html, "la pagina web se sirve")
    big = os.urandom(3 * 1024 * 1024 + 123)
    def put(name, body):
        rq = urllib.request.Request(base + "/up?name=" + urllib.parse.quote(name), data=body, method="PUT")
        try: return urllib.request.urlopen(rq, timeout=30).status
        except urllib.error.HTTPError as e: return e.code
    check(put("Mi Pack (1).mcpack", big) == 200, "sube un .mcpack grande")
    check(put("otro.mcaddon", b"PK\x03\x04abc") == 200, "sube un .mcaddon pequeno")
    check(put("virus.exe", b"zzz") == 400, "rechaza otras extensiones")
    check(put("../../etc/x.mcpack", b"PKxx") == 200, "limpia rutas peligrosas")
    dl = os.path.join(data, "downloads")
    got = sorted(os.listdir(dl)) if os.path.isdir(dl) else []
    print("   guardados:", got)
    check("Mi Pack _1_.mcpack" in got and open(os.path.join(dl, "Mi Pack _1_.mcpack"), "rb").read() == big, "el archivo grande llega entero")
    check("otro.mcaddon" in got and "x.mcpack" in got and not any(g.endswith(".part") for g in got), "nombres limpios y sin .part")
    check(not os.path.exists(os.path.join(data, "..", "etc")), "no escribe fuera de downloads")
rc = proc.wait(timeout=120)
check(rc == 0, "app termino bien")
for f in os.listdir(shots):
    if f.endswith(".ppm"):
        p = os.path.join(shots, f); Image.open(p).convert("RGB").resize((960, 540)).save(p[:-4] + ".png"); os.remove(p)
print("RESULTADO:", "FAIL" if FAIL else "PASS"); sys.exit(1 if FAIL else 0)
