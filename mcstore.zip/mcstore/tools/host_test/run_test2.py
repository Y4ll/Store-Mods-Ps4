#!/usr/bin/env python3
"""Prueba de la pantalla nueva (tarjetas, miniaturas, detalle, paginas, orden).
Uso: python3 tools/host_test/run_test2.py <carpeta> ; necesita g++ y Pillow."""
import os, subprocess, sys, time, shutil, socket
from PIL import Image
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
work = os.path.abspath(sys.argv[1]); shutil.rmtree(work, ignore_errors=True)
shots, data, files = [os.path.join(work, d) for d in ("shots", "data", "files")]
for d in (shots, data, files): os.makedirs(d)
exe = os.path.join(work, "app")
subprocess.check_call(["g++", "-std=c++17", "-O1", "-pthread", "-w", "-DCATALOG_URL=\"http://127.0.0.1:8099/c.json\"", "-o", exe,
                       os.path.join(ROOT, "app/src/main.cpp"), os.path.join(ROOT, "tools/host_test/platform_host.cpp")])
procs = []
def spawn(cmd, env=None):
    p = subprocess.Popen(cmd, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, start_new_session=True); procs.append(p); return p
def wait_port(port):
    for _ in range(60):
        try: socket.create_connection(("127.0.0.1", port), 0.2).close(); return
        except OSError: time.sleep(0.1)
    raise SystemExit("puerto %d no abre" % port)
try:
    spawn([sys.executable, os.path.join(ROOT, "tools/host_test/mock_curseforge.py"), "9100"]); wait_port(9100)
    env = dict(os.environ, CF_API_KEY="x", CF_API_BASE="http://127.0.0.1:9100", MCSTORE_CACHE=os.path.join(work, "cache"),
               MCSTORE_FILES=files, MCSTORE_CATALOG=os.path.join(work, "none.json"))
    spawn([sys.executable, os.path.join(ROOT, "server/server.py"), "8080"], env); wait_port(8080)
    open(os.path.join(data, "config.txt"), "w").write("127.0.0.1:8080\n1\n")
    # C1 bajado hace tiempo (ahora hay otra version) y C2 bajado y al dia
    open(os.path.join(data, "got.txt"), "w").write("C1|2020-01-01|5\nC2|2026-03-12|1002\n")
    lines, fr = [], [3]
    def press(*b): lines.append("%d hold %s" % (fr[0], "+".join(b))); lines.append("%d hold NONE" % (fr[0] + 2)); fr[0] += 5
    def shot(n): lines.append("%d shot %s" % (fr[0], n)); fr[0] += 3
    def wait(n): fr[0] += n
    wait(90); shot("a_cuadricula")
    press("SQUARE"); wait(3); press("R1"); shot("k_teclado_categoria"); press("OPTIONS"); wait(70); shot("l_lista_con_categoria")
    press("L2"); wait(150); shot("m_actualizando_todo")
    press("RIGHT"); press("DOWN"); press("DOWN"); press("DOWN"); press("DOWN"); wait(60); shot("b_scroll")
    press("CROSS"); wait(5); shot("c_detalle_cargando"); wait(90); shot("d_detalle")
    for _ in range(6): press("DOWN")
    shot("e_detalle_scroll")
    press("CROSS"); wait(10); shot("f_descargando"); wait(120); shot("g_descargado")
    press("CIRCLE"); wait(5); shot("g2_lista_descargado"); press("R1"); wait(90); shot("h_pagina2")
    press("CIRCLE"); wait(90); shot("i_orden")
    lines.append("%d exit x" % fr[0])
    sp = os.path.join(work, "s.script"); open(sp, "w").write("\n".join(lines) + "\n")
    r = subprocess.run([exe], env=dict(os.environ, MCSTORE_SCRIPT=sp, MCSTORE_OUT=shots, MCSTORE_DATA=data), timeout=150)
    print("app termino:", r.returncode)
    for f in sorted(os.listdir(shots)):
        Image.open(os.path.join(shots, f)).save(os.path.join(shots, f[:-4] + ".png")); os.remove(os.path.join(shots, f))
    dl = os.path.join(data, "downloads"); print("descargas:", os.listdir(dl) if os.path.isdir(dl) else "NINGUNA")
    print("got.txt:", open(os.path.join(data, "got.txt")).read().split())
finally:
    for p in procs: p.terminate()
