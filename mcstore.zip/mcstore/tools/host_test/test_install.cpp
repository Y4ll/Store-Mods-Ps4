// Pruebas del modulo de instalacion sin pantalla: inspect <archivo> | detect
#include "../../app/src/install.h"

int main(int argc, char **argv) {
    if (argc >= 3 && !strcmp(argv[1], "inspect")) {
        McPack p;
        mc_pack_inspect(argv[2], &p);
        printf("kind=%d min=%d.%d.%d has=%d name=[%s] types=[%s] err=[%s]\n", p.kind, p.minEng[0], p.minEng[1], p.minEng[2],
               p.hasMin ? 1 : 0, p.name, p.types, p.err);
        return 0;
    }
    if (argc >= 2 && !strcmp(argv[1], "detect")) {
        McTargets t;
        int n = mc_detect(&t);
        printf("n=%d\n", n);
        for (int i = 0; i < t.n; i++) printf("%s\n", t.path[i]);
        return 0;
    }
    return 2;
}
