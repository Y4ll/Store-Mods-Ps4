#!/usr/bin/env python3
"""Inicio animado, ayuda y preferencias (sin NOSPLASH). Uso: python3 tools/host_test/run_test3.py <carpeta>"""
import glob, os, shutil, subprocess, sys
from PIL import Image
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
work = os.path.abspath(sys.argv[1]); shutil.rmtree(work, ignore_errors=True)
shots, data = os.path.join(work, "shots"), os.path.join(work, "data")
os.makedirs(shots); os.makedirs(data)
extra = sys.argv[2:]  # banderas -D opcionales
exe = os.path.join(work, "app")
subprocess.check_call(["g++", "-std=c++17", "-O1", "-pthread", "-w", "-DCATALOG_URL=\"http://127.0.0.1:1/c.json\"", "-o", exe,
                       os.path.join(ROOT, "app/src/main.cpp"), os.path.join(ROOT, "tools/host_test/platform_host.cpp")] + extra)
FAIL = []
def check(ok, msg):
    print(("   OK  " if ok else "   MAL ") + msg)
    if not ok: FAIL.append(msg)
def run(name, build, env=None):
    lines, fr = [], [3]
    def press(*b): lines.append("%d hold %s" % (fr[0], "+".join(b))); lines.append("%d hold NONE" % (fr[0] + 2)); fr[0] += 5
    def shot(n): lines.append("%d shot %s" % (fr[0], n)); fr[0] += 3
    def wait(n): fr[0] += n
    build(press, shot, wait)
    lines.append("%d exit x" % fr[0])
    sp = os.path.join(work, name + ".script"); open(sp, "w").write("\n".join(lines) + "\n")
    e = dict(os.environ, MCSTORE_SCRIPT=sp, MCSTORE_OUT=shots, MCSTORE_DATA=data)
    if env: e.update(env)
    r = subprocess.run([exe], env=e, timeout=120)
    check(r.returncode == 0, "app %s termino bien" % name)

# primera vez: inicio -> ayuda -> lista
def first(p, s, w):
    w(2); s("a0_inicio_0"); w(25); s("a1_inicio_1"); w(35); s("a2_inicio_2")
    p("CROSS"); w(3); s("a3_ayuda_primera_vez")
    for _ in range(3): p("R1")
    s("a4_ayuda_abajo")
    p("CIRCLE"); w(5); s("a5_lista")
run("first", first)
check(open(os.path.join(data, "prefs.txt")).read().startswith("help=1"), "prefs.txt guarda que ya vio la ayuda")
# segunda vez: inicio -> lista directa; ayuda desde ajustes
def second(p, s, w):
    w(2); p("CROSS"); w(3); s("b0_lista_directa")
    p("TRIANGLE"); s("b1_ajustes"); p("TRIANGLE"); s("b2_ayuda_desde_ajustes"); p("CIRCLE"); s("b3_vuelve_a_ajustes")
run("second", second)
for f in glob.glob(os.path.join(shots, "*.ppm")):
    Image.open(f).convert("RGB").resize((960, 540)).save(f[:-4] + ".png"); os.remove(f)
print("RESULTADO:", "FAIL" if FAIL else "PASS"); sys.exit(1 if FAIL else 0)
