// Prueba del sintetizador: musica y efectos suenan (ni silencio, ni saturacion, ni NaN) y los efectos terminan.
#include <math.h>
#include <stdio.h>
#include "../../app/src/audio.h"
int main() {
    int bad = 0;
    static int16_t buf[AU_RATE * 25];
    g_auMusic = 1; g_auSfxOn = 1;
    audio_render(buf, AU_RATE * 25);  // 25 s
    int mx = 0; double e = 0;
    for (int i = 0; i < AU_RATE * 25; i++) { int a = abs(buf[i]); if (a > mx) mx = a; e += (double)buf[i] * buf[i]; }
    double rms = sqrt(e / (AU_RATE * 25));
    printf("musica: pico %d rms %.0f\n", mx, rms);
    if (mx < 2000 || mx > 20000 || rms < 300) { printf("MAL musica fuera de rango\n"); bad++; }
    // efectos con la musica apagada
    g_auMusic = 0;
    for (int k = SFX_MOVE; k <= SFX_ERROR; k++) {
        sfx(k);
        int n = 0, peak = 0;
        while (n < AU_RATE && audio_render(buf, 256)) { for (int i = 0; i < 256; i++) { int a = abs(buf[i]); if (a > peak) peak = a; } n += 256; }
        printf("efecto %d: %d muestras, pico %d\n", k, n, peak);
        if (n == 0 || n >= AU_RATE || peak < 3000 || peak > 20000) { printf("MAL efecto %d\n", k); bad++; }
    }
    // apagado = silencio y devuelve false
    g_auSfxOn = 0; sfx(SFX_DONE);
    if (audio_render(buf, 256)) { printf("MAL: con efectos apagados no debe sonar\n"); bad++; }
    // prioridad: un aviso de descarga no lo pisa un 'mover'
    g_auSfxOn = 1; sfx(SFX_DONE); sfx(SFX_MOVE);
    if (g_auPending.load() != SFX_DONE) { printf("MAL prioridad\n"); bad++; }
    printf(bad ? "RESULTADO: FAIL\n" : "RESULTADO: PASS\n");
    return bad ? 1 : 0;
}
