#!/usr/bin/env python3
"""Prueba en PC del menu, los temas, el fondo con imagen y la tienda de CurseForge (con CurseForge simulado).
Uso: python3 tools/host_test/run_ui_test.py <carpeta_de_trabajo>"""
import glob, hashlib, json, os, shutil, socket, subprocess, sys, time
from PIL import Image, ImageDraw

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
work = os.path.abspath(sys.argv[1]); shutil.rmtree(work, ignore_errors=True); os.makedirs(work)
out = os.path.join(work, "shots"); os.makedirs(out)
FAIL = []
def check(ok, msg):
    print(("   OK  " if ok else "   MAL ") + msg)
    if not ok: FAIL.append(msg)
def wait_port(port):
    for _ in range(80):
        try: socket.create_connection(("127.0.0.1", port), 0.2).close(); return
        except OSError: time.sleep(0.1)
    raise SystemExit("puerto %d no abre" % port)

# CurseForge simulado -> catalogo con cf_sync -> servido como "rama catalog-data"
cf = subprocess.Popen([sys.executable, os.path.join(ROOT, "tools/host_test/mock_cf.py"), "8090", os.path.join(work, "expected.json")],
                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); wait_port(8090)
site = os.path.join(work, "site", "catalog")
os.makedirs(os.path.dirname(site))
subprocess.check_call([sys.executable, os.path.join(ROOT, "tools/cf_sync.py"), "--out", site],
                      env=dict(os.environ, CF_API_KEY="TESTKEY", CF_API_BASE="http://127.0.0.1:8090", CF_SLEEP="0"), stdout=subprocess.DEVNULL)
web = subprocess.Popen([sys.executable, "-m", "http.server", "8099", "--bind", "127.0.0.1", "--directory", os.path.join(work, "site")],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); wait_port(8099)

exe = os.path.join(work, "mcstore_host")
subprocess.check_call(["clang++", "-std=c++17", "-O1", "-pthread", "-Wno-unused-function",
                       "-DSTORE_URL=\"http://127.0.0.1:8099/catalog/\"", "-DCATALOG_URL=\"http://127.0.0.1:8099/catalog.json\"", "-o", exe,
                       os.path.join(ROOT, "app/src/main.cpp"), os.path.join(ROOT, "tools/host_test/platform_host.cpp")])

def run(name, build, data_dir, extra=None):
    lines = []; fr = [3]
    def press(*b):
        lines.append("%d hold %s" % (fr[0], "+".join(b))); lines.append("%d hold NONE" % (fr[0] + 2)); fr[0] += 5
    def shot(n): lines.append("%d shot %s" % (fr[0], n)); fr[0] += 3
    def wait(n): fr[0] += n
    build(press, shot, wait)
    lines.append("%d exit x" % fr[0])
    sp = os.path.join(work, name + ".script"); open(sp, "w").write("\n".join(lines) + "\n")
    e = dict(os.environ, MCSTORE_SCRIPT=sp, MCSTORE_OUT=out, MCSTORE_DATA=data_dir)
    if extra: e.update(extra)
    r = subprocess.run([exe], env=e, timeout=300)
    check(r.returncode == 0, "app %s termino bien" % name)

# imagenes de fondo de prueba (una grande horizontal JPG, una vertical PNG)
data = os.path.join(work, "data"); fondos = os.path.join(data, "fondos"); os.makedirs(fondos)
im = Image.new("RGB", (3000, 1500))
d = ImageDraw.Draw(im)
for y in range(1500):
    d.line([(0, y), (3000, y)], fill=(40 + y // 8, 90, 200 - y // 10))
for i in range(40):
    d.ellipse([i * 70, 300 + (i % 5) * 150, i * 70 + 120, 420 + (i % 5) * 150], fill=(255, 200 - i * 4, 60))
im.save(os.path.join(fondos, "Cielo.jpg"), quality=85)
im2 = Image.new("RGB", (900, 1400), (150, 30, 120)); ImageDraw.Draw(im2).rectangle([100, 100, 800, 1300], outline=(255, 255, 255), width=20)
im2.save(os.path.join(fondos, "vertical.png"))
open(os.path.join(fondos, "roto.png"), "wb").write(b"no soy una imagen")
open(os.path.join(fondos, "nota.txt"), "w").write("no es imagen")

def flow(p, s, w):
    s("m0_menu_inicio")
    p("DOWN"); p("RIGHT"); s("m1_menu_apariencia")
    p("L1"); s("m2_menu_tema_anterior")          # cambia de tema desde el menu
    p("R1"); p("TRIANGLE"); s("t0_apariencia")   # apariencia
    p("RIGHT"); s("t1_tema_negro"); p("RIGHT"); s("t2_tema_blanco")
    p("RIGHT"); p("RIGHT"); s("t3_tema_morado")
    p("DOWN"); p("RIGHT"); w(40); s("t4_fondo_cielo")
    p("RIGHT"); w(40); s("t5_fondo_vertical")
    p("RIGHT"); w(40); s("t5b_fondo_roto")
    p("LEFT"); p("LEFT"); w(40)
    p("DOWN"); p("RIGHT"); p("RIGHT"); s("t6_oscurecer_70")
    p("UP"); p("UP"); p("LEFT"); p("LEFT"); p("LEFT"); p("LEFT"); s("t7_verde_con_fondo")       # tema verde
    p("CIRCLE"); s("m3_menu_con_fondo")
    # tienda
    p("UP"); p("LEFT"); p("CROSS"); w(30); s("s0_tienda_texturas_cargando"); w(60); s("s1_tienda")
    p("DOWN"); p("DOWN"); w(40); s("s2_tienda_seleccion")
    for _ in range(14): p("DOWN")
    w(60); s("s3_tienda_pag2")
    p("RIGHT"); w(60); s("s4_otra_categoria")
    p("SQUARE")                                                        # escribe "drag"
    for _ in range(3): p("RIGHT")
    p("CROSS"); p("DOWN")
    for _ in range(4): p("RIGHT")
    p("CROSS"); p("UP")
    for _ in range(7): p("LEFT")
    p("CROSS")
    for _ in range(6): p("RIGHT")
    p("CROSS"); s("s4b_teclado"); p("OPTIONS")
    w(80); s("s5_busqueda")
    p("CROSS"); w(10); s("s6_descargando"); w(120); s("s7_descargado")
    p("CIRCLE"); p("CIRCLE"); s("m4_menu_otra_vez")
run("ui", flow, data)

# archivos
dl = glob.glob(os.path.join(data, "downloads", "*"))
exp = json.load(open(os.path.join(work, "expected.json")))
check(len(dl) == 1, "se descargo 1 archivo: %s" % [os.path.basename(x) for x in dl])
if dl:
    mid = int(os.path.basename(dl[0]).split()[1]) if os.path.basename(dl[0]).startswith("Pack ") else None
    if mid:
        want = (hashlib.sha256(str(mid).encode()).digest() * 200)[:2000 + (mid % 7) * 500]
        check(open(dl[0], "rb").read() == want, "contenido igual al original (%s)" % os.path.basename(dl[0]))
check(open(os.path.join(data, "theme.txt")).read().startswith("0 7\nCielo.jpg"), "theme.txt guardado: %r" % open(os.path.join(data, "theme.txt")).read())

for f in glob.glob(os.path.join(out, "*.ppm")):
    Image.open(f).convert("RGB").resize((960, 540)).save(f[:-4] + ".png"); os.remove(f)
cf.terminate(); web.terminate()
print("RESULTADO:", "FAIL" if FAIL else "PASS")
sys.exit(1 if FAIL else 0)
