#!/usr/bin/env python3
"""CurseForge simulado (solo para pruebas en PC): imita /v1/games, /v1/categories y /v1/mods/search,
y sirve los archivos y las miniaturas que esos datos dicen. Uso: mock_cf.py <puerto>
Clave de API aceptada: TESTKEY. Incluye casos feos a proposito (sin downloadUrl, distribucion prohibida,
.zip, acentos/emojis/CJK, tabuladores y saltos de linea, entidades HTML)."""
import hashlib
import io
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from PIL import Image, ImageDraw

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8090
BASE = "http://127.0.0.1:%d" % PORT
GAME_ID = 78022
CLASSES = [(4984, "Addons", "addons", 130), (6, "Texture Packs", "texture-packs", 95), (6913, "Maps", "maps", 30), (7000, "Skins", "skins", 12)]


def make_mod(cid, i, base):
    mid = base + i
    exts = [".mcaddon", ".mcpack", ".mcworld"]
    ext = ".mcpack" if cid == 6 else (".mcworld" if cid == 6913 else exts[i % 2])
    if i % 17 == 5:
        ext = ".zip"                       # no instalable: no debe salir
    name = "Dragon Epico #%d" % mid if i % 5 else "Dragón Épico ñandú 龍 \U0001F409 #%d" % mid
    summary = "Descripción larga &amp; con acentos, tab\tulador y\nsalto de línea. " * (1 + i % 4) + "Fin %d." % mid
    old = {"id": mid * 10 + 1, "fileName": "old_%d%s" % (mid, ext), "fileDate": "2024-01-01T00:00:00Z", "fileLength": 1000,
           "isAvailable": True, "gameVersions": ["Bedrock", "1.20.%d" % (i % 80)],
           "downloadUrl": "%s/files/%d/old_%d%s" % (BASE, mid, mid, ext)}
    new = {"id": mid * 10 + 2, "fileName": "Pack %d v2%s" % (mid, ext), "fileDate": "2025-06-01T00:00:00Z",
           "fileLength": 2000 + (mid % 7) * 500, "isAvailable": True,
           "gameVersions": ["Bedrock", "1.21.%d" % (60 + i % 30)] + (["1.26.51"] if i % 3 == 0 else []),
           "downloadUrl": "%s/files/%d/Pack%%20%d%%20v2%s" % (BASE, mid, mid, ext)}
    if i % 11 == 0:
        new["downloadUrl"] = None           # CurseForge no deja descargarlo desde apps: no debe salir
        old["downloadUrl"] = None
    mod = {"id": mid, "name": name, "slug": "mod-%d" % mid, "summary": summary, "downloadCount": 1_000_000 - i * 137 - cid,
           "classId": cid, "authors": [{"id": 1, "name": "Autor Ñoño %d" % (i % 9)}],
           "logo": {"thumbnailUrl": "%s/img/%d.%s" % (BASE, mid, "png" if mid % 2 == 0 else "jpg"), "url": "%s/img/big_%d.png" % (BASE, mid)},
           "latestFiles": [old, new]}
    if i % 13 == 7:
        mod["allowModDistribution"] = False  # el autor no permite distribuirlo
    return mod


MODS = {cid: [make_mod(cid, i, cid * 10000) for i in range(n)] for cid, _, _, n in CLASSES}
EXPECTED = {}  # lo que deberia salir (ids), para que run_test lo compruebe
for cid, mods in MODS.items():
    EXPECTED[cid] = [m["id"] for m in mods if m.get("allowModDistribution") is not False
                     and any(f["downloadUrl"] and f["fileName"].endswith((".mcpack", ".mcaddon", ".mcworld")) for f in m["latestFiles"])]
with open(sys.argv[2] if len(sys.argv) > 2 else "/dev/null", "w") as _f:
    json.dump({str(k): v for k, v in EXPECTED.items()}, _f)

IMG = {}


def image_bytes(mid, fmt):
    key = (mid, fmt)
    if key not in IMG:
        h = hashlib.sha256(str(mid).encode()).digest()
        im = Image.new("RGB", (256, 256), (h[0], h[1], h[2]))
        d = ImageDraw.Draw(im)
        for y in range(0, 256, 8):
            d.rectangle([0, y, 255, y + 4], fill=(h[3], (h[4] + y) % 256, h[5]))
        d.rectangle([40, 90, 216, 166], fill=(255, 255, 255))
        d.text((60, 120), "MOD %d" % mid, fill=(0, 0, 0))
        b = io.BytesIO()
        im.save(b, "PNG" if fmt == "png" else "JPEG")
        IMG[key] = b.getvalue()
    return IMG[key]


def file_bytes(mid, n):
    return (hashlib.sha256(str(mid).encode()).digest() * (n // 32 + 1))[:n]


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        p = u.path
        if p.startswith("/v1/"):
            if self.headers.get("x-api-key") != "TESTKEY":
                return self.send(403, b'{"error":"bad key"}')
            if p == "/v1/games":
                data = [{"id": 432, "name": "Minecraft", "slug": "minecraft"}, {"id": GAME_ID, "name": "Minecraft Bedrock", "slug": "minecraft-bedrock"}]
                return self.send(200, json.dumps({"data": data, "pagination": {"index": 0, "pageSize": 50, "resultCount": 2, "totalCount": 2}}).encode())
            if p == "/v1/categories":
                if int(q.get("gameId", 0)) != GAME_ID:
                    return self.send(200, b'{"data":[]}')
                data = [{"id": c, "name": n, "slug": s, "isClass": True} for c, n, s, _ in CLASSES]
                data.append({"id": 999, "name": "Subcategoria", "slug": "sub", "isClass": False, "classId": 4984})
                return self.send(200, json.dumps({"data": data}).encode())
            if p == "/v1/mods/search":
                if int(q.get("gameId", 0)) != GAME_ID or int(q.get("classId", 0)) not in MODS:
                    return self.send(200, json.dumps({"data": [], "pagination": {"totalCount": 0}}).encode())
                mods = sorted(MODS[int(q["classId"])], key=lambda m: -m["downloadCount"])
                idx, size = int(q.get("index", 0)), min(int(q.get("pageSize", 50)), 50)
                if idx + size > 10000:
                    return self.send(400, b'{"error":"index+pageSize > 10000"}')
                chunk = mods[idx:idx + size]
                return self.send(200, json.dumps({"data": chunk, "pagination": {"index": idx, "pageSize": size, "resultCount": len(chunk), "totalCount": len(mods)}}).encode())
            return self.send(404, b"{}")
        if p.startswith("/img/"):
            name = p.split("/")[-1]
            mid = int(name.replace("big_", "").split(".")[0])
            return self.send(200, image_bytes(mid, "png" if name.endswith(".png") else "jpg"), "image/png" if name.endswith(".png") else "image/jpeg")
        if p.startswith("/files/"):
            parts = p.split("/")
            return self.send(200, file_bytes(int(parts[2]), 2000 + (int(parts[2]) % 7) * 500), "application/octet-stream")
        self.send(404, b"no")


if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
