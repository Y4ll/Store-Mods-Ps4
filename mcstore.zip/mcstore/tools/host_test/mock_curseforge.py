#!/usr/bin/env python3
"""CurseForge falso para probar server.py sin internet. Uso: mock_curseforge.py [puerto]"""
import io, json, sys, zipfile, urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from PIL import Image, ImageDraw

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 9100
BASE = "http://127.0.0.1:%d" % PORT
N = 60

def manifest(t, n):
    return json.dumps({"format_version": 2, "header": {"name": n, "uuid": "11111111-1111-1111-1111-111111111111", "version": [1, 0, 0], "min_engine_version": [1, 21, 0]},
                       "modules": [{"type": t, "uuid": "22222222-2222-2222-2222-222222222222", "version": [1, 0, 0]}]})

def mod(i):
    kinds = ["file.mcpack", "file.zip", "folder.zip", "inner.zip", "blocked"]
    k = kinds[i % 5]
    fname = {"file.mcpack": "pack%d.mcpack" % i, "file.zip": "pack%d.zip" % i, "folder.zip": "Carpeta %d.zip" % i, "inner.zip": "wrap%d.zip" % i}.get(k, "x.mcpack")
    return {"id": i, "name": "Add-on Ñandú %d" % i, "summary": "Resumen del add-on número %d con acentos: árboles y dragones" % i,
            "authors": [{"name": "Autor%d" % (i % 7)}], "downloadCount": 100000 - i * 777, "dateModified": "2026-0%d-1%dT10:00:00Z" % (i % 9 + 1, i % 9),
            "logo": {"thumbnailUrl": "%s/img/%d.png" % (BASE, i)},
            "latestFiles": [{"id": i * 10, "fileName": fname, "fileLength": 1000 + i, "fileDate": "2026-01-01T00:00:00Z",
                             "downloadUrl": None if k == "blocked" else "%s/files/%d/%s" % (BASE, i, k), "gameVersions": ["1.21", "Bedrock"]}]}

def file_bytes(i, kind):
    b = io.BytesIO()
    if kind == "file.mcpack":
        with zipfile.ZipFile(b, "w") as z: z.writestr("manifest.json", manifest("resources", "P%d" % i)); z.writestr("pack_icon.png", b"x")
    elif kind == "file.zip":
        with zipfile.ZipFile(b, "w") as z: z.writestr("manifest.json", manifest("data", "P%d" % i))
    elif kind == "folder.zip":
        with zipfile.ZipFile(b, "w") as z: z.writestr("Mi Pack/manifest.json", manifest("resources", "P%d" % i)); z.writestr("Mi Pack/textures/a.txt", "a")
    else:
        inner = io.BytesIO()
        with zipfile.ZipFile(inner, "w") as z: z.writestr("manifest.json", manifest("data", "P%d" % i))
        with zipfile.ZipFile(b, "w") as z: z.writestr("real_%d.mcpack" % i, inner.getvalue()); z.writestr("LEEME.txt", "hola")
    return b.getvalue()

class H(BaseHTTPRequestHandler):
    def out(self, body, ct="application/json"):
        self.send_response(200); self.send_header("Content-Type", ct); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        u = urllib.parse.urlparse(self.path); q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}; p = u.path
        if p == "/v1/categories": return self.out(json.dumps({"data": [{"id": 4984, "name": "Addons"}, {"id": 6929, "name": "Texture Packs"}]}).encode())
        if p == "/v1/mods/search":
            ids = [i for i in range(1, N + 1) if q.get("searchFilter", "").lower() in ("add-on ñandú %d" % i).lower()]
            ids = ids[int(q.get("index", 0)): int(q.get("index", 0)) + int(q.get("pageSize", 20))]
            return self.out(json.dumps({"data": [mod(i) for i in ids], "pagination": {"totalCount": N}}).encode())
        if p.startswith("/v1/mods/") and p.endswith("/description"):
            return self.out(json.dumps({"data": "<h2>Título</h2><p>Este add-on añade <b>dragones</b> &amp; más.</p><ul><li>Uno</li><li>Dos</li></ul>"}).encode())
        if p.startswith("/v1/mods/"): return self.out(json.dumps({"data": mod(int(p.rsplit("/", 1)[1]))}).encode())
        if p.startswith("/img/"):
            i = int(p[5:-4]); im = Image.new("RGBA", (256, 256), (i * 4 % 255, 120, 200 - i * 3 % 150, 255)); ImageDraw.Draw(im).rectangle((40, 40, 216, 216), outline=(255, 255, 255, 255), width=8)
            b = io.BytesIO(); im.save(b, "PNG"); return self.out(b.getvalue(), "image/png")
        if p.startswith("/files/"):
            _, _, i, k = p.split("/"); return self.out(file_bytes(int(i), k), "application/octet-stream")
        self.send_error(404)
    def log_message(self, *a): pass

ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
