// Plataforma "falsa" para probar la app en un PC sin PS4: framebuffer en RAM,
// mando guiado por un guion y capturas en PPM. NO se compila para la PS4.
//
// Guion (MCSTORE_SCRIPT), una orden por línea, el número es el fotograma:
//   <n> hold CROSS+DOWN     -> mantiene esos botones desde el fotograma n (hold NONE = soltar)
//   <n> shot nombre         -> guarda MCSTORE_OUT/nombre.ppm
//   <n> exit                -> termina
#include "../../app/src/platform.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <vector>
#include <string>

struct Step { int frame; std::string cmd, arg; };
static std::vector<Step> g_steps;
static uint32_t g_fbs[2][SCREEN_W * SCREEN_H];
static int g_cur = 0, g_frame = 0;
static uint32_t g_mask = 0;
static size_t g_next = 0;

static uint32_t parse_mask(const std::string &s) {
    static const struct { const char *n; uint32_t b; } T[] = {
        {"UP", BTN_UP}, {"DOWN", BTN_DOWN}, {"LEFT", BTN_LEFT}, {"RIGHT", BTN_RIGHT},
        {"CROSS", BTN_CROSS}, {"CIRCLE", BTN_CIRCLE}, {"SQUARE", BTN_SQUARE},
        {"TRIANGLE", BTN_TRIANGLE}, {"L1", BTN_L1}, {"R1", BTN_R1}, {"OPTIONS", BTN_OPTIONS}, {"R2", BTN_R2}};
    uint32_t m = 0;
    size_t i = 0;
    while (i <= s.size()) {
        size_t j = s.find('+', i);
        if (j == std::string::npos) j = s.size();
        std::string tok = s.substr(i, j - i);
        for (auto &t : T) if (tok == t.n) m |= t.b;
        i = j + 1;
    }
    return m;
}

static void apply_due() {
    while (g_next < g_steps.size() && g_steps[g_next].frame <= g_frame) {
        const Step &s = g_steps[g_next];
        if (s.cmd == "hold") g_mask = parse_mask(s.arg);
        else if (s.cmd == "shot") {
            const char *out = getenv("MCSTORE_OUT");
            std::string path = std::string(out ? out : ".") + "/" + s.arg + ".ppm";
            FILE *f = fopen(path.c_str(), "wb");
            if (f) {
                fprintf(f, "P6\n%d %d\n255\n", SCREEN_W, SCREEN_H);
                for (int i = 0; i < SCREEN_W * SCREEN_H; i++) {
                    uint32_t c = g_fbs[g_cur][i];
                    unsigned char px[3] = {(unsigned char)(c >> 16), (unsigned char)(c >> 8), (unsigned char)c};
                    fwrite(px, 1, 3, f);
                }
                fclose(f);
            }
        } else if (s.cmd == "exit") {
            exit(0);
        }
        g_next++;
    }
}

bool plat_init() {
    const char *sp = getenv("MCSTORE_SCRIPT");
    if (sp) {
        FILE *f = fopen(sp, "r");
        char a[64], b[128];
        int n;
        while (f && fscanf(f, "%d %63s %127s", &n, a, b) == 3) g_steps.push_back({n, a, b});
        if (f) fclose(f);
    }
    return true;
}

uint32_t plat_buttons() { apply_due(); return g_mask; }
uint32_t *plat_framebuffer() { return g_fbs[g_cur]; }
void plat_present() {
    apply_due();
    g_frame++;
    g_cur ^= 1;
    usleep(16000);  // ~60 fps, como el vsync de la PS4
    if (g_frame > 200000) exit(3);  // seguro contra bucles infinitos
}
void plat_sleep_ms(int ms) { usleep((useconds_t)ms * 1000); }
uint64_t plat_ms() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000 + (uint64_t)ts.tv_nsec / 1000000;
}
const char *plat_data_dir() {
    const char *d = getenv("MCSTORE_DATA");
    return d ? d : "./hosttest_data";
}

int plat_https_get(const char *, char **, long *, long, FILE *, PlatProgressCb, void *, char *err, size_t errcap) {
    snprintf(err, errcap, "HTTPS no disponible en la prueba de PC (usa http://)");
    return -1;
}

const char *plat_apptmp_dir() {
    const char *d = getenv("MCSTORE_APPTMP");
    return d ? d : "/app_tmp";
}

bool plat_stat(const char *path, bool *isDir, long *size) {
    struct stat st;
    if (stat(path, &st) != 0) return false;
    *isDir = S_ISDIR(st.st_mode);
    *size = (long)st.st_size;
    return true;
}

bool plat_listdir(const char *path, PlatDirCb cb, void *ctx) {
    DIR *d = opendir(path);
    if (!d) return false;
    while (struct dirent *e = readdir(d))
        if (strcmp(e->d_name, ".") && strcmp(e->d_name, "..")) cb(e->d_name, ctx);
    closedir(d);
    return true;
}

bool plat_game_in_background() { const char *b = getenv("MCSTORE_BG"); return b && *b == '1'; }
int plat_resume_game(const char *cusa) { fprintf(stderr, "[host] resume %s\n", cusa); return 0; }
