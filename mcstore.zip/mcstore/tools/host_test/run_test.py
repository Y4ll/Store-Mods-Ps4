#!/usr/bin/env python3
"""Prueba de extremo a extremo en PC: servidor real + app compilada con la plataforma falsa.
Uso: python3 tools/host_test/run_test.py <carpeta_de_trabajo>
Genera capturas PNG y comprueba que la descarga llega byte a byte igual.
"""
import hashlib, json, os, subprocess, sys, time, shutil, socket
from PIL import Image

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
work = os.path.abspath(sys.argv[1]); shutil.rmtree(work, ignore_errors=True); os.makedirs(work)
files, data, out = [os.path.join(work, d) for d in ("files", "data", "shots")]
for d in (files, data, out): os.makedirs(d)

# --- binario ---
exe = os.path.join(work, "mcstore_host")
subprocess.check_call(["clang++", "-std=c++17", "-O1", "-Wno-unused-function", "-o", exe,
                       os.path.join(ROOT, "app/src/main.cpp"),
                       os.path.join(ROOT, "tools/host_test/platform_host.cpp")])

# --- contenido de prueba ---
blobs = {"ultra_pack.mcpack": 3_000_000, "Muebles Ñandú.mcaddon": 500_000, "mi mundo.mcworld": 2_000_000}
for n, sz in blobs.items():
    with open(os.path.join(files, n), "wb") as f: f.write(os.urandom(sz))
cat = os.path.join(work, "catalog.json")
json.dump([{"name": "Dragones épicos", "summary": "Catálogo con acentos: añade dragones, árboles y más. " * 3,
            "url": "http://127.0.0.1:8099/x.mcpack"}], open(cat, "w"))

env = dict(os.environ, MCSTORE_FILES=files, MCSTORE_CATALOG=cat)
srv = subprocess.Popen([sys.executable, os.path.join(ROOT, "server/server.py"), "8080"], env=env,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for _ in range(50):
    try: socket.create_connection(("127.0.0.1", 8080), 0.2).close(); break
    except OSError: time.sleep(0.1)

def script(steps):
    lines, f = [], 3
    def press(*b):
        nonlocal f
        lines.append("%d hold %s" % (f, "+".join(b))); lines.append("%d hold NONE" % (f + 2)); f += 5
    return lines, press, (lambda: f), (lambda n: lines.append("%d shot %s" % (f, n)))

def run(name, build, data_dir, extra_env=None):
    lines = []; fr = [3]
    def press(*b):
        lines.append("%d hold %s" % (fr[0], "+".join(b))); lines.append("%d hold NONE" % (fr[0] + 2)); fr[0] += 5
    def shot(n): lines.append("%d shot %s" % (fr[0], n)); fr[0] += 3
    build(press, shot)
    lines.append("%d exit x" % fr[0])
    sp = os.path.join(work, name + ".script"); open(sp, "w").write("\n".join(lines) + "\n")
    e = dict(os.environ, MCSTORE_SCRIPT=sp, MCSTORE_OUT=out, MCSTORE_DATA=data_dir)
    r = subprocess.run([exe], env=e, timeout=120)
    assert r.returncode == 0, "la app termino con codigo %s" % r.returncode

# 1) primera vez: sin config -> pantalla de ajustes
run("first", lambda p, s: (s("1_ajustes_primera_vez"), p("RIGHT"), p("UP"), p("UP"), s("1b_ajustes_editado")), os.path.join(work, "data_first"))

# 2) con config: listar, navegar, buscar con teclado, descargar
os.makedirs(os.path.join(data, "x"), exist_ok=True)
open(os.path.join(data, "config.txt"), "w").write("127.0.0.1:8080\n")
def flow(p, s):
    s("2_lista_inicial")
    p("DOWN"); p("DOWN"); s("3_lista_seleccion")
    p("SQUARE"); p("DOWN"); p("RIGHT"); p("RIGHT"); p("RIGHT"); p("RIGHT"); p("RIGHT"); p("CROSS")  # 'p'
    p("UP"); p("DOWN"); p("DOWN"); p("DOWN"); p("LEFT"); p("LEFT"); p("LEFT"); p("LEFT"); p("LEFT"); p("LEFT"); p("CROSS") # prueba movimiento (letra extra)
    s("4_teclado"); p("SQUARE"); p("OPTIONS"); s("5_resultados_filtrados")
    p("CROSS"); s("6_tras_descarga")
run("flow", flow, data)

# 3) servidor caido -> error visible
srv.terminate(); srv.wait()
run("down", lambda p, s: (p("L1"), p("L1"), s("7_servidor_caido")), data)

# --- verificación ---
dl = os.path.join(data, "downloads")
print("Descargas:", os.listdir(dl) if os.path.isdir(dl) else "NINGUNA")
ok = True
for n in (os.listdir(dl) if os.path.isdir(dl) else []):
    a = hashlib.sha256(open(os.path.join(dl, n), "rb").read()).hexdigest()
    src = os.path.join(files, n)
    b = hashlib.sha256(open(src, "rb").read()).hexdigest() if os.path.exists(src) else None
    print(" ", n, "OK" if a == b else "DISTINTO/sin origen"); ok &= (a == b)
ok &= bool(os.path.isdir(dl) and os.listdir(dl))
for n in sorted(os.listdir(out)):
    if n.endswith(".ppm"):
        im = Image.open(os.path.join(out, n)); im.save(os.path.join(out, n[:-4] + ".png")); os.remove(os.path.join(out, n))
print("RESULTADO:", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
