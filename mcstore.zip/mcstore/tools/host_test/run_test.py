#!/usr/bin/env python3
"""Prueba de extremo a extremo en PC: servidor real + app compilada con la plataforma falsa.
Uso: python3 tools/host_test/run_test.py <carpeta_de_trabajo>
Genera capturas PNG y comprueba que la descarga llega byte a byte igual.
"""
import hashlib, json, os, subprocess, sys, time, shutil, socket
from PIL import Image

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
work = os.path.abspath(sys.argv[1]); shutil.rmtree(work, ignore_errors=True); os.makedirs(work)
files, data, out = [os.path.join(work, d) for d in ("files", "data", "shots")]
for d in (files, data, out): os.makedirs(d)

# --- binario ---
exe = os.path.join(work, "mcstore_host")
subprocess.check_call(["clang++", "-std=c++17", "-O1", "-pthread", "-Wno-unused-function", "-DCATALOG_URL=\"http://127.0.0.1:8099/catalog.json\"", "-o", exe,
                       os.path.join(ROOT, "app/src/main.cpp"),
                       os.path.join(ROOT, "tools/host_test/platform_host.cpp")])

# --- contenido de prueba ---
blobs = {"ultra_pack.mcpack": 3_000_000, "Muebles Ñandú.mcaddon": 500_000, "mi mundo.mcworld": 2_000_000}
for n, sz in blobs.items():
    with open(os.path.join(files, n), "wb") as f: f.write(os.urandom(sz))
cat = os.path.join(work, "catalog.json")
json.dump([{"name": "Dragones épicos", "summary": "Catálogo con acentos: añade dragones, árboles y más. " * 3,
            "url": "http://127.0.0.1:8099/x.mcpack"}], open(cat, "w"))

gh = os.path.join(work, "gh"); os.makedirs(os.path.join(gh, "addons"))
gh_blobs = {"Pack Uno.mcpack": 1_500_000, "dragones.mcaddon": 700_000}
for n, sz in gh_blobs.items():
    with open(os.path.join(gh, "addons", n), "wb") as f: f.write(os.urandom(sz))
json.dump([
    {"name": "Pack Uno", "summary": "Primer pack de prueba (ruta relativa con espacio)", "url": "addons/Pack Uno.mcpack", "size": 1_500_000},
    {"name": "Dragones", "summary": "Add-on de dragones; sin size ni file", "url": "addons/dragones.mcaddon"},
    {"name": "Solo archivo", "summary": "Usa solo 'file': la app arma addons/<file>", "file": "dragones.mcaddon"},
], open(os.path.join(gh, "catalog.json"), "w"))
ghsrv = subprocess.Popen([sys.executable, "-m", "http.server", "8099", "--bind", "127.0.0.1", "--directory", gh],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for _ in range(50):
    try: socket.create_connection(("127.0.0.1", 8099), 0.2).close(); break
    except OSError: time.sleep(0.1)

env = dict(os.environ, MCSTORE_FILES=files, MCSTORE_CATALOG=cat)
srv = subprocess.Popen([sys.executable, os.path.join(ROOT, "server/server.py"), "8080"], env=env,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for _ in range(50):
    try: socket.create_connection(("127.0.0.1", 8080), 0.2).close(); break
    except OSError: time.sleep(0.1)

def script(steps):
    lines, f = [], 3
    def press(*b):
        nonlocal f
        lines.append("%d hold %s" % (f, "+".join(b))); lines.append("%d hold NONE" % (f + 2)); f += 5
    return lines, press, (lambda: f), (lambda n: lines.append("%d shot %s" % (f, n)))

def run(name, build, data_dir, extra_env=None):
    lines = []; fr = [3]
    def press(*b):
        lines.append("%d hold %s" % (fr[0], "+".join(b))); lines.append("%d hold NONE" % (fr[0] + 2)); fr[0] += 5
    def shot(n): lines.append("%d shot %s" % (fr[0], n)); fr[0] += 3
    def wait(n): fr[0] += n
    build(press, shot, wait)
    lines.append("%d exit x" % fr[0])
    sp = os.path.join(work, name + ".script"); open(sp, "w").write("\n".join(lines) + "\n")
    e = dict(os.environ, MCSTORE_SCRIPT=sp, MCSTORE_OUT=out, MCSTORE_DATA=data_dir)
    r = subprocess.run([exe], env=e, timeout=120)
    assert r.returncode == 0, "la app termino con codigo %s" % r.returncode

# 1) sin config: lista desde el catalogo "GitHub" (aqui servido por http.server); ajustes con selector de fuente
data_gh = os.path.join(work, "data_gh")
def gh_flow(p, s, w):
    w(40); s("1_github_lista")
    p("DOWN"); s("1b_github_seleccion")
    p("TRIANGLE"); s("1c_ajustes"); p("DOWN"); s("1d_ajustes_fuente_pc"); p("DOWN"); p("RIGHT"); p("UP"); p("UP"); s("1e_ajustes_ip"); p("CIRCLE")
    p("SQUARE"); p("DOWN"); p("RIGHT"); p("RIGHT"); p("RIGHT"); p("RIGHT"); p("RIGHT"); p("CROSS")  # 'p'
    p("OPTIONS"); s("1f_filtro_local_p")
    p("CROSS"); w(8); s("1g_descargando"); w(100); s("1h_tras_descarga")
run("gh", gh_flow, data_gh)

# 2) con config: listar, navegar, buscar con teclado, descargar
os.makedirs(os.path.join(data, "x"), exist_ok=True)
open(os.path.join(data, "config.txt"), "w").write("127.0.0.1:8080\n1\n")
def flow(p, s, w):
    w(40); s("2_lista_inicial")
    p("DOWN"); p("DOWN"); s("3_lista_seleccion")
    p("SQUARE"); p("DOWN"); p("RIGHT"); p("RIGHT"); p("RIGHT"); p("RIGHT"); p("RIGHT"); p("CROSS")  # 'p'
    p("UP"); p("DOWN"); p("DOWN"); p("DOWN"); p("LEFT"); p("LEFT"); p("LEFT"); p("LEFT"); p("LEFT"); p("LEFT"); p("CROSS") # letra extra
    s("4_teclado"); p("SQUARE"); p("OPTIONS"); w(40); s("5_resultados_filtrados")
    p("CROSS"); w(8); s("6a_descargando"); w(150); s("6_tras_descarga")
run("flow", flow, data)

# 3) servidor caido -> error visible
srv.terminate(); srv.wait()
run("down", lambda p, s, w: (w(40), s("7_servidor_caido")), data)


# 4) servidor colgado (acepta y no responde): la pantalla debe seguir viva y poder cancelarse
hang_sock = socket.socket(); hang_sock.bind(("127.0.0.1", 8081)); hang_sock.listen(5)
hang_data = os.path.join(work, "data_hang"); os.makedirs(hang_data)
open(os.path.join(hang_data, "config.txt"), "w").write("127.0.0.1:8081\n1\n")
run("hang", lambda p, s, w: (w(25), s("8_colgado_buscando"), p("CROSS"), s("8b_ignora_botones"), p("CIRCLE"), w(3), s("9_cancelado"), p("TRIANGLE"), s("10_ajustes_tras_cancelar")), hang_data)
hang_sock.close()

# --- verificación ---
ghsrv.terminate()
def check(dl, srcs, label):
    names = os.listdir(dl) if os.path.isdir(dl) else []
    print(label, "descargas:", names or "NINGUNA")
    good = bool(names)
    for n in names:
        h1 = hashlib.sha256(open(os.path.join(dl, n), "rb").read()).hexdigest()
        src = [os.path.join(d, n) for d in srcs if os.path.exists(os.path.join(d, n))]
        h2 = hashlib.sha256(open(src[0], "rb").read()).hexdigest() if src else None
        print("  ", n, "OK" if h1 == h2 else "DISTINTO/sin origen"); good &= (h1 == h2)
    return good
ok = check(os.path.join(data, "downloads"), [files], "LAN")
ok &= check(os.path.join(data_gh, "downloads"), [os.path.join(gh, "addons")], "GitHub")
for n in sorted(os.listdir(out)):
    if n.endswith(".ppm"):
        im = Image.open(os.path.join(out, n)); im.save(os.path.join(out, n[:-4] + ".png")); os.remove(os.path.join(out, n))
print("RESULTADO:", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
