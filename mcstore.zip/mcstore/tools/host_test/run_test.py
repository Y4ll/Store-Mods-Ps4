#!/usr/bin/env python3
"""Prueba de extremo a extremo en PC: servidor real + app compilada con la plataforma falsa.
Uso: python3 tools/host_test/run_test.py <carpeta_de_trabajo>
Genera capturas PNG y comprueba que la descarga llega byte a byte igual.
"""
import hashlib, json, os, subprocess, sys, time, shutil, socket, zipfile
from PIL import Image

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
work = os.path.abspath(sys.argv[1]); shutil.rmtree(work, ignore_errors=True); os.makedirs(work)
files, data, out = [os.path.join(work, d) for d in ("files", "data", "shots")]
for d in (files, data, out): os.makedirs(d)

# --- binario ---
exe = os.path.join(work, "mcstore_host")
subprocess.check_call(["g++", "-std=c++17", "-O1", "-pthread", "-w", "-DMCSTORE_NOSPLASH", "-DCATALOG_URL=\"http://127.0.0.1:8099/catalog.json\"", "-o", exe,
                       os.path.join(ROOT, "app/src/main.cpp"),
                       os.path.join(ROOT, "tools/host_test/platform_host.cpp")])

# --- contenido de prueba ---
blobs = {"ultra_pack.mcpack": 3_000_000, "Muebles Ñandú.mcaddon": 500_000, "mi mundo.mcworld": 2_000_000}
for n, sz in blobs.items():
    with open(os.path.join(files, n), "wb") as f: f.write(os.urandom(sz))
cat = os.path.join(work, "catalog.json")
json.dump([{"name": "Dragones épicos", "summary": "Catálogo con acentos: añade dragones, árboles y más. " * 3,
            "url": "http://127.0.0.1:8099/x.mcpack"}], open(cat, "w"))

gh = os.path.join(work, "gh"); os.makedirs(os.path.join(gh, "addons"))
gh_blobs = {"Pack Uno.mcpack": 1_500_000, "dragones.mcaddon": 700_000}
for n, sz in gh_blobs.items():
    with open(os.path.join(gh, "addons", n), "wb") as f: f.write(os.urandom(sz))
json.dump([
    {"name": "Pack Uno", "summary": "Primer pack de prueba (ruta relativa con espacio)", "url": "addons/Pack Uno.mcpack", "size": 1_500_000},
    {"name": "Dragones", "summary": "Add-on de dragones; sin size ni file", "url": "addons/dragones.mcaddon"},
    {"name": "Solo archivo", "summary": "Usa solo 'file': la app arma addons/<file>", "file": "dragones.mcaddon"},
], open(os.path.join(gh, "catalog.json"), "w"))
json.dump([{"name": "9.0", "summary": "Version de prueba", "url": "McStore.pkg", "size": 1000}], open(os.path.join(gh, "app_update.json"), "w"))
ghsrv = subprocess.Popen([sys.executable, "-m", "http.server", "8099", "--bind", "127.0.0.1", "--directory", gh],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for _ in range(50):
    try: socket.create_connection(("127.0.0.1", 8099), 0.2).close(); break
    except OSError: time.sleep(0.1)

env = dict(os.environ, MCSTORE_FILES=files, MCSTORE_CATALOG=cat)
srv = subprocess.Popen([sys.executable, os.path.join(ROOT, "server/server.py"), "8080"], env=env,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for _ in range(50):
    try: socket.create_connection(("127.0.0.1", 8080), 0.2).close(); break
    except OSError: time.sleep(0.1)

def script(steps):
    lines, f = [], 3
    def press(*b):
        nonlocal f
        lines.append("%d hold %s" % (f, "+".join(b))); lines.append("%d hold NONE" % (f + 2)); f += 5
    return lines, press, (lambda: f), (lambda n: lines.append("%d shot %s" % (f, n)))

def run(name, build, data_dir, extra_env=None):
    lines = []; fr = [3]
    def press(*b):
        lines.append("%d hold %s" % (fr[0], "+".join(b))); lines.append("%d hold NONE" % (fr[0] + 2)); fr[0] += 5
    def shot(n): lines.append("%d shot %s" % (fr[0], n)); fr[0] += 3
    def wait(n): fr[0] += n
    build(press, shot, wait)
    lines.append("%d exit x" % fr[0])
    sp = os.path.join(work, name + ".script"); open(sp, "w").write("\n".join(lines) + "\n")
    e = dict(os.environ, MCSTORE_SCRIPT=sp, MCSTORE_OUT=out, MCSTORE_DATA=data_dir)
    if extra_env: e.update(extra_env)
    r = subprocess.run([exe], env=e, timeout=120)
    assert r.returncode == 0, "la app termino con codigo %s" % r.returncode

# 1) sin config: lista desde el catalogo "GitHub" (aqui servido por http.server); ajustes con selector de fuente
data_gh = os.path.join(work, "data_gh")
def gh_flow(p, s, w):
    w(40); s("1_github_lista"); w(60); s("1_aviso_version")
    p("DOWN"); s("1b_github_seleccion")
    p("TRIANGLE"); s("1c_ajustes"); p("DOWN"); s("1d_ajustes_fuente_pc"); p("DOWN"); p("RIGHT"); p("UP"); p("UP"); s("1e_ajustes_ip"); p("CIRCLE")
    p("SQUARE"); p("DOWN"); p("RIGHT"); p("RIGHT"); p("RIGHT"); p("RIGHT"); p("RIGHT"); p("CROSS")  # 'p'
    p("OPTIONS"); s("1f_filtro_local_p")
    p("CROSS"); w(40); p("CROSS"); w(8); s("1g_descargando"); w(100); s("1h_tras_descarga")
run("gh", gh_flow, data_gh)

# 2) con config: listar, navegar, buscar con teclado, descargar
os.makedirs(os.path.join(data, "x"), exist_ok=True)
open(os.path.join(data, "config.txt"), "w").write("127.0.0.1:8080\n1\n")
def flow(p, s, w):
    w(40); s("2_lista_inicial")
    p("DOWN"); p("DOWN"); s("3_lista_seleccion")
    p("SQUARE"); p("DOWN"); p("RIGHT"); p("RIGHT"); p("RIGHT"); p("RIGHT"); p("RIGHT"); p("CROSS")  # 'p'
    p("UP"); p("DOWN"); p("DOWN"); p("DOWN"); p("LEFT"); p("LEFT"); p("LEFT"); p("LEFT"); p("LEFT"); p("LEFT"); p("CROSS") # letra extra
    s("4_teclado"); p("SQUARE"); p("OPTIONS"); w(40); s("5_resultados_filtrados")
    p("CROSS"); w(40); p("CROSS"); w(8); s("6a_descargando"); w(150); s("6_tras_descarga")
run("flow", flow, data)

# 3) servidor caido -> error visible
srv.terminate(); srv.wait()
run("down", lambda p, s, w: (w(40), s("7_servidor_caido")), data)


# 4) servidor colgado (acepta y no responde): la pantalla debe seguir viva y poder cancelarse
hang_sock = socket.socket(); hang_sock.bind(("127.0.0.1", 8081)); hang_sock.listen(5)
hang_data = os.path.join(work, "data_hang"); os.makedirs(hang_data)
open(os.path.join(hang_data, "config.txt"), "w").write("127.0.0.1:8081\n1\n")
run("hang", lambda p, s, w: (w(25), s("8_colgado_buscando"), p("CROSS"), s("8b_ignora_botones"), p("CIRCLE"), w(3), s("9_cancelado"), p("TRIANGLE"), s("10_ajustes_tras_cancelar")), hang_data)
hang_sock.close()

# 5) instalacion en Minecraft (carpeta /app_tmp falsa)
def manifest(types, name, mn):
    return json.dumps({"format_version": 2, "header": {"name": name, "uuid": "11111111-1111-1111-1111-111111111111", "version": [1, 0, 0], "min_engine_version": mn},
                       "modules": [{"type": t, "uuid": "22222222-2222-2222-2222-22222222222%d" % i, "version": [1, 0, 0]} for i, t in enumerate(types)]})
def mkpack(path, types, name, mn, pad=300_000):
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", manifest(types, name, mn))
        z.writestr("pack_icon.png", os.urandom(pad))
data_inst = os.path.join(work, "data_inst"); dl = os.path.join(data_inst, "downloads"); os.makedirs(dl)
open(os.path.join(data_inst, "mcversion.txt"), "w").write("1.26.51\n")
open(os.path.join(data_inst, "config.txt"), "w").write("127.0.0.1:1\n1\n")   # LAN sin servidor: la lista queda vacia, no molesta
mkpack(os.path.join(dl, "textura.mcpack"), ["resources"], "Textura", [1, 21, 0])
mkpack(os.path.join(dl, "viejo.mcpack"), ["resources"], "Viejo", [1, 20, 80], 100_000)
mkpack(os.path.join(dl, "comp.mcpack"), ["data", "script"], "Comp", [1, 26, 60], 50_000)
mkpack(os.path.join(dl, "mezcla.mcpack"), ["resources", "data"], "Mezcla", [1, 21, 0], 1000)
open(os.path.join(dl, "addon.mcaddon"), "wb").write(os.urandom(2000))
open(os.path.join(dl, "mundo.mcworld"), "wb").write(os.urandom(2000))
open(os.path.join(dl, "medio.mcpack.part"), "wb").write(b"x")   # una descarga a medias: no debe aparecer
SUBS = ["behavior_packs", "resource_packs", "development_behavior_packs", "development_resource_packs", "development_skin_packs", "world_templates"]
def mkmoj(base, subs=SUBS):
    for sdir in subs: os.makedirs(os.path.join(base, "games", "com.mojang", sdir), exist_ok=True)
def tree(name):
    root = os.path.join(work, name); shutil.rmtree(root, ignore_errors=True); os.makedirs(root); return root
def moj(root, cusa, user): return os.path.join(root, cusa, user, "games", "com.mojang")
def user_tree(name):
    r = tree(name)
    mkmoj(os.path.join(r, "CUSA00744", "user355479251"))
    mkmoj(os.path.join(r, "CUSA00744", "user999000111"))
    mkmoj(os.path.join(r, "CUSA09999", "user1"), ["resource_packs"])  # CUSA desconocido y sin behavior_packs: no debe usarse
    return r
def go_install(p, s, w, downs):
    p("R2"); s("i_0_lista")
    for _ in range(downs): p("DOWN")

# 5a) Minecraft cerrado: aviso y no se copia nada
r_nogame = tree("apptmp_nogame")
run("i_nogame", lambda p, s, w: (go_install(p, s, w, 4), p("CROSS"), s("i_1_nogame")), data_inst, {"MCSTORE_APPTMP": r_nogame})

# 5b) flujo completo
r_flow = user_tree("apptmp_flow")
def flow_inst(p, s, w):
    p("R2"); s("i_2_lista"); p("DOWN")                       # comp.mcpack (pide 1.26.60 > 1.26.51)
    p("CROSS"); s("i_3_version"); p("CIRCLE"); s("i_3b_cancelado")
    p("CROSS"); p("CROSS"); w(10); s("i_4_hecho"); p("CROSS")
    p("DOWN"); p("CROSS"); s("i_5_mezcla"); p("CROSS")        # mezcla: error
    p("DOWN"); p("CROSS"); s("i_6_mundo")                      # .mcworld: no soportado
    p("DOWN"); p("CROSS"); w(10); s("i_7_textura"); p("CROSS")
    p("DOWN"); p("CROSS"); w(10); p("CROSS")                   # viejo.mcpack
    for _ in range(5): p("UP")
    p("CROSS"); s("i_8_addon")
run("i_flow", flow_inst, data_inst, {"MCSTORE_APPTMP": r_flow})

# 5c) ya existe: cancelar deja el archivo viejo; reemplazar lo cambia
def preseed(root):
    d = os.path.join(moj(root, "CUSA00744", "user355479251"), "resource_packs"); open(os.path.join(d, "textura.mcpack"), "wb").write(b"VIEJO")
r_cancel = user_tree("apptmp_cancel"); preseed(r_cancel)
run("i_cancel", lambda p, s, w: (go_install(p, s, w, 4), p("CROSS"), s("i_9_existe"), p("CIRCLE"), s("i_9b_cancelado")), data_inst, {"MCSTORE_APPTMP": r_cancel})
r_repl = user_tree("apptmp_repl"); preseed(r_repl)
run("i_replace", lambda p, s, w: (go_install(p, s, w, 4), p("CROSS"), p("CROSS"), w(10), s("i_10_reemplazado")), data_inst, {"MCSTORE_APPTMP": r_repl})

# 5d) sin carpeta user* ni CUSA conocido: se usa cualquier carpeta de /app_tmp con games/com.mojang
r_fb = tree("apptmp_fallback"); mkmoj(os.path.join(r_fb, "CUSA12345")); os.makedirs(os.path.join(r_fb, "OTRA_COSA", "x"))
run("i_fallback", lambda p, s, w: (go_install(p, s, w, 4), p("CROSS"), w(10), s("i_11_fallback")), data_inst, {"MCSTORE_APPTMP": r_fb})

# --- verificación ---
ghsrv.terminate()
def check(dl, srcs, label):
    names = os.listdir(dl) if os.path.isdir(dl) else []
    print(label, "descargas:", names or "NINGUNA")
    good = bool(names)
    for n in names:
        h1 = hashlib.sha256(open(os.path.join(dl, n), "rb").read()).hexdigest()
        src = [os.path.join(d, n) for d in srcs if os.path.exists(os.path.join(d, n))]
        h2 = hashlib.sha256(open(src[0], "rb").read()).hexdigest() if src else None
        print("  ", n, "OK" if h1 == h2 else "DISTINTO/sin origen"); good &= (h1 == h2)
    return good
ok = check(os.path.join(data, "downloads"), [files], "LAN")
ok &= check(os.path.join(data_gh, "downloads"), [os.path.join(gh, "addons")], "GitHub")

def same(a, b): return os.path.exists(a) and os.path.exists(b) and open(a, "rb").read() == open(b, "rb").read()
def lsr(root):
    out = []
    for d, _, fs in os.walk(root):
        for f in fs: out.append(os.path.relpath(os.path.join(d, f), root))
    return sorted(out)
def expect(label, cond):
    global ok
    print("  ", "OK " if cond else "MAL", label); ok &= bool(cond)
print("INSTALAR")
expect("minecraft cerrado: no se copio nada", lsr(r_nogame) == [])
for u in ("user355479251", "user999000111"):
    m = moj(r_flow, "CUSA00744", u)
    expect("flujo %s: comp.mcpack -> behavior_packs (igual al original)" % u, same(os.path.join(m, "behavior_packs", "comp.mcpack"), os.path.join(dl, "comp.mcpack")))
    expect("flujo %s: textura.mcpack -> resource_packs" % u, same(os.path.join(m, "resource_packs", "textura.mcpack"), os.path.join(dl, "textura.mcpack")))
    expect("flujo %s: viejo.mcpack -> resource_packs" % u, same(os.path.join(m, "resource_packs", "viejo.mcpack"), os.path.join(dl, "viejo.mcpack")))
files_flow = [f for f in lsr(r_flow)]
expect("flujo: solo 6 archivos copiados (2 usuarios x 3 packs), ni mezcla, ni mcaddon, ni mcworld, ni .part", len(files_flow) == 6 and not any(".part" in f or "zip" in f or "mezcla" in f or "addon" in f or "mundo" in f for f in files_flow))
expect("flujo: el CUSA desconocido sin behavior_packs no se uso", not any(f.startswith("CUSA09999") for f in files_flow))
expect("flujo: las carpetas development_* quedaron vacias", not any("development" in f or "world_templates" in f for f in files_flow))
c1 = os.path.join(moj(r_cancel, "CUSA00744", "user355479251"), "resource_packs", "textura.mcpack")
expect("cancelar el reemplazo deja el archivo viejo y no copia al otro usuario", open(c1, "rb").read() == b"VIEJO" and len(lsr(r_cancel)) == 1)
for u in ("user355479251", "user999000111"):
    expect("reemplazar %s" % u, same(os.path.join(moj(r_repl, "CUSA00744", u), "resource_packs", "textura.mcpack"), os.path.join(dl, "textura.mcpack")))
expect("fallback: instalo en la carpeta com.mojang sin user*", same(os.path.join(moj(r_fb, "CUSA12345", "").rstrip("/"), "resource_packs", "textura.mcpack"), os.path.join(dl, "textura.mcpack")) if False else same(os.path.join(r_fb, "CUSA12345", "games", "com.mojang", "resource_packs", "textura.mcpack"), os.path.join(dl, "textura.mcpack")) and len(lsr(r_fb)) == 1)
for n in sorted(os.listdir(out)):
    if n.endswith(".ppm"):
        im = Image.open(os.path.join(out, n)); im.save(os.path.join(out, n[:-4] + ".png")); os.remove(os.path.join(out, n))
print("RESULTADO:", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
