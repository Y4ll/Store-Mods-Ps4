// Idioma ES/EN. El texto del programa esta en espanol; con g_lang=1 tr() lo cambia al ingles
// buscando la frase completa en la tabla (los %d/%s/%lu de la frase se comportan como comodines
// y se copian en el mismo orden). Lo que no esta en la tabla se muestra tal cual.
#pragma once
#include <string.h>
#include <stdio.h>

static int g_lang = 0;  // 0 = espanol, 1 = ingles

struct TrEntry { const char *es, *en; };
static const TrEntry TR_TAB[] = {
    {" (se omitieron los que no son .mcpack)", " (non-.mcpack files skipped)"},
    {"%d add-on(s). Pulsa X para descargar.", "%d add-on(s). Press X to download."},
    {"%d archivo(s)", "%d file(s)"},
    {"%s  |  Requiere Minecraft %d.%d.%d o mas nuevo", "%s  |  Requires Minecraft %d.%d.%d or newer"},
    {"%s  |  Sin min_engine_version", "%s  |  No min_engine_version"},
    {"%s / %s   %lus   (Circulo: cancelar)", "%s / %s   %lus   (Circle: cancel)"},
    {"(ilegible)", "(unreadable)"},
    {"(sin nombre)", "(no name)"},
    {"(todo)", "(all)"},
    {"Addon -> carpetas BP/RP", "Addon -> BP/RP folders"},
    {"%s  |  trae %s%s", "%s  |  contains %s%s"},
    {"  |  Requiere Minecraft %d.%d.%d o mas nuevo", "  |  Requires Minecraft %d.%d.%d or newer"},
    {"Addon instalado: %d pack(s) en %d carpeta(s) de usuario.", "Addon installed: %d pack(s) in %d user folder(s)."},
    {"2) Activa Recursos Y Comportamiento en el mundo, y los Experimentos.", "2) Turn on BOTH Resource and Behavior packs in the world, plus Experiments."},
    {"behavior_packs / resource_packs", "behavior_packs / resource_packs"},
    {"Formato no soportado: solo .mcpack y .mcaddon.", "Unsupported format: only .mcpack and .mcaddon."},
    {"1) Cierra y vuelve a abrir Minecraft para que el pack aparezca.", "1) Close and reopen Minecraft so the pack shows up."},
    {"1) Cierra y vuelve a abrir Minecraft para que los packs aparezcan.", "1) Close and reopen Minecraft so the packs show up."},
    {"2) Activalo en el mundo (Recursos o Comportamiento).", "2) Enable it in your world (Resource or Behavior)."},
    {"2) Activalos en el mundo (Recursos o Comportamiento).", "2) Enable them in your world (Resource or Behavior)."},
    {"Abrelo hasta el menu, pulsa PS y abre McStore (sin cerrarlo).", "Open it to the menu, press PS and open McStore (do not close it)."},
    {"Abrir el detalle (foto, descripcion y descargar)", "Open details (picture, description, download)"},
    {"Actualizado", "Updated"},
    {"Actualizado en el catalogo: pulsa X para bajarlo", "Updated in the catalog: press X to get it"},
    {"Actualizar la lista", "Refresh the list"},
    {"Add-ons para Minecraft Bedrock", "Add-ons for Minecraft Bedrock"},
    {"Add-ons para Minecraft Bedrock  -  bienvenido", "Add-ons for Minecraft Bedrock  -  welcome"},
    {"Ajustes", "Settings"},
    {"Ajustes (de donde salen los add-ons)", "Settings (where add-ons come from)"},
    {"Amatista", "Amethyst"},
    {"Aplicar o guardar", "Apply or save"},
    {"Archivo: %s", "File: %s"},
    {"Arriba / Abajo", "Up / Down"},
    {"Arriba/Abajo: fila | Izq/Der o X: cambiar | Circulo: volver (se guarda)", "Up/Down: row | Left/Right or X: change | Circle: back (saved)"},
    {"Arriba/Abajo: fila | Izq/Der: cambiar | X o Circulo: aplicar y volver | Triangulo: quitar filtros", "Up/Down: row | Left/Right: change | X or Circle: apply and back | Triangle: clear filters"},
    {"Arriba/Abajo: leer | L1/R1: pagina | Circulo o X: volver", "Up/Down: read | L1/R1: page | Circle or X: back"},
    {"BUSCAR (TECLADO)", "SEARCH (KEYBOARD)"},
    {"Bajar todo lo nuevo y actualizado", "Download everything new and updated"},
    {"Bloques", "Blocks"},
    {"Borrado.", "Deleted."},
    {"Borrados %d archivos.", "Deleted %d files."},
    {"Borrar archivo", "Delete file"},
    {"Borrar el pack elegido de las descargas", "Delete the selected pack from downloads"},
    {"Borrar la ultima letra", "Delete the last letter"},
    {"Borrar todas las descargas (y, al terminar, volver a Minecraft)", "Delete all downloads (then return to Minecraft)"},
    {"Borrar todo", "Delete all"},
    {"Buscando actualizacion de McStore...", "Looking for a McStore update..."},
    {"Buscando...", "Searching..."},
    {"Buscar", "Search"},
    {"Buscar por nombre", "Search by name"},
    {"Buscar una version nueva de McStore", "Check for a new McStore version"},
    {"Busqueda: %s", "Search: %s"},
    {"Busqueda: %s  |  %s", "Search: %s  |  %s"},
    {"Cambia al instante. Se guarda.", "Changes instantly. Saved automatically."},
    {"Cambiar de categoria (fuente PC)", "Change category (PC source)"},
    {"Cambiar de fila", "Change row"},
    {"Cambiar el valor (tipo, version, tema)", "Change the value (type, version, theme)"},
    {"Cancelado.", "Cancelled."},
    {"Cancelar", "Cancel"},
    {"Cargando catalogo...", "Loading catalog..."},
    {"Cargando descripcion...", "Loading description..."},
    {"Catalogo al dia: %d add-on(s), sin novedades.", "Catalog up to date: %d add-on(s), nothing new."},
    {"Categoria (L1/R1):  < %s >", "Category (L1/R1):  < %s >"},
    {"Circulo", "Circle"},
    {"Circulo: cancelar", "Circle: cancel"},
    {"Comportamiento -> behavior_packs", "Behavior -> behavior_packs"},
    {"Conectando con %d.%d.%d.%d:%d   %lus", "Connecting to %d.%d.%d.%d:%d   %lus"},
    {"Conectando con GitHub   %lus", "Connecting to GitHub   %lus"},
    {"Copiado en %s de %d carpeta(s) de usuario.", "Copied to %s of %d user folder(s)."},
    {"Cuadrado", "Square"},
    {"DETALLE DE UN ADD-ON", "ADD-ON DETAILS"},
    {"Descargando", "Downloading"},
    {"Descargando %d de %d: %s", "Downloading %d of %d: %s"},
    {"Descargando %s...", "Downloading %s..."},
    {"Descargando McStore %s...", "Downloading McStore %s..."},
    {"Descargar (o actualizar si hay version nueva)", "Download (or update if there is a new version)"},
    {"Descargas: %s    Actualizado: %s    Tamano: %s", "Downloads: %s    Updated: %s    Size: %s"},
    {"Descargas: %s/downloads   (Minecraft debe estar abierto)", "Downloads: %s/downloads   (Minecraft must be open)"},
    {"Desde la ultima vez: %d nuevo(s), %d actualizado(s).", "Since last time: %d new, %d updated."},
    {"Direccion del PC (solo para la fuente PC):", "PC address (PC source only):"},
    {"El catalogo aun no trae versiones: ejecuta Build catalog en GitHub y recarga (Options).", "The catalog has no versions yet: run Build catalog on GitHub and reload (Options)."},
    {"El catalogo esta vacio (agrega add-ons a catalog.json en tu repositorio).", "The catalog is empty (add add-ons to catalog.json in your repository)."},
    {"El catalogo esta vacio: agrega add-ons a catalog.json en tu repositorio.", "The catalog is empty: add add-ons to catalog.json in your repository."},
    {"El pack ya existe", "The pack already exists"},
    {"Elige un pack y pulsa X (Minecraft abierto).", "Pick a pack and press X (Minecraft open)."},
    {"En Ajustes: preferencias (fondo animado, sonidos, musica e idioma)", "In Settings: preferences (animated background, sounds, music and language)"},
    {"En Filtros: quitar filtros. En Ajustes: abrir esta ayuda", "In Filters: clear filters. In Settings: open this help"},
    {"Escribir la letra", "Type the letter"},
    {"Esmeralda", "Emerald"},
    {"Esta ayuda sale solo la primera vez (en Ajustes, Triangulo, la vuelves a ver) | Arriba/Abajo: leer | X o Circulo: seguir", "This help shows only the first time (Settings, Triangle to see it again) | Up/Down: read | X or Circle: continue"},
    {"Esta entrada no tiene \"url\" en catalog.json", "This entry has no \"url\" in catalog.json"},
    {"Este pack pide Minecraft %d.%d.%d o mas nuevo.", "This pack needs Minecraft %d.%d.%d or newer."},
    {"FILTROS Y AJUSTES", "FILTERS AND SETTINGS"},
    {"Fallaron %d. Primero: %s", "%d failed. First: %s"},
    {"Fallo en %d carpeta(s): %s", "Failed in %d folder(s): %s"},
    {"Filtros y tema (GitHub) / cambiar el orden (PC)", "Filters and theme (GitHub) / change order (PC)"},
    {"Flechas", "D-pad"},
    {"Fondo animado (llamas, vaporwave, bloques)", "Animated background (flames, vaporwave, blocks)"},
    {"Formato no soportado: solo .mcpack.", "Unsupported format: .mcpack only."},
    {"Fuente de add-ons:", "Add-on source:"},
    {"Fuente: GitHub", "Source: GitHub"},
    {"Fuente: PC %d.%d.%d.%d:%d", "Source: PC %d.%d.%d.%d:%d"},
    {"GitHub (sin PC, por internet)", "GitHub (no PC, over the internet)"},
    {"GitHub: lee catalog.json de tu repositorio. PC: usa server.py en tu red.", "GitHub: reads catalog.json from your repository. PC: uses server.py on your network."},
    {"Gotico", "Gothic"},
    {"Guardado en %s", "Saved to %s"},
    {"Hay novedades en GitHub: %d nuevo(s), %d actualizado(s). Pulsa L2 para bajarlos.", "News on GitHub: %d new, %d updated. Press L2 to download them."},
    {"Hay una version mas nueva: pulsa X para actualizar", "A newer version is available: press X to update"},
    {"Hay version nueva %s (tienes %s): %s. Pulsa L3 para bajar el PKG.", "New version %s (you have %s): %s. Press L3 to download the PKG."},
    {"Hielo", "Ice"},
    {"INSTALAR EN MINECRAFT (Minecraft abierto en segundo plano)", "INSTALL IN MINECRAFT (Minecraft open in the background)"},
    {"Instalado: %s", "Installed: %s"},
    {"Instalados %d pack(s)", "Installed %d pack(s)"},
    {"Instalados %d pack(s)%s.", "Installed %d pack(s)%s."},
    {"Instalando...", "Installing..."},
    {"Instalando... no apagues la consola", "Installing... do not turn off the console"},
    {"Instalar el pack elegido", "Install the selected pack"},
    {"Instalar en Minecraft", "Install in Minecraft"},
    {"Instalar todos los packs", "Install all packs"},
    {"Ir a instalar en Minecraft", "Go to install in Minecraft"},
    {"Izq / Der", "Left / Right"},
    {"Izquierda/Derecha: elegir campo   Arriba/Abajo: cambiar   L1/R1: +-10 (puerto: +-100)", "Left/Right: pick field   Up/Down: change   L1/R1: +-10 (port: +-100)"},
    {"LISTA DE ADD-ONS", "ADD-ON LIST"},
    {"La actualizacion de la app solo funciona con la fuente GitHub.", "App updates only work with the GitHub source."},
    {"Leer la descripcion", "Read the description"},
    {"Lista actualizada.", "List updated."},
    {"Listo", "Done"},
    {"Listo: %d add-on(s) descargado(s). Pulsa R2 para instalar.", "Done: %d add-on(s) downloaded. Press R2 to install."},
    {"Llamas", "Flames"},
    {"Mas bajado", "Most downloaded"},
    {"McStore %s esta al dia.", "McStore %s is up to date."},
    {"McStore - Add-ons", "McStore - Add-ons"},
    {"McStore - Ayuda", "McStore - Help"},
    {"McStore - Detalle", "McStore - Details"},
    {"McStore - Filtros y tema", "McStore - Filters and theme"},
    {"McStore - Instalar en Minecraft", "McStore - Install in Minecraft"},
    {"McStore - Preferencias", "McStore - Preferences"},
    {"Minecraft no esta abierto", "Minecraft is not open"},
    {"Minecraft no esta abierto o no veo su carpeta.", "Minecraft is not open or I cannot see its folder."},
    {"Moverse por las tarjetas", "Move around the cards"},
    {"Muestra solo packs hechos para esa version (1.21.x incluye 1.21.0, 1.21.50...).", "Only shows packs made for that version (1.21.x includes 1.21.0, 1.21.50...)."},
    {"Musica de fondo", "Background music"},
    {"Musica en bucle mientras usas la tienda. Quitala si prefieres silencio.", "Looping music while you use the store. Turn it off if you prefer silence."},
    {"No hay actualizaciones en esta pagina (solo se actualiza lo que ya descargaste).", "No updates on this page (only what you already downloaded is updated)."},
    {"No hay archivos descargados. Vuelve (Circulo) y descarga uno con X.", "No downloaded files. Go back (Circle) and download one with X."},
    {"No hay nada [NUEVO] ni [ACTUALIZADO]. Pulsa Options para buscar novedades en GitHub.", "Nothing [NEW] or [UPDATED]. Press Options to look for news on GitHub."},
    {"No hay resultados con esa busqueda y esos filtros (Circulo: filtros).", "No results for that search and filters (Circle: filters)."},
    {"No hay resultados para esa busqueda.", "No results for that search."},
    {"No pude cargar la descripcion: %s", "Could not load the description: %s"},
    {"No pude mirar GitHub: %s (falta app_update.json en tu repo?)", "Could not check GitHub: %s (is app_update.json missing in your repo?)"},
    {"No pude volver a Minecraft: usa el menu de la consola.", "Could not return to Minecraft: use the console menu."},
    {"No se copio nada.", "Nothing was copied."},
    {"No se pudo borrar.", "Could not delete."},
    {"No se pudo crear %s", "Could not create %s"},
    {"No se pudo guardar la configuracion en %s", "Could not save the settings to %s"},
    {"No se pudo iniciar el hilo de red", "Could not start the network thread"},
    {"No se pudo instalar", "Could not install"},
    {"No se pudo instalar %s", "Could not install %s"},
    {"No se pudo renombrar a %s", "Could not rename to %s"},
    {"No se puede deshacer. Podras volver a bajarlos desde el catalogo.", "This cannot be undone. You can download them again from the catalog."},
    {"Nombre", "Name"},
    {"Nueva version %s (L3)", "New version %s (L3)"},
    {"Nueva version X (L3)", "New version X (L3)"},
    {"Nuevo", "New"},
    {"Nuevo en el catalogo", "New in the catalog"},
    {"Oceano", "Ocean"},
    {"Orden: %s   Pagina %d/%d", "Order: %s   Page %d/%d"},
    {"Oro negro", "Black gold"},
    {"Otros", "Others"},
    {"PC en mi red (server.py)", "PC on my network (server.py)"},
    {"PKG nuevo en %s: instalalo desde Debug Settings > Package Installer.", "New PKG in %s: install it from Debug Settings > Package Installer."},
    {"Pagina %d de %d. Pulsa X para ver el detalle.", "Page %d of %d. Press X for details."},
    {"Poner un espacio", "Insert a space"},
    {"Pulsa TRIANGULO para volver a Minecraft.", "Press TRIANGLE to return to Minecraft."},
    {"Pulsa X para descargar.", "Press X to download."},
    {"Pulsa cualquier boton", "Press any button"},
    {"Quieres reemplazarlo?", "Do you want to replace it?"},
    {"Quita la animacion si prefieres un fondo quieto (gasta menos). Solo afecta a los temas Llamas, Vaporwave y Bloques.", "Turn the animation off for a still background (uses less power). Only affects the Flames, Vaporwave and Blocks themes."},
    {"Recargar el catalogo", "Reload the catalog"},
    {"Saltar una pantalla de tarjetas (PC: cambiar de pagina)", "Jump one screen of cards (PC: change page)"},
    {"Sangre", "Blood"},
    {"Se borra de las descargas de McStore (no toca lo ya instalado en Minecraft).", "Deleted from McStore downloads (does not touch what is already installed in Minecraft)."},
    {"Se pierde al cerrar Minecraft o apagar la consola: vuelve a instalar.", "Lost when you close Minecraft or turn off the console: install again."},
    {"Se pierden al cerrar Minecraft o apagar la consola: vuelve a instalar.", "Lost when you close Minecraft or turn off the console: install again."},
    {"Se van a borrar los %d archivos de la lista.", "All %d files in the list will be deleted."},
    {"Sin resultados. Cuadrado: buscar | Triangulo: ajustes", "No results. Square: search | Triangle: settings"},
    {"Sonidos (cursor, descarga terminada, error)", "Sounds (cursor, download finished, error)"},
    {"Tarda mucho: revisa la IP (cancela y pulsa Triangulo).", "Taking long: check the IP (cancel and press Triangle)."},
    {"Tarda mucho: revisa tu conexion a internet.", "Taking long: check your internet connection."},
    {"Tema de color", "Color theme"},
    {"Texturas", "Textures"},
    {"Texturas -> resource_packs", "Textures -> resource_packs"},
    {"Texturas = resource packs. Addons = comportamiento, mobs, items.", "Textures = resource packs. Addons = behavior, mobs, items."},
    {"Tipo de add-on", "Add-on type"},
    {"Todas", "All"},
    {"Todas (el catalogo aun no trae versiones)", "All (the catalog has no versions yet)"},
    {"Todos", "All"},
    {"Triangulo", "Triangle"},
    {"Triangulo: volver a Minecraft | X o Circulo: cerrar", "Triangle: back to Minecraft | X or Circle: close"},
    {"Tu consola tiene %d.%d.%d (mcversion.txt): puede no cargar.", "Your console has %d.%d.%d (mcversion.txt): it may not load."},
    {"Un tic al mover el cursor y un sonido al terminar una descarga o al fallar.", "A tick when you move the cursor and a sound when a download finishes or fails."},
    {"Version de Minecraft", "Minecraft version"},
    {"Volver", "Back"},
    {"Volver a la lista (cancela la descarga si hay una)", "Back to the list (cancels the download if any)"},
    {"X o Circulo: cerrar", "X or Circle: close"},
    {"X: actualizar | Arriba/Abajo: leer | R2: instalar en Minecraft | Circulo: volver", "X: update | Up/Down: read | R2: install in Minecraft | Circle: back"},
    {"X: borrar | Circulo: cancelar", "X: delete | Circle: cancel"},
    {"X: descargar | Arriba/Abajo: leer | R2: instalar en Minecraft | Circulo: volver", "X: download | Up/Down: read | R2: install in Minecraft | Circle: back"},
    {"X: detalle | Cuad: buscar | Circ: filtros | Opt: recargar | L2: updates | R2: instalar | L3: app | Tri: ajustes", "X: details | Sq: search | Circ: filters | Opt: reload | L2: updates | R2: install | L3: app | Tri: settings"},
    {"X: detalle | Cuad: buscar | Circ: orden | L1/R1: pag. | Opt: recargar | L2: updates | R2: instalar | Tri: ajustes", "X: details | Sq: search | Circ: order | L1/R1: page | Opt: reload | L2: updates | R2: install | Tri: settings"},
    {"X: escribir | Cuadrado: borrar | Triangulo: espacio | L1/R1: categoria | Options: buscar | Circulo: cancelar", "X: type | Square: delete | Triangle: space | L1/R1: category | Options: search | Circle: cancel"},
    {"X: guardar | Circulo: cancelar | Cuadrado: preferencias | Triangulo: ayuda", "X: save | Circle: cancel | Square: preferences | Triangle: help"},
    {"X: instalar igual | Circulo: cancelar", "X: install anyway | Circle: cancel"},
    {"X: instalar | Cuad: borrar", "X: install | Sq: delete"},
    {"X: instalar | Cuad: borrar | Tri: borrar todos | L2: instalar todos | Opt: refrescar | Circ: volver", "X: install | Sq: delete | Tri: delete all | L2: install all | Opt: refresh | Circ: back"},
    {"X: reemplazar | Circulo: cancelar", "X: replace | Circle: cancel"},
    {"Ya descargado (al dia)", "Already downloaded (up to date)"},
    {"[ACTUALIZADO]", "[UPDATED]"},
    {"[DESCARGADO]", "[DOWNLOADED]"},
    {"[HAY UPDATE]", "[UPDATE]"},
    {"[NUEVO]", "[NEW]"},
    {"Si", "Yes"},
    {"Idioma / Language", "Language"},
    {"Cambia el idioma de los menus. Language of the menus.", "Language of the menus. Cambia el idioma de los menus."},
    {"%d resultados", "%d results"},
    {"no instalable", "not installable"},
    {"no habia .mcpack validos para instalar", "there were no valid .mcpack to install"},
    {"no se pudo crear el socket (errno %d)", "could not create the socket (errno %d)"},
    {"no se pudo conectar a %d.%d.%d.%d:%d (errno %d)", "could not connect to %d.%d.%d.%d:%d (errno %d)"},
    {"respuesta HTTP invalida", "invalid HTTP response"},
    {"respuesta demasiado grande", "response too big"},
    {"sin memoria", "out of memory"},
    {"no se pudo abrir el archivo", "could not open the file"},
    {"no es un .mcpack valido (muy pequeno)", "not a valid .mcpack (too small)"},
    {"no es un zip valido (falta el directorio central)", "not a valid zip (central directory missing)"},
    {"no se pudo descomprimir manifest.json", "could not decompress manifest.json"},
    {"no se pudo abrir %s", "could not open %s"},
    {"no se pudo escribir en %s (errno %d)", "could not write to %s (errno %d)"},
    {"no se pudo renombrar a %s (errno %d)", "could not rename to %s (errno %d)"},
    {"no existe la carpeta %s", "folder %s does not exist"},
    {"%d de %d add-ons con este filtro", "%d of %d add-ons match this filter"},
    {"%s esta vacia o la app no la ve.", "%s is empty or the app cannot see it."},
    {"%s ya esta en %s.", "%s is already in %s."},
    {"Addons", "Add-ons"},
    {"Agregado a favoritos.", "Added to favorites."},
    {"Agregado a favoritos: %.50s", "Added to favorites: %.50s"},
    {"Quitado de favoritos.", "Removed from favorites."},
    {"Quitado de favoritos: %.50s", "Removed from favorites: %.50s"},
    {"Aun no has descargado nada.", "You have not downloaded anything yet."},
    {"Aun no tienes favoritos: pulsa R3 sobre un pack (o Cuadrado en el detalle).", "No favorites yet: press R3 on a pack (or Square in the details)."},
    {"Cambia al instante y se guarda.", "Changes instantly and is saved."},
    {"Descargados", "Downloaded"},
    {"Descargas, fecha y tamano salen del catalogo (ejecuta Build catalog si faltan).", "Downloads, date and size come from the catalog (run Build catalog if missing)."},
    {"Diagnostico: jailbreak=%d ; juego(id)=%d ; ruta: %s", "Diagnostics: jailbreak=%d ; game(id)=%d ; path: %s"},
    {"Favoritos", "Favorites"},
    {"Favoritos: R3 en la lista. Novedades: lo ultimo subido. Populares: los mas bajados (60 de cada uno).", "Favorites: R3 in the list. New: latest uploads. Popular: most downloaded (60 of each)."},
    {"Mas descargados", "Most downloaded"},
    {"Mas pesados", "Largest"},
    {"Mostrar", "Show"},
    {"No se cambio de metodo: avisame para decidir el siguiente intento.", "Method not changed: let me know to decide the next attempt."},
    {"Nombre A-Z", "Name A-Z"},
    {"Novedades", "New"},
    {"Novedades (lo ultimo)", "New (latest)"},
    {"Populares", "Popular"},
    {"Populares (mas bajados)", "Popular (most downloaded)"},
    {"Ordenar por", "Sort by"},
    {"Recien actualizado", "Recently updated"},
    {"Sin resultados: cambia los filtros (Circulo).", "No results: change the filters (Circle)."},
    {"Solo descargados", "Downloaded only"},
    {"Solo favoritos", "Favorites only"},
    {"Solo packs hechos para esa version (1.21.x incluye 1.21.0, 1.21.50...).", "Only packs made for that version (1.21.x includes 1.21.0, 1.21.50...)."},
    {"Todas (aun sin versiones)", "All (no versions yet)"},
    {"X: actualizar | Tri: bajar e instalar | Cuad: favorito | Arr/Abj: leer | R2: instalar | Circ: volver", "X: update | Tri: download+install | Sq: favorite | Up/Dn: read | R2: install | Circ: back"},
    {"X: descargar | Tri: bajar e instalar | Cuad: favorito | Arr/Abj: leer | R2: instalar | Circ: volver", "X: download | Tri: download+install | Sq: favorite | Up/Dn: read | R2: install | Circ: back"},
    {"X: detalle | Cuad: buscar | Circ: filtros | R3: fav | Opt: recargar | L2: updates | R2: instalar | L3: app | Tri: ajustes | Pad: ayuda", "X: details | Sq: search | Circ: filters | R3: fav | Opt: reload | L2: updates | R2: install | L3: app | Tri: settings | Pad: help"},
    {"app_update.json no tiene datos.", "app_update.json has no data."},
    {"error desconocido", "unknown error"},
    {"formato no soportado", "unsupported format"},
    {"por %s", "by %s"},
    {"por %s     ", "by %s     "},
    {"Marcar o quitar favorito (corazon) en el pack elegido", "Add or remove a favorite (heart) on the selected pack"},
    {"Abrir esta ayuda", "Open this help"},
    {"Bajar e instalar en Minecraft de una vez", "Download and install in Minecraft in one step"},
    {"Marcar o quitar favorito", "Add or remove favorite"},
    {"SECCIONES Y MARCAS DE LA LISTA", "LIST SECTIONS AND MARKS"},
    {"En Filtros: Todos, Solo favoritos, Solo descargados, Novedades o Populares", "In Filters: All, Favorites only, Downloaded only, New or Popular"},
    {"Los 60 packs subidos o actualizados mas recientemente", "The 60 most recently added or updated packs"},
    {"Los 60 packs mas descargados", "The 60 most downloaded packs"},
    {"Corazon = favorito. OK = ya descargado", "Heart = favorite. OK = already downloaded"},
    {"Corazon / OK", "Heart / OK"},
    {"Musica propia (importar)", "Your own music (import)"},
    {"Tu musica (WAV)", "Your music (WAV)"},
    {"Ninguna", "None"},
    {"X: baja tu musica de GitHub (music/musica.wav o sube un mp3 a la carpeta music). Cuadrado: quitarla y volver a la musica de siempre.", "X: downloads your music from GitHub (music/musica.wav, or upload an mp3 to the music folder). Square: remove it and go back to the default music."},
    {"Arriba/Abajo: fila | Izq/Der o X: cambiar | Cuadrado: quitar musica propia | Circulo: volver (se guarda)", "Up/Down: row | Left/Right or X: change | Square: remove own music | Circle: back (saved)"},
    {"Musica propia quitada: vuelve la musica de siempre.", "Own music removed: the default music is back."},
    {"Importar musica solo funciona con la fuente GitHub.", "Importing music only works with the GitHub source."},
    {"Descargando tu musica...", "Downloading your music..."},
    {"Listo: ahora suena tu musica.", "Done: your music is now playing."},
    {"No pude usar ese archivo: debe ser un WAV de 16 bits (music/musica.wav en el repo).", "Could not use that file: it must be a 16-bit WAV (music/musica.wav in the repo)."},
    {"Subir packs desde el telefono", "Upload packs from your phone"},
    {"Abrir", "Open"},
    {"X: la PS4 abre una web; sube tus .mcpack/.mcaddon desde el telefono (sin GitHub).", "X: the PS4 opens a web page; upload your .mcpack/.mcaddon from your phone."},
    {"McStore - Subir desde el telefono", "McStore - Upload from your phone"},
    {"Abre esta direccion en el navegador del telefono:", "Open this address in your phone's browser:"},
    {"Abriendo...", "Starting..."},
    {"El telefono y la PS4 deben estar en la misma red wifi.", "The phone and the PS4 must be on the same wifi network."},
    {"1) Abre la direccion de arriba en Safari.", "1) Open the address above in Safari."},
    {"2) Toca \"Elegir archivos\" y escoge tus .mcpack o .mcaddon.", "2) Tap \"Choose files\" and pick your .mcpack or .mcaddon."},
    {"3) Toca \"Subir\". Aqui abajo veras cuando lleguen.", "3) Tap \"Upload\". You will see them arrive below."},
    {"4) Pulsa R2 para instalarlos en Minecraft.", "4) Press R2 to install them in Minecraft."},
    {"Archivos recibidos: %d", "Files received: %d"},
    {"Recibido: %s", "Received: %s"},
    {"Rechazado (solo .mcpack/.mcaddon): %s", "Rejected (.mcpack/.mcaddon only): %s"},
    {"Fallo al recibir: %s", "Failed to receive: %s"},
    {"No se pudo abrir el servidor (red no disponible?)", "Could not open the server (network not available?)"},
    {"No se pudo iniciar el servidor", "Could not start the server"},
    {"R2: instalar en Minecraft | Circulo: volver", "R2: install in Minecraft | Circle: back"},
    {"SUBIR PACKS DESDE EL TELEFONO", "UPLOAD PACKS FROM YOUR PHONE"},
    {"Preferencias", "Preferences"},
    {"Ultima fila: la PS4 muestra una direccion web; abrela en el telefono y sube tus packs", "Last row: the PS4 shows a web address; open it on your phone and upload your packs"},
    {"Cuando lleguen, instalalos en Minecraft", "When they arrive, install them in Minecraft"},
    {"Publicando para todos: %s", "Publishing for everyone: %s"},
    {"Publicado para todos: %s", "Published for everyone: %s"},
    {"No se publico: %s", "Not published: %s"},
    {"Modo creador: token guardado", "Creator mode: token saved"},
    {"Modo creador: abre http://%s:%d/creador para publicar para todos.", "Creator mode: open http://%s:%d/creador to publish for everyone."},
};
#define TR_N ((int)(sizeof(TR_TAB) / sizeof(TR_TAB[0])))

struct TrCap { const char *p; int n; };

static const char *tr_spec(const char *f) {  // devuelve el caracter siguiente al %spec (f apunta a '%')
    f++;
    if (*f == 'l') f++;
    return *f ? f + 1 : f;
}

// ¿encaja s con la frase pat? (%d / %lu = digitos, %s = cualquier cosa); guarda lo capturado.
static bool tr_match(const char *pat, const char *s, TrCap *caps, int &nc) {
    while (*pat) {
        if (*pat == '%' && pat[1] != '%') {
            const char *spec = pat + 1;
            if (*spec == 'l') spec++;
            char t = *spec;
            const char *next = tr_spec(pat);
            if (nc >= 12) return false;
            if (t == 'd' || t == 'u') {
                const char *q = s;
                if (*q == '-') q++;
                if (*q < '0' || *q > '9') return false;
                while (*q >= '0' && *q <= '9') q++;
                caps[nc++] = {s, (int)(q - s)};
                s = q; pat = next;
            } else {  // %s: lo mas corto que deje encajar el resto
                int save = nc;
                for (int len = 0; ; len++) {
                    nc = save;
                    caps[nc++] = {s, len};
                    if (tr_match(next, s + len, caps, nc)) return true;
                    if (!s[len]) return false;
                }
            }
        } else {
            if (*pat != *s) return false;
            pat++; s++;
        }
    }
    return *s == 0;
}

static const char *tr_one(const char *s);
static const char *tr(const char *s) {
    if (g_lang == 0 || !s || !s[0]) return s;
    static char eb[2][600];
    static int es = 0;
    if (!strncmp(s, "Error: ", 7)) {  // "Error: <causa>": traduce la causa por separado
        const char *c = tr_one(s + 7);
        char *o = eb[es = (es + 1) & 1];
        snprintf(o, 600, "Error: %s", c);
        return o;
    }
    return tr_one(s);
}
static const char *tr_one(const char *s) {
    static char out[4][600];
    static int slot = 0;
    for (int i = 0; i < TR_N; i++) {
        const char *es = TR_TAB[i].es;
        if (es[0] != s[0] && es[0] != '%') continue;
        TrCap caps[12];
        int nc = 0;
        if (!strchr(es, '%')) {
            if (strcmp(es, s)) continue;
            return TR_TAB[i].en;
        }
        if (!tr_match(es, s, caps, nc)) continue;
        char *o = out[slot = (slot + 1) & 3];
        int w = 0, k = 0;
        for (const char *f = TR_TAB[i].en; *f && w < 590; ) {
            if (*f == '%' && f[1] != '%' && k < nc) {
                for (int j = 0; j < caps[k].n && w < 590; j++) o[w++] = caps[k].p[j];
                k++;
                f = tr_spec(f);
            } else o[w++] = *f++;
        }
        o[w] = 0;
        return o;
    }
    return s;
}
