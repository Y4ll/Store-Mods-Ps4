// Pantalla de la tienda (catalogo de CurseForge): lista a la izquierda, foto y descripcion a la derecha.
// Se incluye desde main.cpp (usa sus funciones: set_status, job_new/job_start, install, etc.).
#pragma once

#ifndef STORE_URL
#define STORE_URL ""
#endif
#define SV_MAXROWS 3000

struct Sv {
    bool on;        // meta cargada: la tienda esta disponible
    bool booting;   // esperando meta.tsv
    bool failed;    // no se pudo bajar meta.tsv
    char err[200];
    uint64_t bootStart;
    int cls, sel, top;
    bool searching, wantSearch;
    uint64_t searchStart;
    char query[40];
    int *rows;
    int nrows;
    // miniatura que se muestra
    int lastKey;
    uint64_t selSince;
    int imgState;   // 0 = pidiendo, 1 = lista, 2 = sin foto
    uint32_t *img;
    int imgW, imgH;
    char storeUrl[300];
};
static Sv V;

static void fmt_count(long n, char *out, size_t cap) {
    if (n >= 1000000) snprintf(out, cap, "%.1fM", n / 1e6);
    else if (n >= 1000) snprintf(out, cap, "%ldK", n / 1000);
    else snprintf(out, cap, "%ld", n);
}

static int sv_count() {
    if (V.searching) return V.nrows;
    return (V.cls >= 0 && V.cls < ST.ncls) ? ST.cls[V.cls].count : 0;
}

static const SItem *sv_item(int row) {
    if (row < 0) return NULL;
    if (V.searching) {
        if (row >= V.nrows) return NULL;
        SIdx e = store_idx(V.rows[row]);
        return store_item(e.cls, e.page, e.slot);
    }
    return store_item(V.cls, row / SPAGE + 1, row % SPAGE);
}

static bool sv_failed(int row) {
    if (V.searching) return false;
    std::lock_guard<std::mutex> g(ST.mu);
    int pg = row / SPAGE;
    return V.cls >= 0 && V.cls < ST.ncls && pg < S_MAXPAGES && ST.cls[V.cls].pg[pg].st == 3;
}

// Parte un texto en renglones de `cols` letras sin cortar palabras. Devuelve cuantos renglones.
static int wrap_text(const char *s, int cols, char lines[][72], int maxLines) {
    int n = 0;
    while (*s && n < maxLines) {
        while (*s == ' ') s++;
        int len = (int)strlen(s);
        if (len <= cols) { snprintf(lines[n++], 72, "%s", s); break; }
        int cut = cols;
        while (cut > 0 && s[cut] != ' ') cut--;
        if (cut == 0) cut = cols;
        snprintf(lines[n], 72, "%.*s", cut, s);
        n++;
        s += cut;
    }
    return n;
}

static bool sv_downloaded(const SItem &it) {
    char fname[128], p[420];
    safe_filename(it.file[0] ? it.file : it.name, fname, sizeof(fname));
    snprintf(p, sizeof(p), "%s/downloads/%s", plat_data_dir(), fname);
    bool d = false;
    long sz = 0;
    return plat_stat(p, &d, &sz) && !d && sz > 0;
}

#define SV_LIST_Y 160
#define SV_ROWS 15

static void draw_store() {
    draw_header("McStore");
    unsigned long secs = (unsigned long)((plat_ms() - V.bootStart) / 1000);

    if (!V.on) {
        int w = 1400, h = 260, x = (SCREEN_W - w) / 2, y = (SCREEN_H - h) / 2 - 40;
        fill(x - 4, y - 4, w + 8, h + 8, V.failed ? C_ERR : C_ACCENT);
        panel(x, y, w, h, C_PANEL);
        if (V.failed) {
            text(x + 40, y + 30, "No pude abrir la tienda de CurseForge", 2, C_ERR);
            text(x + 40, y + 80, V.err, 2, C_TEXT, 82);
            text(x + 40, y + 125, "Falta ejecutar 'Sync catalogo' en GitHub Actions, o no hay internet.", 2, C_DIM, 82);
            text(x + 40, y + 190, "X: reintentar | Derecha: mi catalogo | Circulo: menu", 2, C_ACCENT);
        } else {
            text(x + 40, y + 30, "Conectando con el catalogo de CurseForge...", 2, C_ACCENT);
            char s[120];
            snprintf(s, sizeof(s), "%lus", secs);
            text(x + 40, y + 80, s, 2, C_TEXT);
            text(x + 40, y + 190, "Circulo: volver al menu", 2, C_DIM);
        }
        draw_busy_overlay();
        draw_footer("Circulo: menu");
        return;
    }

    // pestanas de categorias
    int tx = 40;
    for (int c = 0; c <= ST.ncls; c++) {
        const char *label = c < ST.ncls ? ST.cls[c].name : "Mi catalogo";
        int w = (int)strlen(label) * 16 + 40;
        bool sel = c == V.cls && !V.searching;
        if (sel) fill(tx, 100, w, 44, C_ACCENT); else panel(tx, 100, w, 44, C_PANEL);
        text(tx + 20, 112, label, 2, sel ? C_BG : C_DIM);
        tx += w + 10;
    }
    char head[120];
    int n = sv_count();
    if (V.searching) snprintf(head, sizeof(head), "Busqueda: %s  (%d)  Circulo: salir", V.query, n);
    else snprintf(head, sizeof(head), "%d add-ons", n);
    text(SCREEN_W - 40 - text_w(head, 2), 112, head, 2, V.searching ? C_ACCENT : C_DIM);

    // lista
    for (int i = 0; i < SV_ROWS; i++) {
        int idx = V.top + i;
        if (idx >= n) break;
        int y = SV_LIST_Y + i * ROW_H;
        bool sel = idx == V.sel;
        if (sel) panel(30, y - 4, 990, ROW_H - 2, C_SEL);
        uint32_t col = sel ? C_TEXT : C_DIM;
        char name[64] = "", mid[24] = "", dl[16] = "";
        if (V.searching) {
            SIdx e = store_idx(V.rows[idx]);
            snprintf(name, sizeof(name), "%s", e.name);
            snprintf(mid, sizeof(mid), "%s", ST.cls[e.cls].name);
            fmt_count(e.dl, dl, sizeof(dl));
        } else {
            const SItem *it = sv_item(idx);
            if (it) {
                snprintf(name, sizeof(name), "%s", it->name);
                snprintf(mid, sizeof(mid), "%s", it->ver);
                fmt_count(it->dl, dl, sizeof(dl));
            } else {
                snprintf(name, sizeof(name), "%s", sv_failed(idx) ? "(error al bajar la pagina: X para reintentar)" : "Cargando...");
            }
        }
        text(50, y + 4, name, 2, col, 36);
        text(680, y + 4, mid, 2, C_DIM, 10);
        text(1000 - text_w(dl, 2), y + 4, dl, 2, C_ACCENT);
    }
    if (n == 0) text(60, SV_LIST_Y + 20, V.searching ? "Sin resultados para esa busqueda." : "Esta categoria esta vacia.", 2, C_DIM);
    if (n > SV_ROWS) {
        int h = SV_ROWS * ROW_H;
        int bh = h * SV_ROWS / n;
        if (bh < 30) bh = 30;
        int by = SV_LIST_Y + (h - bh) * V.top / (n - SV_ROWS);
        panel(1024, SV_LIST_Y, 8, h, C_PANEL);
        fill(1024, by, 8, bh, C_ACCENT);
    }

    // panel de detalle: foto + datos + descripcion
    int px = 1050, pw = SCREEN_W - px - 30;
    panel(px, 150, pw, 790, C_PANEL);
    const SItem *it = n ? sv_item(V.sel) : NULL;
    if (!it) {
        text(px + 30, 180, n ? (sv_failed(V.sel) ? "No se pudo bajar la pagina." : "Cargando...") : "", 2, C_DIM);
    } else {
        fill(px + 20, 170, 264, 264, RGB(30, 38, 34));
        if (V.imgState == 1) {
            int dw = V.imgW, dh = V.imgH;
            blit(px + 24 + (256 - dw) / 2, 174 + (256 - dh) / 2, dw, dh, V.img, V.imgW, V.imgH);
        } else {
            text(px + 20 + 132 - (V.imgState == 2 ? 4 : 7) * 8 , 296, V.imgState == 2 ? "Sin foto" : "Cargando foto...", 2, C_DIM);
        }
        int tx2 = px + 310, cols = (pw - 330) / 24;
        char nl[3][72];
        int nn = wrap_text(it->name, cols, nl, 2);
        for (int i = 0; i < nn; i++) text(tx2, 172 + i * 40, nl[i], 3, C_TEXT);
        char s[160], a[24];
        snprintf(s, sizeof(s), "por %s", it->author[0] ? it->author : "(desconocido)");
        text(tx2, 270, s, 2, C_ACCENT, (pw - 330) / 16);
        fmt_count(it->dl, a, sizeof(a));
        snprintf(s, sizeof(s), "Descargas: %s", a);
        text(tx2, 306, s, 2, C_TEXT);
        snprintf(s, sizeof(s), "Version: %s", it->ver[0] ? it->ver : "?");
        text(tx2, 340, s, 2, C_TEXT);
        fmt_size(it->size, a, sizeof(a));
        snprintf(s, sizeof(s), "Tamano: %s", a);
        text(tx2, 374, s, 2, C_TEXT);
        if (sv_downloaded(*it)) text(tx2, 408, "Ya descargado (R2: instalar)", 2, C_OK, (pw - 330) / 16);
        else text(tx2, 408, "X: descargar", 2, C_DIM);

        text(px + 20, 456, "Descripcion", 2, C_ACCENT);
        char dl2[14][72];
        int dn = wrap_text(it->summary[0] ? it->summary : "(sin descripcion)", (pw - 40) / 16, dl2, 14);
        for (int i = 0; i < dn; i++) text(px + 20, 494 + i * 30, dl2[i], 2, C_DIM);
    }

    // busqueda esperando el indice
    if (V.wantSearch) {
        int w = 1100, h = 200, x = (SCREEN_W - w) / 2, y = (SCREEN_H - h) / 2;
        fill(x - 4, y - 4, w + 8, h + 8, C_ACCENT);
        panel(x, y, w, h, C_PANEL);
        text(x + 40, y + 30, "Preparando la busqueda (se baja una vez)...", 2, C_ACCENT);
        char s[120], a[24], b[24];
        fmt_size(ST.idxDone.load(), a, sizeof(a));
        fmt_size(ST.idxTotal.load(), b, sizeof(b));
        snprintf(s, sizeof(s), "%s / %s   %lus", a, b, (unsigned long)((plat_ms() - V.searchStart) / 1000));
        text(x + 40, y + 80, s, 2, C_TEXT);
        text(x + 40, y + 130, "Circulo: cancelar", 2, C_DIM);
    }
    draw_busy_overlay();
    draw_footer("X: descargar | Cuadrado: buscar | Izq/Der: categoria | R2: instalar | Options: recargar | Circulo: menu");
}

// ---------- logica ----------

static void sv_reset_view() {
    V.cls = 0;
    V.sel = V.top = 0;
    V.searching = V.wantSearch = false;
    V.query[0] = 0;
    V.lastKey = 0;
    V.imgState = 0;
}

static void store_boot() {
    V.on = false;
    V.booting = true;
    V.failed = false;
    V.bootStart = plat_ms();
    if (!V.img) V.img = (uint32_t *)malloc((size_t)S_THUMB * S_THUMB * 4);
    sv_reset_view();
    store_start(V.storeUrl);
}

// Lee la direccion de la tienda: la del Makefile (STORE_URL) o la de /data/mcstore/store.txt.
static void store_url_load() {
    snprintf(V.storeUrl, sizeof(V.storeUrl), "%s", STORE_URL);
    char p[300];
    snprintf(p, sizeof(p), "%s/store.txt", plat_data_dir());
    FILE *f = fopen(p, "r");
    if (!f) return;
    char line[300];
    if (fgets(line, sizeof(line), f)) {
        size_t l = strlen(line);
        while (l && (line[l - 1] == '\n' || line[l - 1] == '\r' || line[l - 1] == ' ')) line[--l] = 0;
        if (!strncmp(line, "http", 4)) snprintf(V.storeUrl, sizeof(V.storeUrl), "%s", line);
    }
    fclose(f);
}

static void sv_run_search() {
    if (!V.rows) V.rows = (int *)malloc(sizeof(int) * SV_MAXROWS);
    V.nrows = V.rows ? store_search(V.query, V.rows, SV_MAXROWS) : 0;
    V.searching = true;
    V.sel = V.top = 0;
    V.lastKey = 0;
    if (V.nrows) set_status(C_OK, "%d resultado(s) para \"%s\". X: descargar.", V.nrows, V.query);
    else set_status(C_DIM, "Nada encontrado para \"%s\".", V.query);
}

static void sv_apply_query(const char *q) {
    if (!q[0]) {
        V.searching = V.wantSearch = false;
        V.query[0] = 0;
        V.sel = V.top = 0;
        V.lastKey = 0;
        return;
    }
    snprintf(V.query, sizeof(V.query), "%s", q);
    V.wantSearch = true;
    V.searchStart = plat_ms();
    store_want_index();
}

// Se llama en cada fotograma.
static void store_tick() {
    if (V.booting) {
        int st;
        char err[200];
        {
            std::lock_guard<std::mutex> g(ST.mu);
            st = ST.metaSt;
            snprintf(err, sizeof(err), "%s", ST.err);
        }
        if (st == 2) {
            V.booting = false;
            V.on = true;
            g_storeOn = true;
            set_status(C_OK, "%ld add-ons de CurseForge (actualizado %s). Izq/Der: categoria, X: descargar.", ST.total, ST.generated);
        } else if (st == 3) {
            V.booting = false;
            V.failed = true;
            V.on = false;
            g_storeOn = false;
            snprintf(V.err, sizeof(V.err), "%s", err[0] ? err : "sin respuesta");
            set_status(C_ERR, "Tienda no disponible: %s", V.err);
        }
    }
    if (!V.on) return;

    if (V.wantSearch) {
        int st;
        {
            std::lock_guard<std::mutex> g(ST.mu);
            st = ST.idxSt;
        }
        if (st == 2) { V.wantSearch = false; sv_run_search(); }
        else if (st == 3) { V.wantSearch = false; set_status(C_ERR, "No pude bajar el indice de busqueda (falta index.tsv?)."); }
    }
    if (A.scr != S_STORE) return;

    // paginas vecinas por adelantado, para que bajar por la lista sea fluido
    if (!V.searching) {
        int p = V.sel / SPAGE + 1;
        store_want_page(V.cls, p);
        store_want_page(V.cls, p + 1);
        store_want_page(V.cls, p - 1);
    }
    // miniatura del seleccionado (se pide cuando la seleccion se queda quieta un momento)
    int n = sv_count();
    const SItem *it = n ? sv_item(V.sel) : NULL;
    int key = it ? it->id : 0;
    if (key != V.lastKey) {
        V.lastKey = key;
        V.selSince = plat_ms();
        V.imgState = 0;
        store_want_thumb(0, "");
    }
    if (it && V.imgState == 0) {
        int w = 0, h = 0, r = store_thumb_copy(it->id, V.img, &w, &h);
        if (r == 1) { V.imgState = 1; V.imgW = w; V.imgH = h; }
        else if (r == -1) V.imgState = 2;
        else if (plat_ms() - V.selSince > 200) store_want_thumb(it->id, it->thumb);
    }
}

static void start_download_sitem(const SItem &it) {
    if (g_job) return;
    if (!it.url[0]) { set_status(C_ERR, "Este add-on no tiene enlace de descarga."); return; }
    char fname[128], dir[256];
    safe_filename(it.file[0] ? it.file : it.name, fname, sizeof(fname));
    snprintf(dir, sizeof(dir), "%s/downloads", plat_data_dir());
    mkdir_p(dir);
    Job *j = job_new(2);
    j->mode = M_GITHUB;  // descarga por URL completa
    snprintf(j->finalPath, sizeof(j->finalPath), "%s/%s", dir, fname);
    snprintf(j->url, sizeof(j->url), "%s", it.url);
    snprintf(A.dlName, sizeof(A.dlName), "%s", it.name);
    A.dlDone = 0;
    A.dlTotal = it.size;
    g_bulk = false;
    g_dlIdx = -1;
    g_pkgDl = false;
    set_status(C_TEXT, "Descargando %s...", fname);
    job_start(j);
}

static void input_store(uint32_t p) {
    if (!V.on) {
        if (p & BTN_CIRCLE) A.scr = S_MENU;
        if ((p & BTN_CROSS) && V.failed) store_boot();
        if (p & BTN_RIGHT) go_catalog();
        return;
    }
    if (V.wantSearch) {
        if (p & BTN_CIRCLE) V.wantSearch = false;
        return;
    }
    int n = sv_count();
    int last = n ? n - 1 : 0;
    if (p & BTN_DOWN) V.sel = clampi(V.sel + 1, 0, last);
    if (p & BTN_UP) V.sel = clampi(V.sel - 1, 0, last);
    if (p & BTN_R1) V.sel = clampi(V.sel + SV_ROWS, 0, last);
    if (p & BTN_L1) V.sel = clampi(V.sel - SV_ROWS, 0, last);
    if (V.sel < V.top) V.top = V.sel;
    if (V.sel >= V.top + SV_ROWS) V.top = V.sel - SV_ROWS + 1;

    if ((p & BTN_RIGHT) && !V.searching) {
        if (V.cls >= ST.ncls - 1) {  // ultima pestana: "Mi catalogo" (catalog.json del repo)
            go_catalog();
            return;
        }
        V.cls++;
        V.sel = V.top = 0;
        V.lastKey = 0;
    }
    if ((p & BTN_LEFT) && !V.searching && V.cls > 0) {
        V.cls--;
        V.sel = V.top = 0;
        V.lastKey = 0;
    }
    if (p & BTN_CROSS) {
        const SItem *it = n ? sv_item(V.sel) : NULL;
        if (it) start_download_sitem(*it);
        else if (n && !V.searching) store_retry_page(V.cls, V.sel / SPAGE + 1);
    }
    if (p & BTN_CIRCLE) {
        if (V.searching) {
            V.searching = false;
            V.query[0] = 0;
            V.sel = V.top = 0;
            V.lastKey = 0;
        } else A.scr = S_MENU;
    }
    if (p & BTN_SQUARE) {
        snprintf(A.kbuf, sizeof(A.kbuf), "%s", V.query);
        A.kr = A.kc = 0;
        g_kbBack = S_STORE;
        A.scr = S_KEYBOARD;
    }
    if (p & BTN_OPTIONS) {  // recargar todo
        store_reload();
        V.on = false;
        V.booting = true;
        V.failed = false;
        V.bootStart = plat_ms();
        sv_reset_view();
        g_storeOn = false;
        set_status(C_TEXT, "Recargando catalogo...");
    }
    if (p & BTN_R2) open_install(S_STORE);
}
