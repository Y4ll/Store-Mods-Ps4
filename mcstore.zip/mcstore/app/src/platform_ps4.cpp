// Implementación para PS4 (OpenOrbis): video, mando y reloj.
#include "platform.h"

#include <orbis/libkernel.h>
#include <orbis/VideoOut.h>
#include <orbis/Pad.h>
#include <orbis/UserService.h>

static int g_video = -1;
static OrbisKernelEqueue g_eq;
static uint32_t *g_fb[2];
static int g_cur = 0;
static int g_frame = 0;
static int g_pad = -1;

bool plat_init() {
    g_video = sceVideoOutOpen(ORBIS_VIDEO_USER_MAIN, ORBIS_VIDEO_OUT_BUS_MAIN, 0, 0);
    if (g_video < 0) return false;

    if (sceKernelCreateEqueue(&g_eq, "mcstore flip") < 0) return false;
    sceVideoOutAddFlipEvent(g_eq, g_video, 0);

    // Memoria de video: 2 buffers de 1920x1080x4 (~16,6 MB) dentro de 32 MB alineados a 2 MB.
    const size_t fbSize = (size_t)SCREEN_W * SCREEN_H * 4;
    const size_t total = 0x2000000;
    const size_t align = 0x200000;
    off_t off = 0;
    if (sceKernelAllocateDirectMemory(0, sceKernelGetDirectMemorySize(), total, align, 3, &off) < 0) return false;
    void *mem = NULL;
    if (sceKernelMapDirectMemory(&mem, total, 0x33, 0, off, align) < 0) return false;

    g_fb[0] = (uint32_t *)mem;
    g_fb[1] = (uint32_t *)((char *)mem + fbSize);

    OrbisVideoOutBufferAttribute attr;
    sceVideoOutSetBufferAttribute(&attr, 0x80000000, 1, 0, SCREEN_W, SCREEN_H, SCREEN_W);
    void *addrs[2] = {g_fb[0], g_fb[1]};
    if (sceVideoOutRegisterBuffers(g_video, 0, addrs, 2, &attr) != 0) return false;
    sceVideoOutSetFlipRate(g_video, 0);

    // Mando del usuario principal.
    if (scePadInit() != 0) return false;
    OrbisUserServiceInitializeParams p;
    p.priority = ORBIS_KERNEL_PRIO_FIFO_LOWEST;
    sceUserServiceInitialize(&p);
    int32_t uid = 0;
    sceUserServiceGetInitialUser(&uid);
    g_pad = scePadOpen(uid, 0, 0, NULL);
    return g_pad >= 0;
}

uint32_t plat_buttons() {
    OrbisPadData d;
    if (g_pad < 0 || scePadReadState(g_pad, &d) != 0) return 0;
    uint32_t b = d.buttons, m = 0;
    if (b & ORBIS_PAD_BUTTON_UP) m |= BTN_UP;
    if (b & ORBIS_PAD_BUTTON_DOWN) m |= BTN_DOWN;
    if (b & ORBIS_PAD_BUTTON_LEFT) m |= BTN_LEFT;
    if (b & ORBIS_PAD_BUTTON_RIGHT) m |= BTN_RIGHT;
    if (b & ORBIS_PAD_BUTTON_CROSS) m |= BTN_CROSS;
    if (b & ORBIS_PAD_BUTTON_CIRCLE) m |= BTN_CIRCLE;
    if (b & ORBIS_PAD_BUTTON_SQUARE) m |= BTN_SQUARE;
    if (b & ORBIS_PAD_BUTTON_TRIANGLE) m |= BTN_TRIANGLE;
    if (b & ORBIS_PAD_BUTTON_L1) m |= BTN_L1;
    if (b & ORBIS_PAD_BUTTON_R1) m |= BTN_R1;
    if (b & ORBIS_PAD_BUTTON_OPTIONS) m |= BTN_OPTIONS;
    return m;
}

uint32_t *plat_framebuffer() { return g_fb[g_cur]; }

void plat_present() {
    sceVideoOutSubmitFlip(g_video, g_cur, ORBIS_VIDEO_OUT_FLIP_VSYNC, g_frame);
    for (;;) {
        OrbisVideoOutFlipStatus st;
        sceVideoOutGetFlipStatus(g_video, &st);
        if (st.flipArg == g_frame) break;
        OrbisKernelEvent evt;
        int count;
        if (sceKernelWaitEqueue(g_eq, &evt, 1, &count, 0) != 0) break;
    }
    g_frame++;
    g_cur ^= 1;
}

void plat_sleep_ms(int ms) { sceKernelUsleep((uint32_t)ms * 1000u); }
uint64_t plat_ms() { return sceKernelGetProcessTime() / 1000u; }
const char *plat_data_dir() { return "/data/mcstore"; }
