// Tienda McStore v2: catalogo de CurseForge por paginas (lo genera tools/cf_sync.py en GitHub Actions).
// Todo lo de red va en UN hilo aparte (cola de pedidos): la pantalla nunca se congela y solo se baja lo que se ve.
//
//   meta.tsv       categorias y cantidades              (pequeno: abre al instante)
//   <k><n>.tsv     pagina n (40 add-ons) de la categoria k, con foto, descripcion y enlace
//   index.tsv      un renglon por add-on, solo para buscar (se baja la primera vez que buscas)
//   cache/<id>.img miniatura ya bajada (PNG/JPEG original) para no volver a pedirla
#pragma once
#include <atomic>
#include <mutex>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <thread>

#include "net.h"
#include "platform.h"

// Decodificador de imagenes (PNG/JPEG) de un solo archivo: stb_image (dominio publico / MIT).
#define STBI_NO_STDIO
#define STBI_NO_HDR
#define STBI_NO_LINEAR
#define STBI_ONLY_PNG
#define STBI_ONLY_JPEG
#define STBI_NO_SIMD
#define STBI_ASSERT(x) ((void)0)
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define SPAGE 40
#define S_MAXCLS 8
#define S_MAXPAGES 260
#define S_THUMB 256
#define S_IMGCACHE 6

struct SItem {
    int id;
    long size, dl;
    char name[56], author[32], ver[24], file[96], summary[236], thumb[136], url[240];
};
struct SPage {
    SItem *it;
    int n;
    unsigned char st;  // 0 = no pedida, 1 = en cola/bajando, 2 = lista, 3 = fallo
};
struct SClass {
    char key;
    char name[28];
    int count, pages;
    SPage pg[S_MAXPAGES];
};
struct SIdx {
    unsigned char cls;
    unsigned short page;  // 1..
    unsigned char slot;
    int dl;
    char ver[12];
    char name[52];
};
struct SImg {
    int id;
    int w, h;
    uint32_t *px;
    unsigned stamp;
};

struct Store {
    std::mutex mu;
    char base[300];
    int gen;               // sube al recargar: los pedidos viejos se descartan
    int metaSt;            // 0 no pedido, 1 cargando, 2 listo, 3 fallo
    char err[200];
    char generated[40];
    long total;
    int ncls;
    SClass cls[S_MAXCLS];
    int idxSt;
    SIdx *idx;
    int idxN;
    std::atomic<long> idxDone, idxTotal;
    // cola de pedidos (1 = meta, 2 = pagina, 3 = indice)
    struct Req { int kind, cls, page, gen; } q[24];
    int qn;
    // miniatura que se quiere ver ahora
    int wantId;
    char wantUrl[136];
    SImg img[S_IMGCACHE];
    unsigned stamp;
    int failed[48];
    int nfailed;
    bool started;
};
static Store ST;
static std::atomic<bool> g_netBusy(false);  // lo pone la app mientras baja un archivo: el hilo espera

static void s_mkdir_p(const char *dir) {
    char tmp[300];
    snprintf(tmp, sizeof(tmp), "%s", dir);
    for (char *p = tmp + 1; *p; p++)
        if (*p == '/') { *p = 0; mkdir(tmp, 0777); *p = '/'; }
    mkdir(tmp, 0777);
}

// ---------------- lectura de los TSV ----------------

// Separa el buffer en renglones (modifica el buffer). Devuelve el siguiente renglon o NULL.
static char *s_nextline(char **cur) {
    char *p = *cur;
    if (!p || !*p) return NULL;
    char *e = strchr(p, '\n');
    if (e) { *e = 0; *cur = e + 1; } else { *cur = p + strlen(p); }
    size_t l = strlen(p);
    if (l && p[l - 1] == '\r') p[l - 1] = 0;
    return p;
}
static int s_cols(char *line, char **c, int max) {
    int n = 0;
    c[n++] = line;
    for (char *p = line; *p && n < max; p++)
        if (*p == '\t') { *p = 0; c[n++] = p + 1; }
    return n;
}
static void s_copy(char *dst, size_t cap, const char *src) { snprintf(dst, cap, "%s", src); }

static bool s_parse_meta(char *buf) {
    int version = 0, ncls = 0;
    char *cur = buf, *ln;
    char gen[40] = "";
    long total = 0;
    SClass tmp[S_MAXCLS];
    memset(tmp, 0, sizeof(tmp));
    while ((ln = s_nextline(&cur))) {
        char *c[8];
        int n = s_cols(ln, c, 8);
        if (n >= 2 && !strcmp(c[0], "v")) version = atoi(c[1]);
        else if (n >= 2 && !strcmp(c[0], "generated")) s_copy(gen, sizeof(gen), c[1]);
        else if (n >= 2 && !strcmp(c[0], "total")) total = atol(c[1]);
        else if (n >= 5 && !strcmp(c[0], "class") && ncls < S_MAXCLS) {
            tmp[ncls].key = c[1][0];
            s_copy(tmp[ncls].name, sizeof(tmp[ncls].name), c[2]);
            tmp[ncls].count = atoi(c[3]);
            tmp[ncls].pages = atoi(c[4]);
            if (tmp[ncls].pages > S_MAXPAGES) tmp[ncls].pages = S_MAXPAGES;
            if (tmp[ncls].count > 0 && tmp[ncls].pages > 0) ncls++;
        }
    }
    if (version != 2 || ncls == 0) return false;
    std::lock_guard<std::mutex> g(ST.mu);
    for (int i = 0; i < ncls; i++) {
        ST.cls[i].key = tmp[i].key;
        s_copy(ST.cls[i].name, sizeof(ST.cls[i].name), tmp[i].name);
        ST.cls[i].count = tmp[i].count;
        ST.cls[i].pages = tmp[i].pages;
    }
    ST.ncls = ncls;
    ST.total = total;
    s_copy(ST.generated, sizeof(ST.generated), gen);
    return true;
}

static SItem *s_parse_page(char *buf, int *outN) {
    SItem *items = (SItem *)calloc(SPAGE, sizeof(SItem));
    if (!items) return NULL;
    int n = 0;
    char *cur = buf, *ln;
    while (n < SPAGE && (ln = s_nextline(&cur))) {
        char *c[10];
        if (s_cols(ln, c, 10) < 9) continue;  // id name author dl ver size file url thumb [summary]
        SItem &it = items[n];
        it.id = atoi(c[0]);
        s_copy(it.name, sizeof(it.name), c[1]);
        s_copy(it.author, sizeof(it.author), c[2]);
        it.dl = atol(c[3]);
        s_copy(it.ver, sizeof(it.ver), c[4]);
        it.size = atol(c[5]);
        s_copy(it.file, sizeof(it.file), c[6]);
        s_copy(it.url, sizeof(it.url), c[7]);
        s_copy(it.thumb, sizeof(it.thumb), c[8]);
        s_copy(it.summary, sizeof(it.summary), c[9] ? c[9] : "");
        if (it.id && it.url[0]) n++;
        else memset(&it, 0, sizeof(it));
    }
    *outN = n;
    return items;
}

static bool s_parse_index(char *buf) {
    int lines = 0;
    for (char *p = buf; *p; p++) if (*p == '\n') lines++;
    SIdx *idx = (SIdx *)calloc((size_t)lines + 1, sizeof(SIdx));
    if (!idx) return false;
    int n = 0;
    char *cur = buf, *ln;
    while ((ln = s_nextline(&cur))) {
        char *c[6];
        if (s_cols(ln, c, 6) < 6) continue;  // clave pagina posicion descargas version nombre
        int ci = -1;
        for (int i = 0; i < ST.ncls; i++) if (ST.cls[i].key == c[0][0]) ci = i;
        if (ci < 0) continue;
        SIdx &e = idx[n++];
        e.cls = (unsigned char)ci;
        e.page = (unsigned short)atoi(c[1]);
        e.slot = (unsigned char)atoi(c[2]);
        e.dl = atoi(c[3]);
        s_copy(e.ver, sizeof(e.ver), c[4]);
        s_copy(e.name, sizeof(e.name), c[5]);
    }
    std::lock_guard<std::mutex> g(ST.mu);
    free(ST.idx);
    ST.idx = idx;
    ST.idxN = n;
    return true;
}

// ---------------- miniaturas ----------------

static bool s_is_failed(int id) {
    for (int i = 0; i < ST.nfailed && i < 48; i++) if (ST.failed[i] == id) return true;
    return false;
}
static bool s_have_img(int id) {
    for (int i = 0; i < S_IMGCACHE; i++) if (ST.img[i].px && ST.img[i].id == id) return true;
    return false;
}

static void s_cache_path(int id, char *out, size_t cap) { snprintf(out, cap, "%s/cache/%d.img", plat_data_dir(), id); }

static bool s_read_file(const char *path, unsigned char **buf, long *len, long max) {
    FILE *f = fopen(path, "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (n <= 0 || n > max) { fclose(f); return false; }
    *buf = (unsigned char *)malloc((size_t)n);
    if (!*buf) { fclose(f); return false; }
    bool ok = fread(*buf, 1, (size_t)n, f) == (size_t)n;
    fclose(f);
    if (!ok) { free(*buf); *buf = NULL; return false; }
    *len = n;
    return true;
}

static const unsigned S_BG = (30u << 16) | (38u << 8) | 34u;  // color del panel: la transparencia se mezcla con el

static void s_do_thumb(int id, const char *url, int gen) {
    char path[300];
    s_cache_path(id, path, sizeof(path));
    unsigned char *buf = NULL;
    long len = 0;
    bool fromCache = s_read_file(path, &buf, &len, 2 * 1024 * 1024);
    if (!fromCache) {
        char err[120];
        char *mem = NULL;
        long ml = 0;
        if (url[0] && fetch(url, &mem, &ml, 2 * 1024 * 1024, NULL, NULL, NULL, err, sizeof(err)) == 200 && ml > 0) {
            buf = (unsigned char *)mem;
            len = ml;
        } else {
            free(mem);
        }
    }
    int w = 0, h = 0, comp = 0;
    unsigned char *rgba = buf ? stbi_load_from_memory(buf, (int)len, &w, &h, &comp, 4) : NULL;
    if (!rgba || w <= 0 || h <= 0) {
        if (fromCache) remove(path);  // cache danado
        free(buf);
        if (rgba) stbi_image_free(rgba);
        std::lock_guard<std::mutex> g(ST.mu);
        if (!s_is_failed(id)) ST.failed[ST.nfailed++ % 48] = id;
        return;
    }
    if (!fromCache) {  // guarda el original para la proxima vez
        char dir[300];
        snprintf(dir, sizeof(dir), "%s/cache", plat_data_dir());
        s_mkdir_p(dir);
        FILE *f = fopen(path, "wb");
        if (f) { fwrite(buf, 1, (size_t)len, f); fclose(f); }
    }
    free(buf);
    // a 0x80RRGGBB, mezclando la transparencia, reducido (vecino mas cercano) a como mucho 256x256
    int dw = w, dh = h;
    if (dw > S_THUMB || dh > S_THUMB) {
        if (dw >= dh) { dh = dh * S_THUMB / dw; dw = S_THUMB; } else { dw = dw * S_THUMB / dh; dh = S_THUMB; }
        if (dh < 1) dh = 1;
        if (dw < 1) dw = 1;
    }
    uint32_t *px = (uint32_t *)malloc((size_t)dw * dh * 4);
    if (px) {
        for (int y = 0; y < dh; y++)
            for (int x = 0; x < dw; x++) {
                const unsigned char *s = rgba + ((size_t)(y * h / dh) * w + (size_t)(x * w / dw)) * 4;
                unsigned a = s[3];
                unsigned r = (s[0] * a + ((S_BG >> 16) & 255) * (255 - a)) / 255;
                unsigned g = (s[1] * a + ((S_BG >> 8) & 255) * (255 - a)) / 255;
                unsigned b = (s[2] * a + (S_BG & 255) * (255 - a)) / 255;
                px[(size_t)y * dw + x] = 0x80000000u | (r << 16) | (g << 8) | b;
            }
    }
    stbi_image_free(rgba);
    if (!px) return;
    std::lock_guard<std::mutex> g(ST.mu);
    if (gen != ST.gen) { free(px); return; }
    int slot = 0;
    for (int i = 0; i < S_IMGCACHE; i++) {
        if (!ST.img[i].px) { slot = i; break; }
        if (ST.img[i].stamp < ST.img[slot].stamp) slot = i;
    }
    free(ST.img[slot].px);
    ST.img[slot].id = id;
    ST.img[slot].w = dw;
    ST.img[slot].h = dh;
    ST.img[slot].px = px;
    ST.img[slot].stamp = ++ST.stamp;
}

// ---------------- hilo de red ----------------

static bool s_progress(long done, long total, void *) {
    ST.idxDone = done;
    ST.idxTotal = total;
    return true;
}

static void s_do_req(const Store::Req &r) {
    char url[420], err[200] = "";
    char *buf = NULL;
    long len = 0;
    if (r.kind == 1) {
        snprintf(url, sizeof(url), "%smeta.tsv", ST.base);
        int st = fetch(url, &buf, &len, 64 * 1024, NULL, NULL, NULL, err, sizeof(err));
        bool ok = st == 200 && s_parse_meta(buf);
        if (st == 200 && !ok) snprintf(err, sizeof(err), "catalogo de formato no soportado");
        std::lock_guard<std::mutex> g(ST.mu);
        if (r.gen == ST.gen) {
            ST.metaSt = ok ? 2 : 3;
            if (!ok) snprintf(ST.err, sizeof(ST.err), "%s", err[0] ? err : "no se pudo leer meta.tsv");
        }
    } else if (r.kind == 2) {
        char key = ST.cls[r.cls].key;
        snprintf(url, sizeof(url), "%s%c%d.tsv", ST.base, key, r.page);
        int st = fetch(url, &buf, &len, 256 * 1024, NULL, NULL, NULL, err, sizeof(err));
        int n = 0;
        SItem *items = (st == 200) ? s_parse_page(buf, &n) : NULL;
        std::lock_guard<std::mutex> g(ST.mu);
        SPage &pg = ST.cls[r.cls].pg[r.page - 1];
        if (r.gen != ST.gen) { free(items); }
        else if (items && n > 0) { pg.it = items; pg.n = n; pg.st = 2; }
        else { free(items); pg.st = 3; }
    } else if (r.kind == 3) {
        snprintf(url, sizeof(url), "%sindex.tsv", ST.base);
        ST.idxDone = 0;
        ST.idxTotal = 0;
        int st = fetch(url, &buf, &len, 12 * 1024 * 1024, NULL, s_progress, NULL, err, sizeof(err));
        bool ok = st == 200 && s_parse_index(buf);
        std::lock_guard<std::mutex> g(ST.mu);
        if (r.gen == ST.gen) ST.idxSt = ok ? 2 : 3;
    }
    free(buf);
}

static void s_worker() {
    for (;;) {
        if (g_netBusy.load()) { plat_sleep_ms(100); continue; }
        Store::Req r;
        bool have = false;
        int tid = 0, gen = 0;
        char turl[136] = "";
        {
            std::lock_guard<std::mutex> g(ST.mu);
            if (ST.qn > 0) {
                r = ST.q[0];
                memmove(ST.q, ST.q + 1, sizeof(ST.q[0]) * (size_t)(ST.qn - 1));
                ST.qn--;
                have = true;
            } else if (ST.wantId && !s_have_img(ST.wantId) && !s_is_failed(ST.wantId)) {
                tid = ST.wantId;
                gen = ST.gen;
                s_copy(turl, sizeof(turl), ST.wantUrl);
            }
        }
        if (have) { if (r.gen == ST.gen) s_do_req(r); }
        else if (tid) s_do_thumb(tid, turl, gen);
        else plat_sleep_ms(30);
    }
}

// ---------------- API para la pantalla (hilo principal) ----------------

static void store_enqueue(int kind, int cls, int page) {  // con ST.mu tomado
    for (int i = 0; i < ST.qn; i++)
        if (ST.q[i].kind == kind && ST.q[i].cls == cls && ST.q[i].page == page) return;
    if (ST.qn >= 24) return;
    ST.q[ST.qn++] = {kind, cls, page, ST.gen};
}

static void store_start(const char *base) {
    {
        std::lock_guard<std::mutex> g(ST.mu);
        s_copy(ST.base, sizeof(ST.base), base);
        size_t l = strlen(ST.base);
        if (l && ST.base[l - 1] != '/' && l + 1 < sizeof(ST.base)) { ST.base[l] = '/'; ST.base[l + 1] = 0; }
        ST.metaSt = 1;
        ST.err[0] = 0;
        store_enqueue(1, 0, 0);
    }
    if (!ST.started) {
        ST.started = true;
        try { std::thread(s_worker).detach(); } catch (...) { ST.metaSt = 3; s_copy(ST.err, sizeof(ST.err), "no se pudo iniciar el hilo"); }
    }
}

// Borra lo bajado (paginas, indice, miniaturas en memoria) y vuelve a pedir meta.tsv.
static void store_reload() {
    std::lock_guard<std::mutex> g(ST.mu);
    ST.gen++;
    ST.qn = 0;
    for (int c = 0; c < ST.ncls; c++)
        for (int p = 0; p < S_MAXPAGES; p++) { free(ST.cls[c].pg[p].it); ST.cls[c].pg[p] = SPage(); }
    ST.ncls = 0;
    free(ST.idx);
    ST.idx = NULL;
    ST.idxN = 0;
    ST.idxSt = 0;
    ST.metaSt = 1;
    ST.err[0] = 0;
    store_enqueue(1, 0, 0);
}

static void store_want_page(int cls, int page) {  // page: 1..
    std::lock_guard<std::mutex> g(ST.mu);
    if (cls < 0 || cls >= ST.ncls || page < 1 || page > ST.cls[cls].pages) return;
    SPage &pg = ST.cls[cls].pg[page - 1];
    if (pg.st == 0) { pg.st = 1; store_enqueue(2, cls, page); }
}
static void store_retry_page(int cls, int page) {
    std::lock_guard<std::mutex> g(ST.mu);
    if (cls < 0 || cls >= ST.ncls || page < 1 || page > ST.cls[cls].pages) return;
    SPage &pg = ST.cls[cls].pg[page - 1];
    if (pg.st == 3) { pg.st = 1; store_enqueue(2, cls, page); }
}
static void store_want_index() {
    std::lock_guard<std::mutex> g(ST.mu);
    if (ST.idxSt == 0 || ST.idxSt == 3) { ST.idxSt = 1; store_enqueue(3, 0, 0); }
}

// Devuelve el add-on si su pagina ya esta bajada (si no, la pide y devuelve NULL).
static const SItem *store_item(int cls, int page, int slot) {
    std::lock_guard<std::mutex> g(ST.mu);
    if (cls < 0 || cls >= ST.ncls || page < 1 || page > ST.cls[cls].pages) return NULL;
    SPage &pg = ST.cls[cls].pg[page - 1];
    if (pg.st == 0) { pg.st = 1; store_enqueue(2, cls, page); return NULL; }
    if (pg.st != 2 || slot < 0 || slot >= pg.n) return NULL;
    return &pg.it[slot];
}

static void lower_ascii(char *t) { for (; *t; t++) if (*t >= 'A' && *t <= 'Z') *t = (char)(*t + 32); }

// Busca en el indice: todas las palabras deben estar en "nombre version". Resultados por descargas (mayor primero).
static int s_cmp_dl(const void *a, const void *b) {
    int x = *(const int *)a, y = *(const int *)b;
    int dx = ST.idx[x].dl, dy = ST.idx[y].dl;
    return dx < dy ? 1 : (dx > dy ? -1 : x - y);
}
static int store_search(const char *query, int *rows, int max) {
    std::lock_guard<std::mutex> g(ST.mu);
    if (ST.idxSt != 2 || !ST.idx) return 0;
    char q[48], *words[6];
    int nw = 0;
    snprintf(q, sizeof(q), "%s", query);
    lower_ascii(q);
    for (char *p = strtok(q, " "); p && nw < 6; p = strtok(NULL, " ")) words[nw++] = p;
    int n = 0;
    for (int i = 0; i < ST.idxN && n < max; i++) {
        char hay[80];
        snprintf(hay, sizeof(hay), "%s %s", ST.idx[i].name, ST.idx[i].ver);
        lower_ascii(hay);
        bool all = true;
        for (int w = 0; w < nw && all; w++) if (!strstr(hay, words[w])) all = false;
        if (all) rows[n++] = i;
    }
    qsort(rows, (size_t)n, sizeof(int), s_cmp_dl);
    return n;
}
static SIdx store_idx(int i) {
    std::lock_guard<std::mutex> g(ST.mu);
    SIdx z;
    memset(&z, 0, sizeof(z));
    return (ST.idx && i >= 0 && i < ST.idxN) ? ST.idx[i] : z;
}

// Pide la miniatura de un add-on (se baja cuando el hilo esta libre). id = 0: ninguna.
static void store_want_thumb(int id, const char *url) {
    std::lock_guard<std::mutex> g(ST.mu);
    ST.wantId = id;
    if (id) s_copy(ST.wantUrl, sizeof(ST.wantUrl), url);
}
// Copia la miniatura (si ya esta) a `dst` (256x256 como maximo). Devuelve 1 si esta, -1 si fallo, 0 si aun no.
static int store_thumb_copy(int id, uint32_t *dst, int *w, int *h) {
    std::lock_guard<std::mutex> g(ST.mu);
    for (int i = 0; i < S_IMGCACHE; i++)
        if (ST.img[i].px && ST.img[i].id == id) {
            memcpy(dst, ST.img[i].px, (size_t)ST.img[i].w * ST.img[i].h * 4);
            *w = ST.img[i].w;
            *h = ST.img[i].h;
            ST.img[i].stamp = ++ST.stamp;
            return 1;
        }
    return s_is_failed(id) ? -1 : 0;
}
