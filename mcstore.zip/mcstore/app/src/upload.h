// Subir packs desde el telefono: la propia PS4 abre una paginita web (puerto 8080).
// En el telefono: Safari -> http://IP-de-la-PS4:8080 -> elegir .mcpack/.mcaddon -> Subir.
// Los archivos caen en <datos>/downloads, que es lo que ve la pantalla "Instalar en Minecraft".
#pragma once
#include <atomic>
#include <mutex>
#include <thread>

// por si la libreria de la consola no trae alguna (asi nunca falla el enlazado)
#pragma weak getsockname
#pragma weak bind
#pragma weak listen
#pragma weak accept

#define UP_PORT_FIRST 8080
#define UP_MAX_BYTES (900L * 1024L * 1024L)

static std::atomic<int> g_upRun(0);     // 1 = servidor encendido
static std::atomic<int> g_upAlive(0);   // 1 = el hilo del servidor sigue vivo
static std::atomic<int> g_upCount(0);   // archivos recibidos desde que se abrio la app
static std::atomic<long> g_upCur(0), g_upTot(0);
static std::atomic<int> g_upPort(0);    // 0 = no se pudo abrir
static std::mutex g_upMx;
static char g_upLast[100] = "";
static char g_upMsg[160] = "";
static char g_upIp[24] = "";

static void up_msg(const char *fmt, const char *a) {
    std::lock_guard<std::mutex> lk(g_upMx);
    snprintf(g_upMsg, sizeof(g_upMsg), fmt, a);
}

// IP de la consola en la red (UDP "conectado" a un destino cualquiera: no manda nada, solo elige la interfaz)
static void up_find_ip() {
    snprintf(g_upIp, sizeof(g_upIp), "?");
    if (!getsockname) return;
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) return;
    struct sockaddr_in a;
    memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_port = htons(53);
    unsigned char *b = (unsigned char *)&a.sin_addr;
    b[0] = 8; b[1] = 8; b[2] = 8; b[3] = 8;
    if (connect(fd, (struct sockaddr *)&a, sizeof(a)) == 0) {
        struct sockaddr_in me;
        socklen_t l = sizeof(me);
        memset(&me, 0, sizeof(me));
        if (getsockname(fd, (struct sockaddr *)&me, &l) == 0) {
            unsigned char *m = (unsigned char *)&me.sin_addr;
            if (m[0] | m[1] | m[2] | m[3]) snprintf(g_upIp, sizeof(g_upIp), "%d.%d.%d.%d", m[0], m[1], m[2], m[3]);
        }
    }
    close(fd);
}

static const char UP_PAGE[] =
    "<!doctype html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
    "<title>McStore</title><style>"
    "body{font-family:-apple-system,Helvetica,Arial,sans-serif;background:#16181d;color:#eee;margin:0;padding:22px;max-width:640px;margin:auto}"
    "h1{color:#6fd45a;margin:.2em 0}p{color:#aab}label.b,button{display:block;width:100%;box-sizing:border-box;padding:16px;margin:12px 0;"
    "border:0;border-radius:12px;font-size:18px;text-align:center;background:#6fd45a;color:#10200a;font-weight:700}"
    "button[disabled]{opacity:.4}input{display:none}.f{background:#262a33;border-radius:10px;padding:10px 12px;margin:8px 0;word-break:break-all}"
    ".bar{height:8px;background:#3a3f4b;border-radius:4px;margin-top:6px}.bar i{display:block;height:8px;background:#6fd45a;border-radius:4px;width:0}"
    ".ok{color:#6fd45a}.er{color:#ff7a6b}</style></head><body>"
    "<h1>McStore</h1><p>Sube tus .mcpack o .mcaddon a la PS4. / Upload your .mcpack or .mcaddon to the PS4.</p>"
    "<label class=b for=f>1. Elegir archivos / Choose files</label><input id=f type=file multiple>"
    "<div id=l></div><button id=go disabled>2. Subir / Upload</button>"
    "<p id=t></p><script>"
    "var f=document.getElementById('f'),l=document.getElementById('l'),go=document.getElementById('go'),t=document.getElementById('t');"
    "f.onchange=function(){l.innerHTML='';for(var i=0;i<f.files.length;i++){var d=document.createElement('div');d.className='f';"
    "d.innerHTML=f.files[i].name+' ('+Math.round(f.files[i].size/1024)+' KB)<div class=bar><i></i></div>';l.appendChild(d)}go.disabled=!f.files.length};"
    "function up(i){if(i>=f.files.length){t.innerHTML='<b class=ok>Listo. En la PS4 pulsa R2 para instalar. / Done: press R2 on the PS4.</b>';go.disabled=false;return}"
    "var d=l.children[i],bar=d.querySelector('i'),x=new XMLHttpRequest();x.open('PUT','/up?name='+encodeURIComponent(f.files[i].name));"
    "x.upload.onprogress=function(e){if(e.lengthComputable)bar.style.width=(100*e.loaded/e.total)+'%'};"
    "x.onload=function(){if(x.status==200){bar.style.width='100%';d.className='f ok'}else{d.className='f er';d.innerHTML+='<br>'+x.responseText}up(i+1)};"
    "x.onerror=function(){d.className='f er';d.innerHTML+='<br>Error de red / network error';up(i+1)};x.send(f.files[i])}"
    "go.onclick=function(){go.disabled=true;t.textContent='';up(0)};"
    "</script></body></html>";

static int up_hex(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static void up_reply(int fd, int code, const char *type, const char *body, size_t blen) {
    char h[200];
    int n = snprintf(h, sizeof(h), "HTTP/1.0 %d %s\r\nContent-Type: %s\r\nContent-Length: %d\r\nConnection: close\r\n\r\n", code,
                     code == 200 ? "OK" : "ERR", type, (int)blen);
    send_all(fd, h, (size_t)n);
    if (blen) send_all(fd, body, blen);
}

static bool up_ext_ok(const char *name) {
    const char *dot = strrchr(name, '.');
    return dot && (!strcasecmp(dot, ".mcpack") || !strcasecmp(dot, ".mcaddon"));
}

static void up_client(int fd) {
    struct timeval tv;
    tv.tv_sec = 20;
    tv.tv_usec = 0;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    char *buf = (char *)malloc(65536 + 1);
    if (!buf) { close(fd); return; }
    int have = 0, hdrEnd = -1;
    while (have < 8192 && hdrEnd < 0) {
        ssize_t r = recv(fd, buf + have, (size_t)(8192 - have), 0);
        if (r <= 0) break;
        have += (int)r;
        buf[have] = 0;
        const char *e = strstr(buf, "\r\n\r\n");
        if (e) hdrEnd = (int)(e - buf) + 4;
    }
    if (hdrEnd < 0) { free(buf); close(fd); return; }
    buf[hdrEnd - 2] = 0;  // cabeceras como texto
    if (!strncmp(buf, "GET ", 4)) {
        if (!strncmp(buf + 4, "/ ", 2) || !strncmp(buf + 4, "/index", 6)) up_reply(fd, 200, "text/html; charset=utf-8", UP_PAGE, sizeof(UP_PAGE) - 1);
        else up_reply(fd, 404, "text/plain", "no", 2);
    } else if (!strncmp(buf, "PUT /up?name=", 13)) {
        char raw[300], name[120];
        const char *q = buf + 13;
        size_t o = 0;
        for (; *q && *q != ' ' && o + 1 < sizeof(raw); q++) {
            if (*q == '%' && up_hex(q[1]) >= 0 && up_hex(q[2]) >= 0) { raw[o++] = (char)(up_hex(q[1]) * 16 + up_hex(q[2])); q += 2; }
            else raw[o++] = *q == '+' ? ' ' : *q;
        }
        raw[o] = 0;
        safe_filename(raw, name, sizeof(name));
        long clen = -1;
        header_has(buf, "Content-Length:", &clen);
        if (!up_ext_ok(name)) {
            up_reply(fd, 400, "text/plain", "Solo .mcpack o .mcaddon / only .mcpack or .mcaddon", 51);
            up_msg("Rechazado (solo .mcpack/.mcaddon): %.100s", name);
        } else if (clen <= 0 || clen > UP_MAX_BYTES) {
            up_reply(fd, 400, "text/plain", "Tamano no valido / bad size", 27);
        } else {
            char dir[300], part[460], fin[460];
            snprintf(dir, sizeof(dir), "%s/downloads", plat_data_dir());
            mkdir_p(dir);
            snprintf(part, sizeof(part), "%s/%s.part", dir, name);
            snprintf(fin, sizeof(fin), "%s/%s", dir, name);
            FILE *fp = fopen(part, "wb");
            bool ok = fp != NULL;
            long got = 0;
            g_upCur = 0;
            g_upTot = clen;
            { std::lock_guard<std::mutex> lk(g_upMx); snprintf(g_upLast, sizeof(g_upLast), "%s", name); }
            if (ok && have > hdrEnd) {
                long first = have - hdrEnd;
                if (first > clen) first = clen;
                ok = fwrite(buf + hdrEnd, 1, (size_t)first, fp) == (size_t)first;
                got = first;
            }
            while (ok && got < clen) {
                long want = clen - got < 65536 ? clen - got : 65536;
                ssize_t r = recv(fd, buf, (size_t)want, 0);
                if (r <= 0) { ok = false; break; }
                if (fwrite(buf, 1, (size_t)r, fp) != (size_t)r) { ok = false; break; }
                got += r;
                g_upCur = got;
            }
            if (fp) fclose(fp);
            if (ok) {
                remove(fin);
                ok = rename(part, fin) == 0;
            }
            if (ok) {
                up_reply(fd, 200, "text/plain", "ok", 2);
                up_msg("Recibido: %.100s", name);
                g_upCount++;
            } else {
                remove(part);
                up_reply(fd, 500, "text/plain", "No se pudo guardar / could not save", 35);
                up_msg("Fallo al recibir: %.100s", name);
            }
        }
    } else {
        up_reply(fd, 404, "text/plain", "no", 2);
    }
    free(buf);
    close(fd);
}

static void up_server() {
    g_upAlive = 1;
    int lfd = socket(AF_INET, SOCK_STREAM, 0);
    int port = 0;
    if (lfd >= 0 && bind && listen && accept) {
        int one = 1;
        setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
        for (int p = UP_PORT_FIRST; p < UP_PORT_FIRST + 10 && !port; p++) {
            struct sockaddr_in a;
            memset(&a, 0, sizeof(a));
            a.sin_family = AF_INET;
            a.sin_port = htons((unsigned short)p);
            if (bind(lfd, (struct sockaddr *)&a, sizeof(a)) == 0 && listen(lfd, 4) == 0) port = p;
        }
    }
    if (!port) {
        up_msg("%s", "No se pudo abrir el servidor (red no disponible?)");
        if (lfd >= 0) close(lfd);
        g_upPort = 0;
        g_upRun = 0;
        g_upAlive = 0;
        return;
    }
    struct timeval tv;
    tv.tv_sec = 1;
    tv.tv_usec = 0;
    setsockopt(lfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    g_upPort = port;
    while (g_upRun.load()) {
        int c = accept(lfd, NULL, NULL);
        if (c < 0) continue;
        try { std::thread(up_client, c).detach(); } catch (...) { close(c); }
    }
    close(lfd);
    g_upPort = 0;
    g_upAlive = 0;
}

static void up_start() {
    g_upRun = 1;
    up_find_ip();
    { std::lock_guard<std::mutex> lk(g_upMx); g_upMsg[0] = 0; }
    if (g_upAlive.load()) return;  // el hilo anterior aun no termino: sigue sirviendo
    g_upAlive = 1;
    try { std::thread(up_server).detach(); } catch (...) { g_upAlive = 0; g_upRun = 0; up_msg("%s", "No se pudo iniciar el servidor"); }
}

static void up_stop() { g_upRun = 0; }

static void draw_upload() {
    draw_header("McStore - Subir desde el telefono");
    static int lastCount = 0;
    int cnt = g_upCount.load();
    if (cnt != lastCount) { if (cnt > lastCount) sfx(SFX_DONE); lastCount = cnt; }
    int port = g_upPort.load();
    fill(140, 120, SCREEN_W - 280, 190, C_PANEL);
    fill(140, 120, 12, 190, C_ACCENT);
    text(180, 140, "Abre esta direccion en el navegador del telefono:", 2, C_DIM);
    char url[80];
    if (port) snprintf(url, sizeof(url), "http://%s:%d", g_upIp, port);
    else snprintf(url, sizeof(url), "Abriendo...");
    text((SCREEN_W - text_w(url, 5)) / 2, 190, url, 5, C_TEXT);
    text(180, 270, "El telefono y la PS4 deben estar en la misma red wifi.", 2, C_DIM);
    int y = 340;
    text(140, y, "1) Abre la direccion de arriba en Safari.", 3, C_TEXT);
    text(140, y + 52, "2) Toca \"Elegir archivos\" y escoge tus .mcpack o .mcaddon.", 3, C_TEXT);
    text(140, y + 104, "3) Toca \"Subir\". Aqui abajo veras cuando lleguen.", 3, C_TEXT);
    text(140, y + 156, "4) Pulsa R2 para instalarlos en Minecraft.", 3, C_TEXT);
    int by = 600;
    fill(140, by, SCREEN_W - 280, 150, mix(C_PANEL, C_TEXT, 6));
    char s[200];
    snprintf(s, sizeof(s), "Archivos recibidos: %d", cnt);
    text(170, by + 18, s, 3, C_OK);
    char last[100], msg[160];
    { std::lock_guard<std::mutex> lk(g_upMx); snprintf(last, sizeof(last), "%s", g_upLast); snprintf(msg, sizeof(msg), "%s", g_upMsg); }
    if (msg[0]) text(170, by + 62, msg, 2, C_TEXT, 100);
    long tot = g_upTot.load(), cur = g_upCur.load();
    if (last[0] && tot > 0 && cur < tot) {
        fill(170, by + 108, SCREEN_W - 340, 20, C_BAR);
        fill(170, by + 108, (int)((long long)(SCREEN_W - 340) * cur / tot), 20, C_ACCENT);
    }
    draw_footer("R2: instalar en Minecraft | Circulo: volver");
}
