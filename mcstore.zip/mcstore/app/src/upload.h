// Subir packs desde el telefono: la propia PS4 abre una paginita web (puerto 8080).
// En el telefono: Safari -> http://IP-de-la-PS4:8080 -> elegir .mcpack/.mcaddon -> Subir.
// Los archivos caen en <datos>/downloads, que es lo que ve la pantalla "Instalar en Minecraft".
#pragma once
#include <atomic>
#include <mutex>
#include <thread>

// por si la libreria de la consola no trae alguna (asi nunca falla el enlazado)
#pragma weak getsockname
#pragma weak bind
#pragma weak listen
#pragma weak accept

#define UP_PORT_FIRST 8080
#define UP_MAX_BYTES (900L * 1024L * 1024L)

static std::atomic<int> g_upRun(0);     // 1 = servidor encendido
static std::atomic<int> g_upAlive(0);   // 1 = el hilo del servidor sigue vivo
static std::atomic<int> g_upCount(0);   // archivos recibidos desde que se abrio la app
static std::atomic<long> g_upCur(0), g_upTot(0);
static std::atomic<int> g_upPort(0);    // 0 = no se pudo abrir
static std::mutex g_upMx;
static char g_upLast[100] = "";
static char g_upMsg[160] = "";
static char g_upIp[24] = "";

static void up_msg(const char *fmt, const char *a) {
    std::lock_guard<std::mutex> lk(g_upMx);
    snprintf(g_upMsg, sizeof(g_upMsg), fmt, a);
}

// IP de la consola en la red (UDP "conectado" a un destino cualquiera: no manda nada, solo elige la interfaz)
static void up_find_ip() {
    snprintf(g_upIp, sizeof(g_upIp), "?");
    if (!getsockname) return;
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) return;
    struct sockaddr_in a;
    memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_port = htons(53);
    unsigned char *b = (unsigned char *)&a.sin_addr;
    b[0] = 8; b[1] = 8; b[2] = 8; b[3] = 8;
    if (connect(fd, (struct sockaddr *)&a, sizeof(a)) == 0) {
        struct sockaddr_in me;
        socklen_t l = sizeof(me);
        memset(&me, 0, sizeof(me));
        if (getsockname(fd, (struct sockaddr *)&me, &l) == 0) {
            unsigned char *m = (unsigned char *)&me.sin_addr;
            if (m[0] | m[1] | m[2] | m[3]) snprintf(g_upIp, sizeof(g_upIp), "%d.%d.%d.%d", m[0], m[1], m[2], m[3]);
        }
    }
    close(fd);
}

static const char UP_PAGE[] =
    "<!doctype html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>McStore</title><style>\n"
    "body{font-family:-apple-system,Helvetica,Arial,sans-serif;background:#16181d;color:#eee;margin:0;padding:22px;max-width:640px;margin:auto}\n"
    "h1{color:#6fd45a;margin:.2em 0}p{color:#aab}\n"
    "label.b,button{display:block;width:100%;box-sizing:border-box;padding:16px;margin:12px 0;border:0;border-radius:12px;font-size:18px;text-align:center;background:#6fd45a;color:#10200a;font-weight:700}\n"
    "button[disabled]{opacity:.4}input[type=file]{display:none}\n"
    "input[type=password]{width:100%;box-sizing:border-box;padding:14px;margin:6px 0;border-radius:10px;border:1px solid #3a3f4b;background:#20232b;color:#eee;font-size:16px}\n"
    ".f{background:#262a33;border-radius:10px;padding:10px 12px;margin:8px 0;word-break:break-all}\n"
    ".bar{height:8px;background:#3a3f4b;border-radius:4px;margin-top:6px}.bar i{display:block;height:8px;background:#6fd45a;border-radius:4px;width:0}\n"
    ".ok{color:#6fd45a}.er{color:#ff7a6b}.pub{background:#262a33;border-radius:10px;padding:12px;margin:10px 0}summary{color:#6fd45a;font-weight:700;margin:14px 0}\n"
    "</style></head><body>\n"
    "<h1>McStore</h1><p>Sube tus .mcpack o .mcaddon a la PS4. / Upload your .mcpack or .mcaddon to the PS4.</p>\n"
    "<label class=b for=f>1. Elegir archivos / Choose files</label><input id=f type=file multiple>\n"
    "<div id=l></div>\n"
    "<div class=pub id=own style='display:none'><label><input type=checkbox id=pub checked style='display:inline;width:auto'> Publicar tambien para TODOS (catalogo de McStore)</label></div>\n"
    "<button id=go disabled>2. Subir / Upload</button><p id=t></p>\n"
    "<details id=cr><summary>Modo creador (solo para el dueno)</summary>\n"
    "<p>Pega tu token de GitHub (Contents: Read and write) para poder publicar para todos. Se guarda solo en la PS4.</p>\n"
    "<input id=tk type=password placeholder='github_pat_...' autocapitalize=off autocorrect=off><button id=stk type=button>Guardar token</button></details>\n"
    "<script>\n"
    "var f=document.getElementById('f'),l=document.getElementById('l'),go=document.getElementById('go'),t=document.getElementById('t'),own=document.getElementById('own'),pub=document.getElementById('pub');\n"
    "fetch('/info').then(function(r){return r.text()}).then(function(x){if(x=='1')own.style.display='block'}).catch(function(){});\n"
    "document.getElementById('stk').onclick=function(){var v=document.getElementById('tk').value.trim();var x=new XMLHttpRequest();x.open('PUT','/token');\n"
    "x.onload=function(){if(x.status==200){own.style.display='block';t.innerHTML='<b class=ok>Token guardado.</b>';document.getElementById('tk').value=''}else t.innerHTML='<span class=er>Token no valido</span>'};x.send(v)};\n"
    "f.onchange=function(){l.innerHTML='';for(var i=0;i<f.files.length;i++){var d=document.createElement('div');d.className='f';\n"
    "d.innerHTML=f.files[i].name+' ('+Math.round(f.files[i].size/1024)+' KB)<div class=bar><i></i></div>';l.appendChild(d)}go.disabled=!f.files.length};\n"
    "function up(i){if(i>=f.files.length){t.innerHTML='<b class=ok>Listo. En la PS4 pulsa R2 para instalar. / Done: press R2 on the PS4.</b>';go.disabled=false;return}\n"
    "var d=l.children[i],bar=d.querySelector('i'),x=new XMLHttpRequest();\n"
    "x.open('PUT','/up?name='+encodeURIComponent(f.files[i].name)+(own.style.display=='block'&&pub.checked?'&pub=1':''));\n"
    "x.upload.onprogress=function(e){if(e.lengthComputable)bar.style.width=(100*e.loaded/e.total)+'%'};\n"
    "x.onload=function(){if(x.status==200){bar.style.width='100%';d.className='f ok';if(x.responseText.indexOf('publicado')>0)d.innerHTML+='<br>Publicado para todos'}else{d.className='f er';d.innerHTML+='<br>'+x.responseText}up(i+1)};\n"
    "x.onerror=function(){d.className='f er';d.innerHTML+='<br>Error de red / network error';up(i+1)};x.send(f.files[i])}\n"
    "go.onclick=function(){go.disabled=true;t.textContent='';up(0)};\n"
    "</script></body></html>\n";

static int up_hex(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static void up_reply(int fd, int code, const char *type, const char *body, size_t blen) {
    char h[200];
    int n = snprintf(h, sizeof(h), "HTTP/1.0 %d %s\r\nContent-Type: %s\r\nContent-Length: %d\r\nConnection: close\r\n\r\n", code,
                     code == 200 ? "OK" : "ERR", type, (int)blen);
    send_all(fd, h, (size_t)n);
    if (blen) send_all(fd, body, blen);
}

static bool up_ext_ok(const char *name) {
    const char *dot = strrchr(name, '.');
    return dot && (!strcasecmp(dot, ".mcpack") || !strcasecmp(dot, ".mcaddon"));
}

// ---------- modo creador: publicar en GitHub (addons/) con el token guardado en la PS4 ----------
static void up_token_path(char *out, size_t cap) { snprintf(out, cap, "%s/github_token.txt", plat_data_dir()); }

static bool up_token_read(char *tok, size_t cap) {
    char p[300];
    up_token_path(p, sizeof(p));
    FILE *f = fopen(p, "r");
    if (!f) return false;
    char line[200] = "";
    if (!fgets(line, sizeof(line), f)) line[0] = 0;
    fclose(f);
    size_t o = 0;
    for (char *c = line; *c && o + 1 < cap; c++)
        if ((*c >= 'a' && *c <= 'z') || (*c >= 'A' && *c <= 'Z') || (*c >= '0' && *c <= '9') || *c == '_' || *c == '-') tok[o++] = *c;
    tok[o] = 0;
    return o >= 20;
}

// OWNER/REPO sale de la direccion del catalogo (https://raw.githubusercontent.com/OWNER/REPO/main/catalog.json)
static bool up_repo(char *out, size_t cap) {
    const char *p = strstr(A.catalogUrl, "githubusercontent.com/");
    if (!p) return false;
    p += 22;
    const char *s1 = strchr(p, '/');
    if (!s1) return false;
    const char *s2 = strchr(s1 + 1, '/');
    if (!s2) return false;
    snprintf(out, cap, "%.*s", (int)(s2 - p), p);
    return true;
}

static void b64_append(char *dst, size_t *w, const unsigned char *in, size_t n) {
    static const char T[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    size_t o = *w;
    for (size_t i = 0; i < n; i += 3) {
        unsigned v = in[i] << 16 | (i + 1 < n ? in[i + 1] << 8 : 0) | (i + 2 < n ? in[i + 2] : 0);
        dst[o++] = T[(v >> 18) & 63];
        dst[o++] = T[(v >> 12) & 63];
        dst[o++] = i + 1 < n ? T[(v >> 6) & 63] : '=';
        dst[o++] = i + 2 < n ? T[v & 63] : '=';
    }
    *w = o;
}

static bool up_publish(const char *path, const char *name, char *err, size_t ecap) {
    char tok[200], repo[100];
    if (!up_token_read(tok, sizeof(tok))) { snprintf(err, ecap, "falta el token de GitHub (Modo creador)"); return false; }
    if (!up_repo(repo, sizeof(repo))) { snprintf(err, ecap, "no se el repositorio (CATALOG_URL no es de GitHub)"); return false; }
    FILE *f = fopen(path, "rb");
    if (!f) { snprintf(err, ecap, "no se pudo leer el archivo"); return false; }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (sz <= 0 || sz > 60L * 1024L * 1024L) { fclose(f); snprintf(err, ecap, "el archivo pesa mas de 60 MB"); return false; }
    char enc[300], url[500];
    urlenc(name, enc, sizeof(enc));
    snprintf(url, sizeof(url), "https://api.github.com/repos/%s/contents/addons/%s", repo, enc);
    // si ya existe, GitHub pide su "sha" para reemplazarlo (si no se puede mirar, se intenta sin el)
    char sha[64] = "";
    char *cur = NULL;
    long cl = 0;
    char e2[100];
    if (fetch(url, &cur, &cl, 200000, NULL, NULL, NULL, e2, sizeof(e2)) == 200 && cur) {
        const char *s = strstr(cur, "\"sha\"");
        if (s) {
            s = strchr(s + 5, '"');
            if (s) { s++; const char *e = strchr(s, '"'); if (e && e - s < 63) { memcpy(sha, s, (size_t)(e - s)); sha[e - s] = 0; } }
        }
    }
    free(cur);
    size_t cap = (size_t)sz / 3 * 4 + 600;
    char *body = (char *)malloc(cap);
    unsigned char *raw = (unsigned char *)malloc((size_t)sz);
    if (!body || !raw || fread(raw, 1, (size_t)sz, f) != (size_t)sz) {
        fclose(f); free(body); free(raw);
        snprintf(err, ecap, "sin memoria");
        return false;
    }
    fclose(f);
    size_t w = (size_t)snprintf(body, 300, "{\"message\":\"Pack propio: %s\",\"branch\":\"main\",", name);
    if (sha[0]) w += (size_t)snprintf(body + w, 100, "\"sha\":\"%s\",", sha);
    w += (size_t)snprintf(body + w, 20, "\"content\":\"");
    b64_append(body, &w, raw, (size_t)sz);
    free(raw);
    w += (size_t)snprintf(body + w, 8, "\"}");
    char resp[400];
    int st = plat_https_put(url, tok, body, (long)w, resp, sizeof(resp), err, ecap);
    free(body);
    if (st == 200 || st == 201) return true;
    if (st > 0) {
        const char *m = strstr(resp, "\"message\"");
        char msg[120] = "";
        if (m && (m = strchr(m + 9, '"')) && (m = strchr(m + 1, '"'))) { m++; const char *e = strchr(m, '"'); snprintf(msg, sizeof(msg), "%.*s", e ? (int)(e - m) : 100, m); }
        if (st == 401 || st == 403) snprintf(err, ecap, "GitHub rechazo el token (%d): %s", st, msg);
        else snprintf(err, ecap, "GitHub respondio %d: %s", st, msg);
    }
    return false;
}

static void up_client(int fd) {
    struct timeval tv;
    tv.tv_sec = 20;
    tv.tv_usec = 0;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    char *buf = (char *)malloc(65536 + 1);
    if (!buf) { close(fd); return; }
    int have = 0, hdrEnd = -1;
    while (have < 8192 && hdrEnd < 0) {
        ssize_t r = recv(fd, buf + have, (size_t)(8192 - have), 0);
        if (r <= 0) break;
        have += (int)r;
        buf[have] = 0;
        const char *e = strstr(buf, "\r\n\r\n");
        if (e) hdrEnd = (int)(e - buf) + 4;
    }
    if (hdrEnd < 0) { free(buf); close(fd); return; }
    buf[hdrEnd - 2] = 0;  // cabeceras como texto
    if (!strncmp(buf, "GET ", 4)) {
        if (!strncmp(buf + 4, "/ ", 2) || !strncmp(buf + 4, "/index", 6)) up_reply(fd, 200, "text/html; charset=utf-8", UP_PAGE, sizeof(UP_PAGE) - 1);
        else if (!strncmp(buf + 4, "/info", 5)) { char t[200]; up_reply(fd, 200, "text/plain", up_token_read(t, sizeof(t)) ? "1" : "0", 1); }
        else up_reply(fd, 404, "text/plain", "no", 2);
    } else if (!strncmp(buf, "PUT /token", 10)) {  // guardar el token de GitHub (modo creador)
        long clen = -1;
        header_has(buf, "Content-Length:", &clen);
        char tk[220] = "";
        if (clen > 0 && clen < 200) {
            int got = have - hdrEnd > clen ? (int)clen : have - hdrEnd;
            if (got > 0) memcpy(tk, buf + hdrEnd, (size_t)got);
            while (got < clen) {
                ssize_t r = recv(fd, tk + got, (size_t)(clen - got), 0);
                if (r <= 0) break;
                got += (int)r;
            }
            tk[got < 210 ? got : 210] = 0;
        }
        char p[300];
        up_token_path(p, sizeof(p));
        FILE *f = fopen(p, "w");
        size_t keep = 0;
        char clean[220];
        for (char *c = tk; *c; c++)
            if ((*c >= 'a' && *c <= 'z') || (*c >= 'A' && *c <= 'Z') || (*c >= '0' && *c <= '9') || *c == '_' || *c == '-') clean[keep++] = *c;
        clean[keep] = 0;
        if (f && keep >= 20) { fprintf(f, "%s\n", clean); fclose(f); up_reply(fd, 200, "text/plain", "ok", 2); up_msg("%s", "Modo creador: token guardado"); }
        else { if (f) { fclose(f); remove(p); } up_reply(fd, 400, "text/plain", "token no valido", 15); }
    } else if (!strncmp(buf, "PUT /up?name=", 13)) {
        char raw[300], name[120];
        const char *q = buf + 13;
        size_t o = 0;
        const char *pubFlag = NULL;
        { const char *sp = strchr(buf + 13, ' '); const char *pf = strstr(buf + 13, "&pub=1"); if (pf && (!sp || pf < sp)) pubFlag = pf; }
        for (; *q && *q != ' ' && *q != '&' && o + 1 < sizeof(raw); q++) {
            if (*q == '%' && up_hex(q[1]) >= 0 && up_hex(q[2]) >= 0) { raw[o++] = (char)(up_hex(q[1]) * 16 + up_hex(q[2])); q += 2; }
            else raw[o++] = *q == '+' ? ' ' : *q;
        }
        raw[o] = 0;
        safe_filename(raw, name, sizeof(name));
        long clen = -1;
        header_has(buf, "Content-Length:", &clen);
        if (!up_ext_ok(name)) {
            up_reply(fd, 400, "text/plain", "Solo .mcpack o .mcaddon / only .mcpack or .mcaddon", 51);
            up_msg("Rechazado (solo .mcpack/.mcaddon): %.100s", name);
        } else if (clen <= 0 || clen > UP_MAX_BYTES) {
            up_reply(fd, 400, "text/plain", "Tamano no valido / bad size", 27);
        } else {
            char dir[300], part[460], fin[460];
            snprintf(dir, sizeof(dir), "%s/downloads", plat_data_dir());
            mkdir_p(dir);
            snprintf(part, sizeof(part), "%s/%s.part", dir, name);
            snprintf(fin, sizeof(fin), "%s/%s", dir, name);
            FILE *fp = fopen(part, "wb");
            bool ok = fp != NULL;
            long got = 0;
            g_upCur = 0;
            g_upTot = clen;
            { std::lock_guard<std::mutex> lk(g_upMx); snprintf(g_upLast, sizeof(g_upLast), "%s", name); }
            if (ok && have > hdrEnd) {
                long first = have - hdrEnd;
                if (first > clen) first = clen;
                ok = fwrite(buf + hdrEnd, 1, (size_t)first, fp) == (size_t)first;
                got = first;
            }
            while (ok && got < clen) {
                long want = clen - got < 65536 ? clen - got : 65536;
                ssize_t r = recv(fd, buf, (size_t)want, 0);
                if (r <= 0) { ok = false; break; }
                if (fwrite(buf, 1, (size_t)r, fp) != (size_t)r) { ok = false; break; }
                got += r;
                g_upCur = got;
            }
            if (fp) fclose(fp);
            if (ok) {
                remove(fin);
                ok = rename(part, fin) == 0;
            }
            if (ok && pubFlag) {
                char perr[160] = "";
                up_msg("Publicando para todos: %s", name);
                if (up_publish(fin, name, perr, sizeof(perr))) {
                    up_reply(fd, 200, "text/plain", "ok publicado", 12);
                    up_msg("Publicado para todos: %s", name);
                } else {
                    char m[260];
                    int ml = snprintf(m, sizeof(m), "Guardado en la PS4 pero NO publicado: %s", perr);
                    up_reply(fd, 502, "text/plain", m, (size_t)ml);
                    { std::lock_guard<std::mutex> lk(g_upMx); snprintf(g_upMsg, sizeof(g_upMsg), "No se publico: %.120s", perr); }
                }
                g_upCount++;
            } else if (ok) {
                up_reply(fd, 200, "text/plain", "ok", 2);
                up_msg("Recibido: %.100s", name);
                g_upCount++;
            } else {
                remove(part);
                up_reply(fd, 500, "text/plain", "No se pudo guardar / could not save", 35);
                up_msg("Fallo al recibir: %.100s", name);
            }
        }
    } else {
        up_reply(fd, 404, "text/plain", "no", 2);
    }
    free(buf);
    close(fd);
}

static void up_server() {
    g_upAlive = 1;
    int lfd = socket(AF_INET, SOCK_STREAM, 0);
    int port = 0;
    if (lfd >= 0 && bind && listen && accept) {
        int one = 1;
        setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
        for (int p = UP_PORT_FIRST; p < UP_PORT_FIRST + 10 && !port; p++) {
            struct sockaddr_in a;
            memset(&a, 0, sizeof(a));
            a.sin_family = AF_INET;
            a.sin_port = htons((unsigned short)p);
            if (bind(lfd, (struct sockaddr *)&a, sizeof(a)) == 0 && listen(lfd, 4) == 0) port = p;
        }
    }
    if (!port) {
        up_msg("%s", "No se pudo abrir el servidor (red no disponible?)");
        if (lfd >= 0) close(lfd);
        g_upPort = 0;
        g_upRun = 0;
        g_upAlive = 0;
        return;
    }
    struct timeval tv;
    tv.tv_sec = 1;
    tv.tv_usec = 0;
    setsockopt(lfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    g_upPort = port;
    while (g_upRun.load()) {
        int c = accept(lfd, NULL, NULL);
        if (c < 0) continue;
        try { std::thread(up_client, c).detach(); } catch (...) { close(c); }
    }
    close(lfd);
    g_upPort = 0;
    g_upAlive = 0;
}

static void up_start() {
    g_upRun = 1;
    up_find_ip();
    { std::lock_guard<std::mutex> lk(g_upMx); g_upMsg[0] = 0; }
    if (g_upAlive.load()) return;  // el hilo anterior aun no termino: sigue sirviendo
    g_upAlive = 1;
    try { std::thread(up_server).detach(); } catch (...) { g_upAlive = 0; g_upRun = 0; up_msg("%s", "No se pudo iniciar el servidor"); }
}

static void up_stop() { g_upRun = 0; }

static void draw_upload() {
    draw_header("McStore - Subir desde el telefono");
    static int lastCount = 0;
    int cnt = g_upCount.load();
    if (cnt != lastCount) { if (cnt > lastCount) sfx(SFX_DONE); lastCount = cnt; }
    int port = g_upPort.load();
    fill(140, 120, SCREEN_W - 280, 190, C_PANEL);
    fill(140, 120, 12, 190, C_ACCENT);
    text(180, 140, "Abre esta direccion en el navegador del telefono:", 2, C_DIM);
    char url[80];
    if (port) snprintf(url, sizeof(url), "http://%s:%d", g_upIp, port);
    else snprintf(url, sizeof(url), "Abriendo...");
    text((SCREEN_W - text_w(url, 5)) / 2, 190, url, 5, C_TEXT);
    text(180, 270, "El telefono y la PS4 deben estar en la misma red wifi.", 2, C_DIM);
    int y = 340;
    text(140, y, "1) Abre la direccion de arriba en Safari.", 3, C_TEXT);
    text(140, y + 52, "2) Toca \"Elegir archivos\" y escoge tus .mcpack o .mcaddon.", 3, C_TEXT);
    text(140, y + 104, "3) Toca \"Subir\". Aqui abajo veras cuando lleguen.", 3, C_TEXT);
    text(140, y + 156, "4) Pulsa R2 para instalarlos en Minecraft.", 3, C_TEXT);
    char tk[200];
    bool owner = up_token_read(tk, sizeof(tk));
    text(140, y + 214, owner ? "Modo creador ACTIVO: en la pagina marca \"Publicar para todos\" para que salgan en el catalogo." : "Modo creador: en la pagina web abre \"Modo creador\" y pega tu token para publicar para todos.", 2, owner ? C_OK : C_DIM, 110);
    int by = 600;
    fill(140, by, SCREEN_W - 280, 150, mix(C_PANEL, C_TEXT, 6));
    char s[200];
    snprintf(s, sizeof(s), "Archivos recibidos: %d", cnt);
    text(170, by + 18, s, 3, C_OK);
    char last[100], msg[160];
    { std::lock_guard<std::mutex> lk(g_upMx); snprintf(last, sizeof(last), "%s", g_upLast); snprintf(msg, sizeof(msg), "%s", g_upMsg); }
    if (msg[0]) text(170, by + 62, msg, 2, C_TEXT, 100);
    long tot = g_upTot.load(), cur = g_upCur.load();
    if (last[0] && tot > 0 && cur < tot) {
        fill(170, by + 108, SCREEN_W - 340, 20, C_BAR);
        fill(170, by + 108, (int)((long long)(SCREEN_W - 340) * cur / tot), 20, C_ACCENT);
    }
    draw_footer("R2: instalar en Minecraft | Circulo: volver");
}
