// Capa de plataforma: lo único que cambia entre la PS4 y las pruebas en PC.
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

#define SCREEN_W 1920
#define SCREEN_H 1080

enum {
    BTN_UP = 1 << 0,
    BTN_DOWN = 1 << 1,
    BTN_LEFT = 1 << 2,
    BTN_RIGHT = 1 << 3,
    BTN_CROSS = 1 << 4,
    BTN_CIRCLE = 1 << 5,
    BTN_SQUARE = 1 << 6,
    BTN_TRIANGLE = 1 << 7,
    BTN_L1 = 1 << 8,
    BTN_R1 = 1 << 9,
    BTN_OPTIONS = 1 << 10,
    BTN_R2 = 1 << 11,
};

bool plat_init();
uint32_t plat_buttons();          // botones mantenidos ahora mismo
uint32_t *plat_framebuffer();     // buffer de dibujo actual, SCREEN_W*SCREEN_H, 0x80RRGGBB
void plat_present();              // muestra el buffer y espera al vsync
void plat_sleep_ms(int ms);
uint64_t plat_ms();               // reloj monotónico en milisegundos
const char *plat_data_dir();      // carpeta de datos de la app (config y descargas)
const char *plat_apptmp_dir();    // carpeta donde Minecraft monta sus datos mientras esta abierto (/app_tmp)

// Existe la ruta? Si existe, dice si es carpeta y su tamano en bytes.
bool plat_stat(const char *path, bool *isDir, long *size);

// Lista los nombres de una carpeta (sin "." ni ".."). Devuelve false si no se pudo abrir.
typedef void (*PlatDirCb)(const char *name, void *ctx);
bool plat_listdir(const char *path, PlatDirCb cb, void *ctx);

// HTTPS (en la PS4 usa libSceHttp). Mismo contrato que http_get de net.h:
// modo memoria (out_buf) o modo archivo (fp). Devuelve el codigo HTTP o -1 con texto en err.
typedef bool (*PlatProgressCb)(long done, long total, void *ctx);
int plat_https_get(const char *url, char **out_buf, long *out_len, long max_len,
                   FILE *fp, PlatProgressCb cb, void *ctx, char *err, size_t errcap);
