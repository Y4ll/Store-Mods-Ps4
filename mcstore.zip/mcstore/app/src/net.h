// Cliente HTTP mínimo (HTTP/1.0, solo GET) + lector JSON para la respuesta del servidor.
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "platform.h"

struct Server {
    int ip[4];
    int port;
};

// Devuelve false para cancelar la descarga.
typedef bool (*ProgressCb)(long done, long total, void *ctx);

// Codifica para URL. Con keepPath se conservan "/" y "%" (rutas ya codificadas).
static void urlenc(const char *in, char *out, size_t cap, bool keepPath = false) {
    static const char *hex = "0123456789ABCDEF";
    size_t o = 0;
    for (; *in && o + 4 < cap; in++) {
        unsigned char c = (unsigned char)*in;
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
            c == '-' || c == '_' || c == '.' || c == '~' || (keepPath && (c == '/' || c == '%'))) {
            out[o++] = (char)c;
        } else {
            out[o++] = '%';
            out[o++] = hex[c >> 4];
            out[o++] = hex[c & 15];
        }
    }
    out[o] = 0;
}

static int send_all(int fd, const char *p, size_t n) {
    while (n) {
        ssize_t k = send(fd, p, n, 0);
        if (k <= 0) return -1;
        p += k;
        n -= (size_t)k;
    }
    return 0;
}

static bool header_has(const char *h, const char *name, long *val) {
    size_t nl = strlen(name);
    for (const char *p = h; *p; p++) {
        if ((p == h || p[-1] == '\n') && strncasecmp(p, name, nl) == 0) {
            *val = atol(p + nl);
            return true;
        }
    }
    return false;
}

// GET http://ip:puerto/path
// - Modo memoria: out_buf != NULL -> cuerpo en un buffer malloc (terminado en 0), hasta max_len.
// - Modo archivo: fp != NULL -> el cuerpo se escribe en fp.
// Devuelve el código HTTP (200 = ok) o -1 si falla (con texto en err).
static int http_get(const Server &s, const char *path, char **out_buf, long *out_len, long max_len,
                    FILE *fp, ProgressCb cb, void *ctx, char *err, size_t errcap) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) { snprintf(err, errcap, "no se pudo crear el socket (errno %d)", errno); return -1; }

    struct timeval tv;
    tv.tv_sec = 15;
    tv.tv_usec = 0;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    struct sockaddr_in a;
    memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_port = htons((unsigned short)s.port);
    unsigned char *ipb = (unsigned char *)&a.sin_addr;
    for (int i = 0; i < 4; i++) ipb[i] = (unsigned char)s.ip[i];

    if (connect(fd, (struct sockaddr *)&a, sizeof(a)) != 0) {
        snprintf(err, errcap, "no se pudo conectar a %d.%d.%d.%d:%d (errno %d)",
                 s.ip[0], s.ip[1], s.ip[2], s.ip[3], s.port, errno);
        close(fd);
        return -1;
    }

    char req[1024];
    int rl = snprintf(req, sizeof(req),
                      "GET %s HTTP/1.0\r\nHost: %d.%d.%d.%d:%d\r\nConnection: close\r\n\r\n",
                      path, s.ip[0], s.ip[1], s.ip[2], s.ip[3], s.port);
    if (send_all(fd, req, (size_t)rl) != 0) {
        snprintf(err, errcap, "fallo al enviar la peticion");
        close(fd);
        return -1;
    }

    // Cabeceras
    char hdr[4096];
    size_t hl = 0;
    char *body_start = NULL;
    while (!body_start) {
        if (hl >= sizeof(hdr) - 1) { snprintf(err, errcap, "cabeceras demasiado largas"); close(fd); return -1; }
        ssize_t k = recv(fd, hdr + hl, sizeof(hdr) - 1 - hl, 0);
        if (k <= 0) { snprintf(err, errcap, "el servidor cerro la conexion (errno %d)", errno); close(fd); return -1; }
        hl += (size_t)k;
        hdr[hl] = 0;
        char *e = strstr(hdr, "\r\n\r\n");
        if (e) { *e = 0; body_start = e + 4; }
    }
    size_t first_len = hl - (size_t)(body_start - hdr);

    int status = 0;
    if (sscanf(hdr, "HTTP/%*d.%*d %d", &status) != 1) {
        snprintf(err, errcap, "respuesta HTTP invalida");
        close(fd);
        return -1;
    }
    if (status != 200) {
        snprintf(err, errcap, "el servidor respondio HTTP %d", status);
        close(fd);
        return status;
    }

    long total = -1;
    header_has(hdr, "content-length:", &total);

    char *buf = NULL;
    long got = 0;
    if (out_buf) {
        buf = (char *)malloc((size_t)max_len + 1);
        if (!buf) { snprintf(err, errcap, "sin memoria"); close(fd); return -1; }
    }

    char *chunk = (char *)malloc(65536);
    if (!chunk) { snprintf(err, errcap, "sin memoria"); free(buf); close(fd); return -1; }
    const char *src = body_start;
    size_t n = first_len;
    bool ok = true;
    long last_cb = 0;
    for (;;) {
        if (n) {
            if (buf) {
                long room = max_len - got;
                long take = (long)n < room ? (long)n : room;
                memcpy(buf + got, src, (size_t)take);
                got += take;
                if (take < (long)n) { snprintf(err, errcap, "respuesta demasiado grande"); ok = false; break; }
            } else {
                if (fwrite(src, 1, n, fp) != n) { snprintf(err, errcap, "error al escribir el archivo (disco lleno?)"); ok = false; break; }
                got += (long)n;
            }
            if (cb && (got - last_cb >= 32768 || (total >= 0 && got >= total))) {
                last_cb = got;
                if (!cb(got, total, ctx)) { snprintf(err, errcap, "descarga cancelada"); ok = false; break; }
            }
        }
        ssize_t k = recv(fd, chunk, 65536, 0);
        if (k == 0) break;
        if (k < 0) { snprintf(err, errcap, "conexion interrumpida (errno %d)", errno); ok = false; break; }
        src = chunk;
        n = (size_t)k;
    }
    free(chunk);
    close(fd);

    if (ok && total >= 0 && got < total) {
        snprintf(err, errcap, "descarga incompleta (%ld de %ld bytes)", got, total);
        ok = false;
    }
    if (!ok) { free(buf); return -1; }

    if (out_buf) { buf[got] = 0; *out_buf = buf; *out_len = got; }
    return 200;
}

// ---------------- JSON ----------------

struct Item {
    char id[24];
    char name[96];
    char summary[200];
    char file[96];
    char url[400];
    long size;
    char author[40];
    long dl;                // descargas totales (CurseForge)
    char upd[12];           // fecha de la ultima actualizacion
    char ver[12];           // version de Minecraft mas nueva del pack (catalogo: "ver")
    char vers[48];          // todas las versiones, separadas por coma ("vers")
    char cls[8];            // tipo: tex, add, map, skin... ("cls")
    char img[20];           // miniatura del catalogo: thumbs/<img>.t96 ("img")
    unsigned char have, fav;  // la app: ya descargado / favorito
    unsigned char th;       // 1 = el servidor tiene miniatura
    unsigned char flag;  // 0 = igual, 1 = nuevo, 2 = actualizado (lo calcula la app al recargar)
};

static const char *LATIN1_BASE =
    "AAAAAAACEEEEIIIIDNOOOOO*OUUUUYTs"   // U+00C0..U+00DF
    "aaaaaaaceeeeiiiidnooooo/ouuuuyty";  // U+00E0..U+00FF

static const char *jws(const char *p) {
    while (*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t' || *p == ',') p++;
    return p;
}

// p apunta a la comilla de apertura. Devuelve el puntero tras la comilla de cierre.
static const char *jstring(const char *p, char *out, size_t cap, bool nl = false) {
    size_t o = 0;
    p++;
    while (*p && *p != '"') {
        char c = *p++;
        if (c == '\\') {
            char e = *p++;
            if (e == 'u') {
                unsigned cp = 0;
                for (int i = 0; i < 4 && *p; i++, p++) {
                    char h = *p;
                    cp = cp * 16 + (unsigned)(h <= '9' ? h - '0' : (h | 32) - 'a' + 10);
                }
                if (cp < 128) c = (char)cp;
                else if (cp >= 0xC0 && cp <= 0xFF) c = LATIN1_BASE[cp - 0xC0];
                else c = '?';
            } else if (e == 'n' && nl) c = '\n';
            else if (e == 'n' || e == 't' || e == 'r') c = ' ';
            else c = e;
        }
        if (o + 1 < cap) out[o++] = c;
    }
    out[o] = 0;
    return *p == '"' ? p + 1 : p;
}

// Lee un arreglo JSON de objetos planos {id,name,summary,file,size}. Devuelve cuántos leyó.
static int parse_items(const char *json, Item *items, int max) {
    int n = 0;
    const char *p = strchr(json, '[');
    if (!p) return 0;
    p++;
    while (n < max) {
        p = jws(p);
        if (*p != '{') break;
        p++;
        Item it;
        memset(&it, 0, sizeof(it));
        while (*p && *p != '}') {
            p = jws(p);
            if (*p != '"') break;
            char key[24];
            p = jstring(p, key, sizeof(key));
            p = jws(p);
            if (*p == ':') p++;
            p = jws(p);
            char val[420];
            val[0] = 0;
            long num = 0;
            if (*p == '"') {
                p = jstring(p, val, sizeof(val));
            } else {
                num = atol(p);
                while (*p && *p != ',' && *p != '}') p++;
            }
            if (!strcmp(key, "id")) snprintf(it.id, sizeof(it.id), "%s", val);
            else if (!strcmp(key, "name")) snprintf(it.name, sizeof(it.name), "%s", val);
            else if (!strcmp(key, "summary")) snprintf(it.summary, sizeof(it.summary), "%s", val);
            else if (!strcmp(key, "file")) snprintf(it.file, sizeof(it.file), "%s", val);
            else if (!strcmp(key, "url")) snprintf(it.url, sizeof(it.url), "%s", val);
            else if (!strcmp(key, "size")) it.size = num;
            else if (!strcmp(key, "author")) snprintf(it.author, sizeof(it.author), "%s", val);
            else if (!strcmp(key, "upd")) snprintf(it.upd, sizeof(it.upd), "%s", val);
            else if (!strcmp(key, "dl")) it.dl = num;
            else if (!strcmp(key, "th")) it.th = num ? 1 : 0;
            else if (!strcmp(key, "ver")) snprintf(it.ver, sizeof(it.ver), "%s", val);
            else if (!strcmp(key, "vers")) snprintf(it.vers, sizeof(it.vers), "%s", val);
            else if (!strcmp(key, "cls")) snprintf(it.cls, sizeof(it.cls), "%s", val);
            else if (!strcmp(key, "img")) snprintf(it.img, sizeof(it.img), "%s", val);
            p = jws(p);
        }
        if (*p == '}') p++;
        if (it.id[0] || it.url[0] || it.name[0]) {
            if (!it.id[0]) snprintf(it.id, sizeof(it.id), "%d", n);
            items[n++] = it;
        }
    }
    return n;
}

// Deja solo caracteres seguros para un nombre de archivo.
static void safe_filename(const char *in, char *out, size_t cap) {
    const char *base = strrchr(in, '/');
    base = base ? base + 1 : in;
    size_t o = 0;
    for (; *base && o + 1 < cap; base++) {
        char c = *base;
        bool ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
                  c == '.' || c == '-' || c == '_' || c == ' ';
        out[o++] = ok ? c : '_';
    }
    out[o] = 0;
    if (!o || out[0] == '.') snprintf(out, cap, "mod_%s", o ? out + 1 : "descarga");
}

// ---------------- URL genérica (http:// por IP, https:// por la plataforma) ----------------

struct Url {
    bool https;
    char host[160];
    int port;
    char path[600];
};

static bool url_parse(const char *s, Url *u) {
    memset(u, 0, sizeof(*u));
    if (!strncasecmp(s, "https://", 8)) { u->https = true; u->port = 443; s += 8; }
    else if (!strncasecmp(s, "http://", 7)) { u->https = false; u->port = 80; s += 7; }
    else return false;
    size_t h = 0;
    while (*s && *s != '/' && *s != ':' && h + 1 < sizeof(u->host)) u->host[h++] = *s++;
    u->host[h] = 0;
    if (*s == ':') { u->port = atoi(s + 1); while (*s && *s != '/') s++; }
    snprintf(u->path, sizeof(u->path), "%s", *s ? s : "/");
    return h > 0;
}

static int fetch(const char *url, char **out_buf, long *out_len, long max_len, FILE *fp,
                 ProgressCb cb, void *ctx, char *err, size_t errcap) {
    Url u;
    if (!url_parse(url, &u)) { snprintf(err, errcap, "URL invalida"); return -1; }
    if (u.https) return plat_https_get(url, out_buf, out_len, max_len, fp, cb, ctx, err, errcap);
    Server s;
    if (sscanf(u.host, "%d.%d.%d.%d", &s.ip[0], &s.ip[1], &s.ip[2], &s.ip[3]) != 4) {
        snprintf(err, errcap, "http:// solo admite una IP (usa https://)");
        return -1;
    }
    s.port = u.port;
    return http_get(s, u.path, out_buf, out_len, max_len, fp, cb, ctx, err, errcap);
}

// Directorio de una URL, con la "/" final: https://a/b/c.json -> https://a/b/
static void url_dir(const char *url, char *out, size_t cap) {
    snprintf(out, cap, "%s", url);
    char *q = strchr(out, '?');
    if (q) *q = 0;
    char *slash = strrchr(out, '/');
    if (slash && slash > out + 8) slash[1] = 0;
}

// Convierte la ruta de una entrada del catalogo en una URL completa.
static void resolve_url(const char *catalogUrl, const char *entry, char *out, size_t cap) {
    if (!strncasecmp(entry, "http://", 7) || !strncasecmp(entry, "https://", 8)) {
        urlenc(entry, out, cap, true);  // solo codifica espacios y rarezas
        // urlenc codifica ":" de "https://": lo restauramos
        char fixed[600];
        snprintf(fixed, sizeof(fixed), "%s", out);
        char *p = strstr(fixed, "%3A");
        if (p && p < fixed + 10) { memmove(p + 1, p + 3, strlen(p + 3) + 1); *p = ':'; }
        snprintf(out, cap, "%s", fixed);
        return;
    }
    char base[400], enc[500];
    url_dir(catalogUrl, base, sizeof(base));
    while (*entry == '/') entry++;
    urlenc(entry, enc, sizeof(enc), true);
    snprintf(out, cap, "%s%s", base, enc);
}

// Numero de un campo suelto del JSON, p. ej. json_int(j, "\"pages\":", 1). Devuelve def si no esta.
static int json_int(const char *json, const char *pat, int def) {
    const char *p = strstr(json, pat);
    return p ? atoi(p + strlen(pat)) : def;
}

// Texto de un campo suelto del JSON ("key":"valor"). Con nl se conservan los saltos de linea.
static bool json_str(const char *json, const char *key, char *out, size_t cap, bool nl = false) {
    char pat[40];
    snprintf(pat, sizeof(pat), "\"%s\":\"", key);
    const char *p = strstr(json, pat);
    if (!p) { out[0] = 0; return false; }
    jstring(p + strlen(pat) - 1, out, cap, nl);
    return true;
}
