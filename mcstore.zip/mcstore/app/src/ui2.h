// Pantalla de inicio (logo animado + version), ayuda con todos los botones y preferencias guardadas.
// Se incluye desde main.cpp justo antes de render().
#pragma once

// ---------- preferencias (/data/mcstore/prefs.txt, lineas clave=valor) ----------
struct Prefs {
    int helpSeen;  // 1 = ya se mostro la ayuda la primera vez
};
static Prefs g_pf = {0};
#include "audio.h"

static void prefs_path(char *out, size_t cap) { snprintf(out, cap, "%s/prefs.txt", plat_data_dir()); }

static void prefs_save() {
    char p[300];
    prefs_path(p, sizeof(p));
    FILE *f = fopen(p, "w");
    if (!f) return;
    fprintf(f, "help=%d\nanim=%d\nsfx=%d\nmusic=%d\n", g_pf.helpSeen, g_animBg ? 1 : 0, g_auSfxOn ? 1 : 0, g_auMusic ? 1 : 0);
    fclose(f);
}

static bool prefs_load() {
    char p[300], line[80];
    prefs_path(p, sizeof(p));
    FILE *f = fopen(p, "r");
    if (!f) return false;
    while (fgets(line, sizeof(line), f)) {
        int v;
        if (sscanf(line, "help=%d", &v) == 1) g_pf.helpSeen = v ? 1 : 0;
        else if (sscanf(line, "anim=%d", &v) == 1) g_animBg = v != 0;
        else if (sscanf(line, "sfx=%d", &v) == 1) g_auSfxOn = v != 0;
        else if (sscanf(line, "music=%d", &v) == 1) g_auMusic = v != 0;
    }
    fclose(f);
    return true;
}

// ---------- inicio ----------
static const int SIN64[64] = {0, 10, 20, 29, 38, 47, 56, 63, 71, 77, 83, 88, 92, 96, 98, 100, 100, 100, 98, 96, 92, 88, 83, 77, 71, 63, 56, 47, 38, 29, 20, 10,
                              0, -10, -20, -29, -38, -47, -56, -63, -71, -77, -83, -88, -92, -96, -98, -100, -100, -100, -98, -96, -92, -88, -83, -77, -71, -63, -56, -47, -38, -29, -20, -10};
static int isin(int phase) { return SIN64[((phase % 64) + 64) % 64]; }  // -100..100

static uint64_t g_splashStart = 0;
#define SPLASH_MS 3200

// Bloque de Minecraft en isometrico: tapa verde, caras de tierra con motas.
static void draw_cube(int cx, int cy, int s) {
    uint32_t top = C_ACCENT, topHi = C_ACC2;
    uint32_t dirtL = RGB(134, 96, 67), dirtR = RGB(104, 74, 52), speck = RGB(86, 62, 44);
    for (int dx = 0; dx < s; dx++) {  // cara izquierda y derecha
        int yl = cy + s / 2 + dx / 2, yr = cy + s - dx / 2;
        fill(cx - s + dx, yl, 1, s, dirtL);
        fill(cx + dx, yr, 1, s, dirtR);
        fill(cx - s + dx, yl, 1, s / 5 + 6 - dx / 12, mix(top, C_BG, 25));  // flecos de pasto
        fill(cx + dx, yr, 1, s / 5 + 6 - (s - dx) / 12 + 6 - 6, mix(top, C_BG, 45));
    }
    for (int k = 0; k < 9; k++) {
        int mx = (k * 37) % (s - 16), my = (k * 53) % (s / 2) + s / 3;
        fill(cx - s + 8 + mx, cy + s / 2 + (mx + 8) / 2 + my, 10, 8, speck);
        fill(cx + 6 + mx, cy + s - (mx + 6) / 2 + my, 10, 8, mix(speck, C_BG, 20));
    }
    for (int dx = -s; dx < s; dx++) {  // tapa
        int a = dx < 0 ? -dx : dx;
        fill(cx + dx, cy + a / 2, 1, s - a, top);
        if ((dx & 15) < 8) fill(cx + dx, cy + a / 2, 1, 3, topHi);
    }
}

static void draw_splash() {
    uint64_t t = plat_ms() - g_splashStart;
    int ph = (int)(t / 40);
    // destellos de fondo
    for (int i = 0; i < 26; i++) {
        unsigned h = (unsigned)i * 2654435761u;
        int x = (int)((h >> 3) % SCREEN_W), y = (int)((h >> 14) % SCREEN_H);
        int tw = (isin(ph + i * 7) + 100) / 50;  // 0..4
        uint32_t c = mix(C_BG2, C_ACC2, 18 + tw * 14);
        fill(x, y, 6 + tw, 6 + tw, c);
    }
    int cx = SCREEN_W / 2;
    int bob = isin(ph) * 14 / 100;
    draw_cube(cx, 140 + bob, 150);
    // titulo: cada letra sube y baja con retraso
    const char *title = "McStore";
    int sc = 10, tw = (int)strlen(title) * 8 * sc, x0 = cx - tw / 2;
    for (int i = 0; i < (int)strlen(title); i++) {
        char ch[2] = {title[i], 0};
        int dy = isin(ph * 2 - i * 6) * 12 / 100;
        uint32_t col = i % 2 ? C_TEXT : C_ACC2;
        int slide = t < 600 ? (int)((600 - t) * (i + 1)) / 8 : 0;  // entrada desde arriba
        text(x0 + i * 8 * sc + 6, 470 + dy + 8 - slide, ch, sc, mix(C_BG, C_ACCENT, 60));
        text(x0 + i * 8 * sc, 470 + dy - slide, ch, sc, col);
    }
    const char *sub = g_pf.helpSeen ? "Add-ons para Minecraft Bedrock" : "Add-ons para Minecraft Bedrock  -  bienvenido";
    text(cx - text_w(sub, 3) / 2, 680, sub, 3, C_DIM);
    char v[40];
    snprintf(v, sizeof(v), "version %s", APP_VERSION);
    int vw = text_w(v, 3) + 40;
    fill(cx - vw / 2 - 4, 744, vw + 8, 64, mix(C_BG, C_ACCENT, 60));
    fill(cx - vw / 2, 748, vw, 56, mix(C_PANEL, C_ACCENT, 35));
    text(cx - text_w(v, 3) / 2, 764, v, 3, C_TEXT);
    // barra de progreso
    int bw = 700, bx = cx - bw / 2, by = 880;
    fill(bx, by, bw, 14, C_PANEL);
    int w = (int)(t >= SPLASH_MS ? bw : (long long)bw * t / SPLASH_MS);
    fill(bx, by, w, 14, C_ACCENT);
    fill(bx, by, w, 4, C_ACC2);
    const char *hint = (isin(ph) > 0) ? "Pulsa cualquier boton" : "";
    text(cx - text_w("Pulsa cualquier boton", 2) / 2, 920, hint, 2, C_DIM);
    text(cx - text_w(A.status, 2) / 2 > 0 ? cx - text_w(A.status, 2) / 2 : 20, 980, A.status, 2, A.statusCol, 115);
}

static bool g_helpFirst = false;
static Screen g_helpBack = S_LIST;
static int g_helpTop = 0;

static void splash_done() {
    if (!g_pf.helpSeen) {  // primera vez: ensena los botones
        g_pf.helpSeen = 1;
        prefs_save();
        g_helpFirst = true;
        g_helpBack = S_LIST;
        g_helpTop = 0;
        A.scr = S_HELP;
    } else A.scr = S_LIST;
}

static void input_splash(uint32_t p) {
    if (p || plat_ms() - g_splashStart > SPLASH_MS + 400) splash_done();
}

// ---------- ayuda ----------
struct HelpLine { const char *key; const char *txt; };  // key == NULL: titulo de seccion
static const HelpLine HELP[] = {
    {NULL, "LISTA DE ADD-ONS"},
    {"Flechas", "Moverse por las tarjetas"},
    {"X", "Abrir el detalle (foto, descripcion y descargar)"},
    {"Cuadrado", "Buscar por nombre"},
    {"Circulo", "Filtros y tema (GitHub) / cambiar el orden (PC)"},
    {"Options", "Recargar el catalogo"},
    {"L1 / R1", "Saltar una pantalla de tarjetas (PC: cambiar de pagina)"},
    {"L2", "Bajar todo lo nuevo y actualizado"},
    {"R2", "Instalar en Minecraft"},
    {"L3", "Buscar una version nueva de McStore"},
    {"Triangulo", "Ajustes (de donde salen los add-ons)"},
    {NULL, "DETALLE DE UN ADD-ON"},
    {"X", "Descargar (o actualizar si hay version nueva)"},
    {"Arriba / Abajo", "Leer la descripcion"},
    {"R2", "Ir a instalar en Minecraft"},
    {"Circulo", "Volver a la lista (cancela la descarga si hay una)"},
    {NULL, "INSTALAR EN MINECRAFT (Minecraft abierto en segundo plano)"},
    {"X", "Instalar el pack elegido"},
    {"L2", "Instalar todos los packs"},
    {"Cuadrado", "Borrar el pack elegido de las descargas"},
    {"Triangulo", "Borrar todas las descargas (y, al terminar, volver a Minecraft)"},
    {"Options", "Actualizar la lista"},
    {"Circulo", "Volver"},
    {NULL, "BUSCAR (TECLADO)"},
    {"X", "Escribir la letra"},
    {"Cuadrado", "Borrar la ultima letra"},
    {"Triangulo", "Poner un espacio"},
    {"L1 / R1", "Cambiar de categoria (fuente PC)"},
    {"Options", "Buscar"},
    {"Circulo", "Cancelar"},
    {NULL, "FILTROS Y AJUSTES"},
    {"Arriba / Abajo", "Cambiar de fila"},
    {"Izq / Der", "Cambiar el valor (tipo, version, tema)"},
    {"X", "Aplicar o guardar"},
    {"Cuadrado", "En Ajustes: preferencias (quitar fondo animado, sonidos y musica)"},
    {"Triangulo", "En Filtros: quitar filtros. En Ajustes: abrir esta ayuda"},
    {"Circulo", "Volver"},
};
#define N_HELP ((int)(sizeof(HELP) / sizeof(HELP[0])))
#define HELP_ROWS 22

static void draw_help() {
    draw_header("McStore - Ayuda");
    int y0 = 128, lh = 36;
    fill(40, y0 - 10, SCREEN_W - 80, HELP_ROWS * lh + 14, mix(C_BG, C_PANEL, 70));
    for (int i = 0; i < HELP_ROWS && g_helpTop + i < N_HELP; i++) {
        const HelpLine &h = HELP[g_helpTop + i];
        int y = y0 + i * lh;
        if (!h.key) {
            fill(60, y, SCREEN_W - 120, lh - 4, mix(C_PANEL, C_ACCENT, 30));
            text(76, y + 6, h.txt, 2, C_TEXT);
        } else {
            fill(76, y + 1, 330, lh - 6, C_SEL);
            text(90, y + 6, h.key, 2, C_ACC2);
            text(440, y + 6, h.txt, 2, C_TEXT, 92);
        }
    }
    if (N_HELP > HELP_ROWS) {
        int h = HELP_ROWS * lh, bh = h * HELP_ROWS / N_HELP;
        int by = y0 + (h - bh) * g_helpTop / (N_HELP - HELP_ROWS);
        fill(SCREEN_W - 36, y0, 8, h, C_PANEL);
        fill(SCREEN_W - 36, by, 8, bh, C_ACCENT);
    }
    draw_footer(g_helpFirst ? "Esta ayuda sale solo la primera vez (en Ajustes, Triangulo, la vuelves a ver) | Arriba/Abajo: leer | X o Circulo: seguir"
                            : "Arriba/Abajo: leer | L1/R1: pagina | Circulo o X: volver");
}

static void input_help(uint32_t p) {
    int maxTop = N_HELP > HELP_ROWS ? N_HELP - HELP_ROWS : 0;
    if (p & BTN_DOWN) g_helpTop = g_helpTop + 1 > maxTop ? maxTop : g_helpTop + 1;
    if (p & BTN_UP) g_helpTop = g_helpTop - 1 < 0 ? 0 : g_helpTop - 1;
    if (p & BTN_R1) g_helpTop = g_helpTop + HELP_ROWS > maxTop ? maxTop : g_helpTop + HELP_ROWS;
    if (p & BTN_L1) g_helpTop = g_helpTop - HELP_ROWS < 0 ? 0 : g_helpTop - HELP_ROWS;
    if (p & (BTN_CIRCLE | BTN_CROSS)) {
        g_helpFirst = false;
        A.scr = g_helpBack;
    }
}

// ---------- preferencias ----------
static int g_prefRow = 0;
#define N_PREF 3

static void pref_value(int row, char *out, size_t cap) {
    bool b = row == 0 ? g_animBg : row == 1 ? (bool)g_auSfxOn : (bool)g_auMusic;
    snprintf(out, cap, "%s", b ? "Si" : "No");
}

static void draw_prefs() {
    draw_header("McStore - Preferencias");
    static const char *lbl[N_PREF] = {"Fondo animado (llamas, vaporwave, bloques)", "Sonidos (cursor, descarga terminada, error)", "Musica de fondo"};
    static const char *hint[N_PREF] = {"Quita la animacion si prefieres un fondo quieto (gasta menos). Solo afecta a los temas Llamas, Vaporwave y Bloques.",
                                       "Un tic al mover el cursor y un sonido al terminar una descarga o al fallar.",
                                       "Musica en bucle mientras usas la tienda. Quitala si prefieres silencio."};
    for (int i = 0; i < N_PREF; i++) {
        int y = 150 + i * 190;
        bool sel = g_prefRow == i;
        if (sel) fill_vgrad(200, y, 1520, 150, C_ACCENT, mix(C_ACCENT, C_BG, 30));
        else fill_vgrad(200, y, 1520, 150, mix(C_PANEL, C_TEXT, 7), C_PANEL);
        fill(200, y, 12, 150, sel ? C_TEXT : C_ACC2);
        char v[40];
        pref_value(i, v, sizeof(v));
        text(240, y + 18, lbl[i], 2, sel ? C_BG : C_DIM);
        text(240, y + 56, v, 4, sel ? C_BG : C_TEXT);
        text(240, y + 116, hint[i], 2, sel ? C_BG : C_DIM, 92);
        if (sel) text(1500, y + 56, "<   >", 4, C_BG);
    }
    draw_footer("Arriba/Abajo: fila | Izq/Der o X: cambiar | Circulo: volver (se guarda)");
}

static void input_prefs(uint32_t p) {
    if (p & BTN_DOWN) g_prefRow = g_prefRow + 1 >= N_PREF ? N_PREF - 1 : g_prefRow + 1;
    if (p & BTN_UP) g_prefRow = g_prefRow - 1 < 0 ? 0 : g_prefRow - 1;
    if (p & (BTN_LEFT | BTN_RIGHT | BTN_CROSS)) {
        if (g_prefRow == 0) g_animBg = !g_animBg;
        else if (g_prefRow == 1) { g_auSfxOn = !g_auSfxOn; sfx(SFX_SELECT); }
        else g_auMusic = !g_auMusic;
    }
    if (p & BTN_CIRCLE) {
        prefs_save();
        A.scr = S_SETTINGS;
    }
}
