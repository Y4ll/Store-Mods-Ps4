// Menu principal (cuadricula de botones grandes) y pantalla de Apariencia (temas + fondo). Se incluye desde main.cpp.
#pragma once

enum { T_STORE, T_SEARCH, T_CAT, T_NEWS, T_INST, T_LOOK, T_SET, T_UPD, N_TILES };
static int g_menuSel = 0;
static int g_thSel = 0;           // fila elegida en Apariencia: 0 tema, 1 fondo, 2 oscurecer
static bool g_bgPendingSel = false;
static uint64_t g_bgSelAt = 0;

// ---------- dibujo de iconos (solo rectangulos y circulos) ----------

static int isqrt(int v) {
    int r = 0;
    while ((r + 1) * (r + 1) <= v) r++;
    return r;
}
static void disc(int cx, int cy, int r, uint32_t col) {
    for (int dy = -r; dy <= r; dy++) {
        int w = isqrt(r * r - dy * dy);
        fill(cx - w, cy + dy, 2 * w + 1, 1, col);
    }
}
static void ring(int cx, int cy, int r, int t, uint32_t col) {
    for (int dy = -r; dy <= r; dy++) {
        int wo = isqrt(r * r - dy * dy);
        int ri = r - t;
        if (abs(dy) >= ri) { fill(cx - wo, cy + dy, 2 * wo + 1, 1, col); continue; }
        int wi = isqrt(ri * ri - dy * dy);
        fill(cx - wo, cy + dy, wo - wi, 1, col);
        fill(cx + wi + 1, cy + dy, wo - wi, 1, col);
    }
}
static void tri_down(int cx, int y, int h, uint32_t col) { for (int r = 0; r < h; r++) fill(cx - (h - r), y + r, 2 * (h - r) + 1, 1, col); }
static void tri_up(int cx, int y, int h, uint32_t col) { for (int r = 0; r < h; r++) fill(cx - r, y + r, 2 * r + 1, 1, col); }

static void draw_icon(int t, int x, int y, uint32_t col, uint32_t hole) {
    switch (t) {
    case T_STORE:
        fill(x + 10, y + 40, 90, 65, col);
        fill(x + 32, y + 14, 6, 30, col);
        fill(x + 72, y + 14, 6, 30, col);
        fill(x + 32, y + 14, 46, 6, col);
        fill(x + 38, y + 62, 34, 8, hole);
        break;
    case T_SEARCH:
        ring(x + 45, y + 45, 38, 11, col);
        for (int k = 0; k < 34; k++) fill(x + 72 + k, y + 72 + k, 12, 12, col);
        break;
    case T_CAT:
        for (int i = 0; i < 3; i++) {
            fill(x + 8, y + 14 + i * 34, 16, 16, col);
            fill(x + 36, y + 16 + i * 34, 68, 12, col);
        }
        break;
    case T_NEWS:
        fill(x + 43, y + 4, 24, 48, col);
        tri_down(x + 55, y + 52, 32, col);
        fill(x + 8, y + 98, 94, 10, col);
        break;
    case T_INST:
        fill(x + 47, y + 2, 16, 40, col);
        tri_down(x + 55, y + 42, 26, col);
        fill(x + 8, y + 70, 10, 38, col);
        fill(x + 92, y + 70, 10, 38, col);
        fill(x + 8, y + 98, 94, 10, col);
        break;
    case T_LOOK:
        disc(x + 55, y + 55, 52, col);
        disc(x + 34, y + 40, 9, hole);
        disc(x + 62, y + 28, 9, hole);
        disc(x + 84, y + 50, 9, hole);
        disc(x + 72, y + 82, 13, hole);
        break;
    case T_SET:
        ring(x + 55, y + 55, 34, 16, col);
        static const int TX[8] = {43, 30, 0, -30, -43, -30, 0, 30}, TY[8] = {0, 30, 43, 30, 0, -30, -43, -30};
        for (int k = 0; k < 8; k++) fill(x + 55 + TX[k] - 9, y + 55 + TY[k] - 9, 18, 18, col);
        break;
    case T_UPD:
        tri_up(x + 55, y + 2, 34, col);
        fill(x + 43, y + 36, 24, 52, col);
        fill(x + 8, y + 98, 94, 10, col);
        break;
    }
}

// ---------- menu principal ----------

static int count_flags() {
    int c = 0;
    if (A.catLoaded && A.cat)
        for (int i = 0; i < A.catN; i++) if (A.cat[i].flag) c++;
    return c;
}

static const char *TILE_TITLE[N_TILES] = {"TIENDA", "BUSCAR", "MI CATALOGO", "NOVEDADES", "INSTALAR", "APARIENCIA", "AJUSTES", "ACTUALIZAR"};
static const char *TILE_HELP[N_TILES] = {
    "Miles de add-ons, texturas, mundos y skins de CurseForge, con foto y descripcion.",
    "Busca por nombre en toda la tienda (la primera vez baja el indice, una sola vez).",
    "Tu propio catalog.json de GitHub (los add-ons que tu agregues).",
    "Baja de una vez todo lo [NUEVO] y [ACTUALIZADO] de tu catalogo.",
    "Mete los packs descargados en Minecraft (Minecraft tiene que estar abierto en segundo plano).",
    "Cambia el tema (blanco, negro, azul...) y pon tu propia imagen de fondo.",
    "Fuente de los add-ons: GitHub (sin PC) o un PC de tu red.",
    "Busca una version nueva de McStore y baja el PKG.",
};

static void tile_text(int t, char l1[40], char l2[40], uint32_t *col) {
    l1[0] = l2[0] = 0;
    *col = C_DIM;
    switch (t) {
    case T_STORE:
        if (V.on) { fmt_count(ST.total, l1, 24); snprintf(l1 + strlen(l1), 16, " add-ons"); snprintf(l2, 40, "de CurseForge"); *col = C_OK; }
        else if (V.booting) snprintf(l1, 40, "Conectando...");
        else if (V.failed) { snprintf(l1, 40, "No disponible"); snprintf(l2, 40, "X: reintentar"); *col = C_ERR; }
        else { snprintf(l1, 40, "No configurada"); snprintf(l2, 40, "usa Mi catalogo"); }
        break;
    case T_SEARCH: snprintf(l1, 40, "Por nombre"); snprintf(l2, 40, "en toda la tienda"); break;
    case T_CAT:
        snprintf(l1, 40, A.mode == M_GITHUB ? "catalog.json" : "Servidor de tu PC");
        if (A.catLoaded) snprintf(l2, 40, "%d add-ons", A.catN);
        else snprintf(l2, 40, "%s", A.mode == M_GITHUB ? "de tu GitHub" : "en tu red");
        break;
    case T_NEWS: {
        int c = count_flags();
        if (c) { snprintf(l1, 40, "%d por bajar", c); snprintf(l2, 40, "X: bajar todo"); *col = C_OK; }
        else { snprintf(l1, 40, A.catLoaded ? "Sin novedades" : "Pulsa para ver"); }
        break;
    }
    case T_INST:
        if (plat_game_in_background()) { snprintf(l1, 40, "Minecraft abierto"); snprintf(l2, 40, "listo para instalar"); *col = C_OK; }
        else { snprintf(l1, 40, "Abre Minecraft"); snprintf(l2, 40, "y vuelve aqui"); }
        break;
    case T_LOOK:
        snprintf(l1, 40, "Tema: %s", THEMES[g_theme].name);
        snprintf(l2, 40, "Fondo: %.15s", g_bgName[0] ? g_bgName : "ninguno");
        break;
    case T_SET:
        snprintf(l1, 40, "Fuente: %s", A.mode == M_GITHUB ? "GitHub" : "PC en red");
        break;
    case T_UPD:
        if (g_upd.avail) { snprintf(l1, 40, "Hay v%s nueva", g_upd.ver); snprintf(l2, 40, "X: bajar el PKG"); *col = C_OK; }
        else { snprintf(l1, 40, "Version %s", APP_VERSION); snprintf(l2, 40, "X: buscar nueva"); }
        break;
    }
}

static void draw_menu() {
    draw_header("McStore");
    const int TW = 420, TH = 330, GAP = 30, X0 = 75, Y0 = 130;
    for (int t = 0; t < N_TILES; t++) {
        int x = X0 + (t % 4) * (TW + GAP), y = Y0 + (t / 4) * (TH + GAP);
        bool sel = t == g_menuSel;
        if (sel) {
            fill(x - 6, y - 6, TW + 12, TH + 12, C_ACCENT);
            fill(x, y, TW, TH, C_BG);
        }
        panel(x, y, TW, TH, sel ? C_SEL : C_PANEL);
        draw_icon(t, x + 36, y + 34, sel ? C_TEXT : C_ACCENT, sel ? C_SEL : C_PANEL);
        text(x + 36, y + 176, TILE_TITLE[t], 3, sel ? C_TEXT : C_TEXT);
        char l1[40], l2[40];
        uint32_t col;
        tile_text(t, l1, l2, &col);
        text(x + 36, y + 238, l1, 2, col, 23);
        text(x + 36, y + 270, l2, 2, sel ? C_TEXT : C_DIM, 23);
        if (t == T_NEWS && count_flags()) {
            char b[16];
            snprintf(b, sizeof(b), "%d", count_flags());
            int bw = (int)strlen(b) * 24 + 28;
            fill(x + TW - bw - 20, y + 20, bw, 46, C_OK);
            text(x + TW - bw - 6, y + 28, b, 3, C_BG);
        }
        if (t == T_UPD && g_upd.avail) fill(x + TW - 56, y + 24, 30, 30, C_OK);
    }
    panel(X0, 850, 4 * TW + 3 * GAP, 70, C_PANEL);
    text(X0 + 24, 872, TILE_HELP[g_menuSel], 2, C_TEXT, 100);
    draw_busy_overlay();
    draw_footer("Flechas: moverse | X: abrir | Cuadrado: buscar | Triangulo: apariencia | L1/R1: tema | Options: ajustes");
}

// ---------- apariencia ----------

static void draw_theme_row(int row, int y, const char *label, const char *value, int cur, int total) {
    bool sel = g_thSel == row;
    if (sel) fill(150, y - 6, 1620, 106, C_ACCENT);
    panel(156, y, 1608, 94, sel ? C_SEL : C_PANEL);
    text(190, y + 14, label, 2, sel ? C_TEXT : C_DIM);
    text(190, y + 48, value, 3, C_TEXT, 52);
    char s[32];
    if (total > 0) snprintf(s, sizeof(s), "%d / %d", cur, total); else s[0] = 0;
    text(1700 - text_w(s, 2), y + 14, s, 2, C_DIM);
    text(1560, y + 40, "<", 4, sel ? C_ACCENT : C_DIM);
    text(1700, y + 40, ">", 4, sel ? C_ACCENT : C_DIM);
}

static void draw_theme() {
    draw_header("Apariencia");
    draw_theme_row(0, 130, "TEMA", THEMES[g_theme].name, g_theme + 1, N_THEMES);
    // muestras de todos los temas
    int sx = 156, sw = 192, gap = 12;
    for (int i = 0; i < N_THEMES; i++) {
        const Theme &t = THEMES[i];
        int x = sx + i * (sw + gap);
        if (i == g_theme) fill(x - 5, 246, sw + 10, 80, C_ACCENT);
        fill(x, 250, sw, 72, RGB(t.bg[0], t.bg[1], t.bg[2]));
        fill(x, 250, sw, 22, RGB(t.panel[0], t.panel[1], t.panel[2]));
        fill(x + 10, 296, 70, 14, RGB(t.accent[0], t.accent[1], t.accent[2]));
        fill(x + 90, 296, 90, 14, RGB(t.sel[0], t.sel[1], t.sel[2]));
        text(x + 8, 254, t.name, 1, RGB(t.text[0], t.text[1], t.text[2]));
    }

    char val[110];
    if (g_bgIdx < 0) snprintf(val, sizeof(val), "Ninguno (color liso)");
    else snprintf(val, sizeof(val), "%s", g_bgList.name[g_bgIdx]);
    draw_theme_row(1, 360, "FONDO (IMAGEN PROPIA)", val, g_bgIdx + 1, g_bgList.n);
    if (g_bgState.load() == 1) text(190, 462, "Cargando imagen...", 2, C_ACCENT);
    else if (g_bgState.load() == 3) text(190, 462, g_bgErr, 2, C_ERR, 100);
    else if (g_bgPendingSel) text(190, 462, "...", 2, C_DIM);

    {
        // barra de oscurecer
        const char *lab = g_light ? "ACLARAR FONDO (para que se lea el texto)" : "OSCURECER FONDO (para que se lea el texto)";
        bool sel = g_thSel == 2;
        int y = 500;
        if (sel) fill(150, y - 6, 1620, 106, C_ACCENT);
        panel(156, y, 1608, 94, sel ? C_SEL : C_PANEL);
        text(190, y + 14, lab, 2, sel ? C_TEXT : C_DIM);
        for (int i = 0; i < 10; i++) {
            fill(190 + i * 100, y + 50, 88, 26, i < g_dim ? C_ACCENT : C_BG);
            if (i >= g_dim) fill(190 + i * 100, y + 50, 88, 26, C_BG);
        }
        char s[16];
        snprintf(s, sizeof(s), "%d%%", g_dim * 10);
        text(1700 - text_w(s, 3), y + 44, s, 3, C_TEXT);
        text(1560, y + 14, "<", 2, sel ? C_ACCENT : C_DIM);
    }

    // vista previa
    panel(156, 630, 1608, 150, C_PANEL);
    text(190, 648, "Vista previa", 2, C_ACCENT);
    text(190, 684, "Asi se ve el texto normal", 2, C_TEXT);
    text(190, 716, "Y asi el texto atenuado (descripciones)", 2, C_DIM);
    text(900, 684, "Todo bien: listo", 2, C_OK);
    text(900, 716, "Algo fallo: error", 2, C_ERR);
    fill(1300, 650, 140, 54, C_ACCENT);
    text(1318, 664, "OK", 3, C_BG);
    fill(1470, 650, 140, 54, C_SEL);
    text(1488, 664, "Sel", 3, C_TEXT);

    char d[360];
    snprintf(d, sizeof(d), "Tus imagenes: copia archivos .png o .jpg (ideal 1920x1080) por FTP a %s/fondos y pulsa Options.", plat_data_dir());
    text(156, 800, d, 2, C_DIM, 112);
    snprintf(d, sizeof(d), "Imagenes encontradas: %d", g_bgList.n);
    text(156, 836, d, 2, g_bgList.n ? C_OK : C_DIM);
    draw_footer("Arriba/Abajo: opcion | Izq/Der: cambiar | Options: recargar imagenes | Circulo: guardar y volver");
}

static void theme_set(int t) {
    g_theme = (t % N_THEMES + N_THEMES) % N_THEMES;
    bool wasLight = g_light;
    theme_apply();
    if (wasLight != g_light) bg_rebuild();
}

static void bg_commit() {  // aplica ya la imagen elegida (sin esperar)
    if (!g_bgPendingSel) return;
    g_bgPendingSel = false;
    bg_select(g_bgIdx >= 0 ? g_bgList.name[g_bgIdx] : "");
}

// Cada fotograma
static void look_tick() {
    bg_tick();
    if (g_bgPendingSel && plat_ms() - g_bgSelAt > 450) bg_commit();
}

static void input_theme(uint32_t p) {
    if (p & BTN_DOWN) g_thSel = clampi(g_thSel + 1, 0, 2);
    if (p & BTN_UP) g_thSel = clampi(g_thSel - 1, 0, 2);
    int d = 0;
    if (p & (BTN_RIGHT | BTN_R1)) d = 1;
    if (p & (BTN_LEFT | BTN_L1)) d = -1;
    if (d) {
        if (g_thSel == 0) theme_set(g_theme + d);
        else if (g_thSel == 1) {
            if (g_bgList.n) {  // -1 (ninguno), 0 .. n-1
                int v = g_bgIdx + d;
                if (v < -1) v = g_bgList.n - 1;
                if (v >= g_bgList.n) v = -1;
                g_bgIdx = v;
                g_bgPendingSel = true;
                g_bgSelAt = plat_ms();
            }
        } else {
            int v = clampi(g_dim + d, 0, 9);
            if (v != g_dim) { g_dim = v; bg_rebuild(); }
        }
    }
    if (p & BTN_OPTIONS) {
        bg_scan();
        set_status(C_DIM, "%d imagen(es) en fondos.", g_bgList.n);
    }
    if (p & BTN_CIRCLE) {
        bg_commit();
        theme_save();
        A.scr = S_MENU;
    }
}

// ---------- entrar a cada seccion ----------

static void go_catalog() {
    if (!g_job && (A.mode == M_LAN ? A.n == 0 : !A.catLoaded)) start_search();
    A.scr = S_LIST;
}

static void go_store() {
    if (!V.storeUrl[0] || A.mode != M_GITHUB) {
        set_status(C_DIM, "La tienda de CurseForge solo funciona con la fuente GitHub y su catalogo sincronizado.");
        go_catalog();
        return;
    }
    if (!V.on && !V.booting) store_boot();
    A.scr = S_STORE;
}

static void open_install(Screen back) {
    I.modal = MD_NONE;
    install_rescan();
    I.top = 0;
    set_status(C_DIM, "Elige un pack y pulsa X (Minecraft abierto).");
    g_instBack = back;
    A.scr = S_INSTALL;
}

static void open_search() {
    go_store();
    if (V.on) {
        snprintf(A.kbuf, sizeof(A.kbuf), "%s", V.query);
        A.kr = A.kc = 0;
        g_kbBack = S_STORE;
        A.scr = S_KEYBOARD;
    }
}

static void open_look() {
    bg_scan();
    g_thSel = 0;
    g_bgPendingSel = false;
    A.scr = S_THEME;
}

static void open_settings() {
    A.edit = A.srv;
    A.editMode = A.mode;
    A.field = 0;
    g_setBack = S_MENU;
    A.scr = S_SETTINGS;
}

static void menu_activate(int t) {
    switch (t) {
    case T_STORE: go_store(); break;
    case T_SEARCH: open_search(); break;
    case T_CAT: go_catalog(); break;
    case T_NEWS:
        if (!A.catLoaded && A.mode == M_GITHUB) { go_catalog(); set_status(C_TEXT, "Cargando tu catalogo: al terminar vuelve a pulsar Novedades."); A.scr = S_MENU; }
        else start_bulk();
        break;
    case T_INST: open_install(S_MENU); break;
    case T_LOOK: open_look(); break;
    case T_SET: open_settings(); break;
    case T_UPD: check_app_update(); break;
    }
}

static void input_menu(uint32_t p) {
    int c = g_menuSel % 4, r = g_menuSel / 4;
    if (p & BTN_RIGHT) c = (c + 1) % 4;
    if (p & BTN_LEFT) c = (c + 3) % 4;
    if (p & BTN_DOWN) r = (r + 1) % 2;
    if (p & BTN_UP) r = (r + 1) % 2;
    g_menuSel = r * 4 + c;
    if (p & BTN_CROSS) menu_activate(g_menuSel);
    if (p & BTN_SQUARE) open_search();
    if (p & BTN_TRIANGLE) open_look();
    if (p & BTN_OPTIONS) open_settings();
    if (p & BTN_L2) menu_activate(T_NEWS);
    if (p & BTN_L3) check_app_update();
    if (p & (BTN_L1 | BTN_R1)) {
        theme_set(g_theme + ((p & BTN_R1) ? 1 : -1));
        theme_save();
    }
}
