// Sonido sintetizado (sin archivos): efectos al mover/elegir/terminar una descarga y una musica suave en bucle.
// audio_render() es portable (se prueba en PC); el hilo que lo manda a la salida de audio esta en platform_ps4.cpp.
#pragma once
#include <atomic>
#include <stdint.h>
#include <math.h>

#define AU_RATE 48000
enum { SFX_NONE = 0, SFX_MOVE, SFX_BACK, SFX_SELECT, SFX_DONE, SFX_ERROR };

static std::atomic<int> g_auMusic(1);    // musica de fondo encendida
static std::atomic<int> g_auSfxOn(1);    // efectos encendidos
static std::atomic<int> g_auPending(0);  // efecto pedido por la pantalla (lo recoge el hilo de audio)
static std::atomic<int> g_auBusy(0);     // 1 mientras suena un efecto

struct AuNote { int hz; int ms; };  // hz 0 = silencio; ms 0 = fin
static const AuNote AU_MOVE[] = {{1500, 18}, {0, 0}};
static const AuNote AU_BACK[] = {{700, 40}, {500, 50}, {0, 0}};
static const AuNote AU_SELECT[] = {{880, 45}, {1320, 70}, {0, 0}};
static const AuNote AU_DONE[] = {{523, 90}, {659, 90}, {784, 90}, {1047, 220}, {0, 0}};
static const AuNote AU_ERROR[] = {{220, 140}, {165, 220}, {0, 0}};
static const AuNote *const AU_SFX[] = {NULL, AU_MOVE, AU_BACK, AU_SELECT, AU_DONE, AU_ERROR};
static const int AU_PRIO[] = {0, 1, 2, 2, 4, 4};

static void sfx(int k) {
    if (!g_auSfxOn.load()) return;
    int cur = g_auPending.load();
    if (cur && AU_PRIO[cur] > AU_PRIO[k]) return;  // no pisar un aviso importante pendiente
    g_auPending = k;
}

static float g_auMidi[128];
static bool g_auInit = false;
static void audio_init() {
    if (g_auInit) return;
    float f = 8.175799f;  // MIDI 0
    for (int i = 0; i < 128; i++) { g_auMidi[i] = f; f *= 1.0594630943592953f; }
    g_auInit = true;
}

static inline float au_sq(float ph, float duty) { return ph < duty ? 1.0f : -1.0f; }
static inline float au_tri(float ph) { return ph < 0.5f ? 4.0f * ph - 1.0f : 3.0f - 4.0f * ph; }

// ---- musica: piano suave y espacioso, al estilo calmado de Minecraft (original, no es ninguna cancion del juego) ----
// Acordes C - Am - F - G (72 bpm). Cada nota suena como una tecla de piano que se apaga sola, con eco, y las
// notas aparecen "sueltas" (con silencios), como en la musica ambiente del juego.
static const int M_ROOT[4] = {48, 45, 41, 43};
static const int M_TONES[4][4] = {{0, 4, 7, 11}, {0, 3, 7, 10}, {0, 4, 7, 11}, {0, 4, 7, 14}};
static const int M_PENTA[5] = {0, 2, 4, 7, 9};  // escala pentatonica de Do para la melodia

struct AuMusic { long pos; float pb, pa, pl; };
static AuMusic g_mu;
struct AuVoice { int kind, idx; long left; float ph; };
static AuVoice g_vo;

struct PVoice { float f, ph, age, amp, dec; bool on; };
static PVoice g_pv[10];
static float g_sinT[1024];
static float g_echo[17000];
static int g_echoI = 0;
static bool g_pvInit = false;
static inline float au_sin(float ph) { return g_sinT[(int)(ph * 1024.0f) & 1023]; }

static void pv_start(int midi, float amp, float dec) {
    int k = 0;
    for (int i = 0; i < 10; i++) {
        if (!g_pv[i].on) { k = i; break; }
        if (g_pv[i].age > g_pv[k].age) k = i;
    }
    g_pv[k].f = g_auMidi[midi]; g_pv[k].ph = 0; g_pv[k].age = 0; g_pv[k].amp = amp; g_pv[k].dec = dec; g_pv[k].on = true;
}
static inline unsigned au_hash(unsigned x) { x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; return x ^ (x >> 16); }

static float music_sample() {
    if (!g_pvInit) {
        for (int i = 0; i < 1024; i++) g_sinT[i] = (float)sin(i * 6.283185307179586 / 1024.0);
        g_pvInit = true;
    }
    const long STEP = AU_RATE * 60 / (72 * 2);  // una corchea
    if (g_mu.pos % STEP == 0) {
        long step = g_mu.pos / STEP;
        int chord = (int)((step / 16) % 4), s16 = (int)(step % 16);
        unsigned h = au_hash((unsigned)step * 2654435761u + 77u);
        int root = M_ROOT[chord];
        if (s16 == 0) { pv_start(root, 0.55f, 0.55f); pv_start(root + 12, 0.25f, 0.9f); }
        else if (s16 == 8) pv_start(root + M_TONES[chord][2] - 12 + 12, 0.30f, 0.8f);
        // notas sueltas del acorde (mas probables en los tiempos pares, silencio al final del compas)
        int dens = (s16 % 2 == 0) ? 50 : 18;
        if (s16 >= 14) dens = 8;
        if ((int)(h % 100) < dens) pv_start(root + 24 + M_TONES[chord][(h >> 8) % 4], 0.22f, 1.3f);
        // melodia escasa y alta
        if (s16 % 4 == 2 && ((h >> 16) % 100) < 30) pv_start(72 + M_PENTA[(h >> 20) % 5] + (((h >> 24) % 3 == 0) ? 12 : 0), 0.20f, 1.0f);
    }
    float s = 0;
    for (int i = 0; i < 10; i++) {
        PVoice &v = g_pv[i];
        if (!v.on) continue;
        v.age += 1.0f / AU_RATE;
        v.ph += v.f / AU_RATE; if (v.ph >= 1.0f) v.ph -= 1.0f;
        float env = expf(-v.age * v.dec * 3.0f);
        if (env < 0.003f) { v.on = false; continue; }
        float atk = v.age < 0.006f ? v.age / 0.006f : 1.0f;
        float tone = au_sin(v.ph) + 0.30f * au_sin(v.ph * 2.0f - (int)(v.ph * 2.0f)) * expf(-v.age * 4.0f) +
                     0.10f * au_sin(v.ph * 3.0f - (int)(v.ph * 3.0f));
        s += tone * env * atk * v.amp;
    }
    float e = g_echo[g_echoI];
    g_echo[g_echoI] = s + 0.5f * e;
    if (++g_echoI >= 17000) g_echoI = 0;
    s = (s + 0.4f * e) * 0.6f;
    g_mu.pos++;
    return s;
}

static float sfx_sample() {
    int pend = g_auPending.exchange(0);
    if (pend && (g_vo.kind == 0 || AU_PRIO[pend] >= AU_PRIO[g_vo.kind])) {
        g_vo.kind = pend; g_vo.idx = 0; g_vo.ph = 0;
        g_vo.left = (long)AU_SFX[pend][0].ms * AU_RATE / 1000;
    }
    if (!g_vo.kind) { g_auBusy = 0; return 0; }
    g_auBusy = 1;
    const AuNote &n = AU_SFX[g_vo.kind][g_vo.idx];
    long total = (long)n.ms * AU_RATE / 1000;
    float e = (float)g_vo.left / (total ? total : 1);
    float s = 0;
    if (n.hz) {
        g_vo.ph += (float)n.hz / AU_RATE; if (g_vo.ph >= 1) g_vo.ph -= 1;
        s = au_sq(g_vo.ph, 0.5f) * (e < 0.3f ? e / 0.3f : 1.0f) * 0.9f;
    }
    if (--g_vo.left <= 0) {
        g_vo.idx++;
        if (AU_SFX[g_vo.kind][g_vo.idx].ms == 0) g_vo.kind = 0;
        else g_vo.left = (long)AU_SFX[g_vo.kind][g_vo.idx].ms * AU_RATE / 1000;
    }
    return s;
}

// Rellena `n` muestras (S16 mono, 48 kHz). Devuelve false si no hay nada que sonar (para cerrar la salida).
static bool audio_render(int16_t *out, int n) {
    audio_init();
    bool mus = g_auMusic.load() != 0, sf = g_auSfxOn.load() != 0 && (g_auPending.load() != 0 || g_vo.kind != 0);
    if (!mus && !sf) { for (int i = 0; i < n; i++) out[i] = 0; return false; }
    for (int i = 0; i < n; i++) {
        float m = 0;
        if (mus) m += music_sample() * 0.32f;
        m += sfx_sample() * 0.35f;
        int v = (int)(m * 32767.0f);
        out[i] = (int16_t)(v > 32767 ? 32767 : v < -32768 ? -32768 : v);
    }
    return true;
}
