// Sonido sintetizado (sin archivos): efectos al mover/elegir/terminar una descarga y una musica suave en bucle.
// audio_render() es portable (se prueba en PC); el hilo que lo manda a la salida de audio esta en platform_ps4.cpp.
#pragma once
#include <atomic>
#include <stdint.h>

#define AU_RATE 48000
enum { SFX_NONE = 0, SFX_MOVE, SFX_BACK, SFX_SELECT, SFX_DONE, SFX_ERROR };

static std::atomic<int> g_auMusic(1);    // musica de fondo encendida
static std::atomic<int> g_auSfxOn(1);    // efectos encendidos
static std::atomic<int> g_auPending(0);  // efecto pedido por la pantalla (lo recoge el hilo de audio)
static std::atomic<int> g_auBusy(0);     // 1 mientras suena un efecto

struct AuNote { int hz; int ms; };  // hz 0 = silencio; ms 0 = fin
static const AuNote AU_MOVE[] = {{1500, 18}, {0, 0}};
static const AuNote AU_BACK[] = {{700, 40}, {500, 50}, {0, 0}};
static const AuNote AU_SELECT[] = {{880, 45}, {1320, 70}, {0, 0}};
static const AuNote AU_DONE[] = {{523, 90}, {659, 90}, {784, 90}, {1047, 220}, {0, 0}};
static const AuNote AU_ERROR[] = {{220, 140}, {165, 220}, {0, 0}};
static const AuNote *const AU_SFX[] = {NULL, AU_MOVE, AU_BACK, AU_SELECT, AU_DONE, AU_ERROR};
static const int AU_PRIO[] = {0, 1, 2, 2, 4, 4};

static void sfx(int k) {
    if (!g_auSfxOn.load()) return;
    int cur = g_auPending.load();
    if (cur && AU_PRIO[cur] > AU_PRIO[k]) return;  // no pisar un aviso importante pendiente
    g_auPending = k;
}

static float g_auMidi[128];
static bool g_auInit = false;
static void audio_init() {
    if (g_auInit) return;
    float f = 8.175799f;  // MIDI 0
    for (int i = 0; i < 128; i++) { g_auMidi[i] = f; f *= 1.0594630943592953f; }
    g_auInit = true;
}

static inline float au_sq(float ph, float duty) { return ph < duty ? 1.0f : -1.0f; }
static inline float au_tri(float ph) { return ph < 0.5f ? 4.0f * ph - 1.0f : 3.0f - 4.0f * ph; }

// ---- musica: Am - F - C - G, bajo triangular + arpegio + melodia (original, 100 bpm) ----
static const int M_ROOT[4] = {45, 41, 48, 43};
static const int M_MINOR[4] = {1, 0, 0, 0};
static const int M_LEAD[4][8] = {{72, 0, 76, 72, 71, 0, 67, 0}, {77, 0, 72, 69, 72, 0, 69, 0}, {76, 0, 79, 76, 72, 0, 76, 0}, {74, 0, 71, 67, 71, 0, 74, 0}};
static const int M_ARP[8] = {0, 1, 2, 1, 0, 2, 1, 2};

struct AuMusic { long pos; float pb, pa, pl; };
static AuMusic g_mu;
struct AuVoice { int kind, idx; long left; float ph; };
static AuVoice g_vo;

static float music_sample() {
    const long STEP = AU_RATE * 60 / (100 * 2);  // una corchea
    long step = g_mu.pos / STEP, within = g_mu.pos % STEP;
    int chord = (int)((step / 16) % 4), s16 = (int)(step % 16), s8 = s16 % 8;
    int root = M_ROOT[chord];
    int third = M_MINOR[chord] ? 3 : 4;
    int tones[3] = {0, third, 7};
    float env = 1.0f - (float)within / STEP;
    int bnote = root + ((s8 == 4) ? 7 : 0);
    float fb = g_auMidi[bnote], fa = g_auMidi[root + 24 + tones[M_ARP[s8]]];
    g_mu.pb += fb / AU_RATE; if (g_mu.pb >= 1) g_mu.pb -= 1;
    g_mu.pa += fa / AU_RATE; if (g_mu.pa >= 1) g_mu.pa -= 1;
    float s = au_tri(g_mu.pb) * (0.55f + 0.2f * env) * 0.5f + au_sq(g_mu.pa, 0.25f) * env * 0.16f;
    int ln = M_LEAD[chord][s8];
    if (s16 >= 8) ln = M_LEAD[chord][7 - s8] ? M_LEAD[chord][7 - s8] : 0;  // segunda mitad: el motivo al reves
    if (ln) {
        g_mu.pl += g_auMidi[ln] / AU_RATE; if (g_mu.pl >= 1) g_mu.pl -= 1;
        float le = 1.0f - (float)within / (STEP * 2);
        s += au_sq(g_mu.pl, 0.5f) * le * 0.12f;
    }
    g_mu.pos++;
    return s;
}

static float sfx_sample() {
    int pend = g_auPending.exchange(0);
    if (pend && (g_vo.kind == 0 || AU_PRIO[pend] >= AU_PRIO[g_vo.kind])) {
        g_vo.kind = pend; g_vo.idx = 0; g_vo.ph = 0;
        g_vo.left = (long)AU_SFX[pend][0].ms * AU_RATE / 1000;
    }
    if (!g_vo.kind) { g_auBusy = 0; return 0; }
    g_auBusy = 1;
    const AuNote &n = AU_SFX[g_vo.kind][g_vo.idx];
    long total = (long)n.ms * AU_RATE / 1000;
    float e = (float)g_vo.left / (total ? total : 1);
    float s = 0;
    if (n.hz) {
        g_vo.ph += (float)n.hz / AU_RATE; if (g_vo.ph >= 1) g_vo.ph -= 1;
        s = au_sq(g_vo.ph, 0.5f) * (e < 0.3f ? e / 0.3f : 1.0f) * 0.9f;
    }
    if (--g_vo.left <= 0) {
        g_vo.idx++;
        if (AU_SFX[g_vo.kind][g_vo.idx].ms == 0) g_vo.kind = 0;
        else g_vo.left = (long)AU_SFX[g_vo.kind][g_vo.idx].ms * AU_RATE / 1000;
    }
    return s;
}

// Rellena `n` muestras (S16 mono, 48 kHz). Devuelve false si no hay nada que sonar (para cerrar la salida).
static bool audio_render(int16_t *out, int n) {
    audio_init();
    bool mus = g_auMusic.load() != 0, sf = g_auSfxOn.load() != 0 && (g_auPending.load() != 0 || g_vo.kind != 0);
    if (!mus && !sf) { for (int i = 0; i < n; i++) out[i] = 0; return false; }
    for (int i = 0; i < n; i++) {
        float m = 0;
        if (mus) m += music_sample() * 0.32f;
        m += sfx_sample() * 0.35f;
        int v = (int)(m * 32767.0f);
        out[i] = (int16_t)(v > 32767 ? 32767 : v < -32768 ? -32768 : v);
    }
    return true;
}
