// Instalacion de .mcpack en Minecraft (PS4): deteccion de la ruta, lectura del manifest y copia.
//
// Ruta de destino (verificada por el usuario con Minecraft abierto):
//     /app_tmp/<CUSA>/user<ID>/games/com.mojang/{resource_packs,behavior_packs,...}
// No se usa ninguna ruta fija: se detecta cada vez. Esa carpeta solo existe mientras Minecraft esta abierto.
#pragma once
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "platform.h"

// ---------------------------------------------------------------------------------------------
// Regiones de la consola. Para ampliar, agrega aqui el CUSA nuevo (una linea).
// ---------------------------------------------------------------------------------------------
static const char *const MC_CUSA_LIST[] = {
    "CUSA00744",  // America (US / LATAM)
    "CUSA00265",  // Europa / Asia
    "CUSA00283",  // Japon
};
#define MC_CUSA_COUNT ((int)(sizeof(MC_CUSA_LIST) / sizeof(MC_CUSA_LIST[0])))

static bool mc_is_dir(const char *p) {
    bool d = false;
    long sz = 0;
    return plat_stat(p, &d, &sz) && d;
}
static bool mc_exists(const char *p) {
    bool d = false;
    long sz = 0;
    return plat_stat(p, &d, &sz);
}
static long mc_file_size(const char *p) {
    bool d = false;
    long sz = 0;
    return plat_stat(p, &d, &sz) ? sz : -1;
}

// ---------------------------------------------------------------------------------------------
// 1) Deteccion de la ruta
// ---------------------------------------------------------------------------------------------
#define MC_MAX_TARGETS 8
struct McTargets {
    int n;
    char path[MC_MAX_TARGETS][300];  // cada una termina en ".../games/com.mojang"
};

struct McDirList {
    int n;
    char names[96][64];
};
static void mc_dirlist_cb(const char *name, void *ctx) {
    McDirList *d = (McDirList *)ctx;
    if (d->n < 96) snprintf(d->names[d->n++], sizeof(d->names[0]), "%s", name);
}
static bool mc_list(const char *dir, McDirList *out) {
    out->n = 0;
    return plat_listdir(dir, mc_dirlist_cb, out);
}

static void mc_add_target(McTargets *t, const char *base) {
    if (t->n >= MC_MAX_TARGETS) return;
    for (int i = 0; i < t->n; i++)
        if (!strcmp(t->path[i], base)) return;
    snprintf(t->path[t->n++], sizeof(t->path[0]), "%s", base);
}

// Devuelve cuantas carpetas com.mojang se encontraron (0 = Minecraft no esta abierto).
static int mc_detect(McTargets *t) {
    t->n = 0;
    const char *root = plat_apptmp_dir();
    static McDirList L, L2;  // estaticas: no caben comodas en la pila
    char dir[300], base[340], chk[400];

    // Pasos 1-3: carpetas conocidas (CUSA) -> user* -> games/com.mojang con resource_packs y behavior_packs.
    for (int c = 0; c < MC_CUSA_COUNT; c++) {
        snprintf(dir, sizeof(dir), "%s/%s", root, MC_CUSA_LIST[c]);
        if (!mc_list(dir, &L)) continue;
        for (int i = 0; i < L.n; i++) {
            if (strncmp(L.names[i], "user", 4)) continue;
            snprintf(base, sizeof(base), "%s/%s/games/com.mojang", dir, L.names[i]);
            snprintf(chk, sizeof(chk), "%s/resource_packs", base);
            if (!mc_is_dir(chk)) continue;
            snprintf(chk, sizeof(chk), "%s/behavior_packs", base);
            if (!mc_is_dir(chk)) continue;
            mc_add_target(t, base);
        }
    }
    if (t->n > 0) return t->n;

    // Paso 4: cualquier carpeta de /app_tmp que contenga games/com.mojang (directa o dentro de user*).
    if (!mc_list(root, &L)) return 0;
    for (int i = 0; i < L.n; i++) {
        snprintf(dir, sizeof(dir), "%s/%s", root, L.names[i]);
        snprintf(base, sizeof(base), "%s/games/com.mojang", dir);
        if (mc_is_dir(base)) mc_add_target(t, base);
        if (!mc_list(dir, &L2)) continue;
        for (int k = 0; k < L2.n; k++) {
            if (strncmp(L2.names[k], "user", 4)) continue;
            snprintf(base, sizeof(base), "%s/%s/games/com.mojang", dir, L2.names[k]);
            if (mc_is_dir(base)) mc_add_target(t, base);
        }
    }
    return t->n;
}

// ---------------------------------------------------------------------------------------------
// 2) Lector minimo de ZIP + inflate (para leer manifest.json sin extraer el .mcpack)
// ---------------------------------------------------------------------------------------------
namespace mcz {

// Inflate al estilo "puff" (zlib/contrib/puff): pequeno y sin dependencias.
struct State {
    const uint8_t *in;
    size_t inlen, incnt;
    uint32_t bitbuf;
    int bitcnt;
    uint8_t *out;
    size_t outlen, outcnt;
    int err;
};
struct Huff {
    short count[16];
    short symbol[288];
};

static int bits(State *s, int need) {
    uint32_t val = s->bitbuf;
    while (s->bitcnt < need) {
        if (s->incnt >= s->inlen) { s->err = 1; return 0; }
        val |= (uint32_t)s->in[s->incnt++] << s->bitcnt;
        s->bitcnt += 8;
    }
    s->bitbuf = val >> need;
    s->bitcnt -= need;
    return (int)(val & ((1u << need) - 1));
}

static int decode(State *s, const Huff *h) {
    int len, code = 0, first = 0, count, index = 0;
    for (len = 1; len <= 15; len++) {
        code |= bits(s, 1);
        count = h->count[len];
        if (code - count < first) return h->symbol[index + (code - first)];
        index += count;
        first += count;
        first <<= 1;
        code <<= 1;
        if (s->err) return -1;
    }
    return -10;
}

static int construct(Huff *h, const short *length, int n) {
    int symbol, len, left;
    short offs[16];
    for (len = 0; len <= 15; len++) h->count[len] = 0;
    for (symbol = 0; symbol < n; symbol++) h->count[length[symbol]]++;
    if (h->count[0] == n) return 0;
    left = 1;
    for (len = 1; len <= 15; len++) {
        left <<= 1;
        left -= h->count[len];
        if (left < 0) return left;
    }
    offs[1] = 0;
    for (len = 1; len < 15; len++) offs[len + 1] = (short)(offs[len] + h->count[len]);
    for (symbol = 0; symbol < n; symbol++)
        if (length[symbol] != 0) h->symbol[offs[length[symbol]]++] = (short)symbol;
    return left;
}

static int codes(State *s, const Huff *lencode, const Huff *distcode) {
    static const short lens[29] = {3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27,
                                   31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258};
    static const short lext[29] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0};
    static const short dists[30] = {1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129,
                                    193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577};
    static const short dext[30] = {0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13};
    int symbol, len;
    unsigned dist;
    do {
        symbol = decode(s, lencode);
        if (symbol < 0) return symbol;
        if (symbol < 256) {
            if (s->outcnt == s->outlen) return 1;
            s->out[s->outcnt++] = (uint8_t)symbol;
        } else if (symbol > 256) {
            symbol -= 257;
            if (symbol >= 29) return -10;
            len = lens[symbol] + bits(s, lext[symbol]);
            symbol = decode(s, distcode);
            if (symbol < 0) return symbol;
            dist = (unsigned)(dists[symbol] + bits(s, dext[symbol]));
            if (s->err) return -1;
            if (dist > s->outcnt) return -11;
            if (s->outcnt + (size_t)len > s->outlen) return 1;
            while (len--) {
                s->out[s->outcnt] = s->out[s->outcnt - dist];
                s->outcnt++;
            }
        }
        if (s->err) return -1;
    } while (symbol != 256);
    return 0;
}

static int fixed(State *s) {
    static Huff lencode, distcode;
    static bool built = false;
    if (!built) {
        short lengths[288];
        int symbol;
        for (symbol = 0; symbol < 144; symbol++) lengths[symbol] = 8;
        for (; symbol < 256; symbol++) lengths[symbol] = 9;
        for (; symbol < 280; symbol++) lengths[symbol] = 7;
        for (; symbol < 288; symbol++) lengths[symbol] = 8;
        construct(&lencode, lengths, 288);
        for (symbol = 0; symbol < 30; symbol++) lengths[symbol] = 5;
        construct(&distcode, lengths, 30);
        built = true;
    }
    return codes(s, &lencode, &distcode);
}

static int dynamic(State *s) {
    static const short order[19] = {16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15};
    short lengths[320];
    Huff lencode, distcode;
    int nlen = bits(s, 5) + 257, ndist = bits(s, 5) + 1, ncode = bits(s, 4) + 4;
    if (s->err) return -1;
    if (nlen > 286 || ndist > 30) return -3;
    int index;
    for (index = 0; index < ncode; index++) lengths[order[index]] = (short)bits(s, 3);
    for (; index < 19; index++) lengths[order[index]] = 0;
    if (construct(&lencode, lengths, 19) != 0) return -4;
    index = 0;
    while (index < nlen + ndist) {
        int symbol = decode(s, &lencode);
        if (symbol < 0) return symbol;
        if (symbol < 16) {
            lengths[index++] = (short)symbol;
        } else {
            int len = 0;
            if (symbol == 16) {
                if (index == 0) return -5;
                len = lengths[index - 1];
                symbol = 3 + bits(s, 2);
            } else if (symbol == 17) {
                symbol = 3 + bits(s, 3);
            } else {
                symbol = 11 + bits(s, 7);
            }
            if (index + symbol > nlen + ndist) return -6;
            while (symbol--) lengths[index++] = (short)len;
        }
        if (s->err) return -1;
    }
    if (lengths[256] == 0) return -9;
    int err = construct(&lencode, lengths, nlen);
    if (err && (err < 0 || nlen != lencode.count[0] + lencode.count[1])) return -7;
    err = construct(&distcode, lengths + nlen, ndist);
    if (err && (err < 0 || ndist != distcode.count[0] + distcode.count[1])) return -8;
    return codes(s, &lencode, &distcode);
}

static int stored(State *s) {
    s->bitbuf = 0;
    s->bitcnt = 0;
    if (s->incnt + 4 > s->inlen) return 2;
    unsigned len = s->in[s->incnt++];
    len |= (unsigned)s->in[s->incnt++] << 8;
    unsigned nlen = s->in[s->incnt++];
    nlen |= (unsigned)s->in[s->incnt++] << 8;
    if (len != (~nlen & 0xFFFF)) return -2;
    if (s->incnt + len > s->inlen) return 2;
    if (s->outcnt + len > s->outlen) return 1;
    memcpy(s->out + s->outcnt, s->in + s->incnt, len);
    s->incnt += len;
    s->outcnt += len;
    return 0;
}

// Devuelve true si descomprimio exactamente outlen bytes.
static bool inflate_raw(const uint8_t *in, size_t inlen, uint8_t *out, size_t outlen) {
    State s;
    memset(&s, 0, sizeof(s));
    s.in = in; s.inlen = inlen; s.out = out; s.outlen = outlen;
    int last, type, err = 0;
    do {
        last = bits(&s, 1);
        type = bits(&s, 2);
        if (s.err) return false;
        err = type == 0 ? stored(&s) : type == 1 ? fixed(&s) : type == 2 ? dynamic(&s) : -1;
        if (err != 0) return false;
    } while (!last);
    return s.outcnt == outlen;
}

static uint32_t rd16(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8); }
static uint32_t rd32(const uint8_t *p) { return rd16(p) | (rd16(p + 2) << 16); }

#define MCZ_MAX_MANIFEST (1024 * 1024)

// Lee manifest.json (el menos profundo) del zip, sin extraer nada al disco. *out se libera con free().
static bool read_manifest(const char *path, uint8_t **out, size_t *outlen, char *err, size_t ecap) {
    FILE *f = fopen(path, "rb");
    if (!f) { snprintf(err, ecap, "no se pudo abrir el archivo"); return false; }
    bool ok = false;
    uint8_t *tb = NULL, *comp = NULL, *dat = NULL;
    do {
        fseek(f, 0, SEEK_END);
        long fsz = ftell(f);
        if (fsz < 22) { snprintf(err, ecap, "no es un .mcpack valido (muy pequeno)"); break; }
        long tail = fsz < 65557 ? fsz : 65557;
        tb = (uint8_t *)malloc((size_t)tail);
        if (!tb) { snprintf(err, ecap, "sin memoria"); break; }
        fseek(f, fsz - tail, SEEK_SET);
        if (fread(tb, 1, (size_t)tail, f) != (size_t)tail) { snprintf(err, ecap, "error de lectura"); break; }
        long e = -1;
        for (long i = tail - 22; i >= 0; i--)
            if (rd32(tb + i) == 0x06054b50u) { e = i; break; }
        if (e < 0) { snprintf(err, ecap, "no es un zip valido (falta el directorio central)"); break; }
        uint32_t entries = rd16(tb + e + 10), cdoff = rd32(tb + e + 16);
        if (cdoff == 0xFFFFFFFFu) { snprintf(err, ecap, "zip64 no soportado"); break; }
        if (fseek(f, (long)cdoff, SEEK_SET) != 0) { snprintf(err, ecap, "zip danado"); break; }

        int bestDepth = 99, bestMethod = 0, bestFlags = 0;
        uint32_t bestOff = 0, bestComp = 0, bestUnc = 0;
        for (uint32_t i = 0; i < entries; i++) {
            uint8_t h[46];
            if (fread(h, 1, 46, f) != 46 || rd32(h) != 0x02014b50u) break;
            uint32_t flags = rd16(h + 8), method = rd16(h + 10);
            uint32_t csz = rd32(h + 20), usz = rd32(h + 24);
            uint32_t nl = rd16(h + 28), el = rd16(h + 30), cl = rd16(h + 32), off = rd32(h + 42);
            char name[256];
            size_t take = nl < 255 ? nl : 255;
            if (fread(name, 1, take, f) != take) break;
            name[take] = 0;
            if (fseek(f, (long)((nl - take) + el + cl), SEEK_CUR) != 0) break;
            int depth = 0;
            for (char *c = name; *c; c++) {
                if (*c == '\\') *c = '/';
                if (*c == '/') depth++;
            }
            size_t L = strlen(name);
            bool match = L >= 13 && !strcmp(name + L - 13, "manifest.json") && (L == 13 || name[L - 14] == '/');
            if (match && strncmp(name, "__MACOSX/", 9) && depth < bestDepth) {
                bestDepth = depth; bestMethod = (int)method; bestFlags = (int)flags;
                bestOff = off; bestComp = csz; bestUnc = usz;
            }
        }
        if (bestDepth == 99) { snprintf(err, ecap, "el .mcpack no tiene manifest.json"); break; }
        if (bestFlags & 1) { snprintf(err, ecap, "el manifest esta cifrado"); break; }
        if (bestComp > MCZ_MAX_MANIFEST || bestUnc > MCZ_MAX_MANIFEST) { snprintf(err, ecap, "manifest.json demasiado grande"); break; }

        uint8_t lh[30];
        if (fseek(f, (long)bestOff, SEEK_SET) != 0 || fread(lh, 1, 30, f) != 30 || rd32(lh) != 0x04034b50u) {
            snprintf(err, ecap, "zip danado (cabecera local)");
            break;
        }
        if (fseek(f, (long)(rd16(lh + 26) + rd16(lh + 28)), SEEK_CUR) != 0) { snprintf(err, ecap, "zip danado"); break; }
        comp = (uint8_t *)malloc(bestComp ? bestComp : 1);
        dat = (uint8_t *)malloc((size_t)bestUnc + 1);
        if (!comp || !dat) { snprintf(err, ecap, "sin memoria"); break; }
        if (fread(comp, 1, bestComp, f) != bestComp) { snprintf(err, ecap, "zip danado (datos truncados)"); break; }
        if (bestMethod == 0) {
            if (bestComp != bestUnc) { snprintf(err, ecap, "zip danado"); break; }
            memcpy(dat, comp, bestUnc);
        } else if (bestMethod == 8) {
            if (!inflate_raw(comp, bestComp, dat, bestUnc)) { snprintf(err, ecap, "no se pudo descomprimir manifest.json"); break; }
        } else {
            snprintf(err, ecap, "compresion %d no soportada", bestMethod);
            break;
        }
        dat[bestUnc] = 0;
        *out = dat;
        *outlen = bestUnc;
        dat = NULL;
        ok = true;
    } while (0);
    free(tb);
    free(comp);
    free(dat);
    fclose(f);
    return ok;
}

}  // namespace mcz

// ---------------------------------------------------------------------------------------------
// 3) Clasificacion por manifest.json
// ---------------------------------------------------------------------------------------------
enum { PK_NONE = 0, PK_RES = 1, PK_BEH = 2, PK_BAD = 3 };

struct McPack {
    int kind;         // PK_RES -> resource_packs, PK_BEH -> behavior_packs, PK_BAD -> no instalable (ver err)
    bool hasMin;
    int minEng[3];    // header.min_engine_version
    char name[64];    // header.name (vacio si es una clave de idioma)
    char types[48];   // tipos de modulo encontrados, para mostrar
    char err[160];
};

// --- mini escaner de JSON (suficiente para manifest.json) ---
static const char *js_ws(const char *p, const char *e) {
    while (p < e && (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n')) p++;
    return p;
}
// p apunta a una comilla de apertura; devuelve la comilla de cierre o NULL.
static const char *js_str_end(const char *p, const char *e) {
    for (p++; p < e; p++) {
        if (*p == '\\') { p++; continue; }
        if (*p == '"') return p;
    }
    return NULL;
}
// Valor de la primera clave con ese nombre en [b,e): puntero al valor (tras ':'), o NULL.
static const char *js_key(const char *b, const char *e, const char *key) {
    size_t kl = strlen(key);
    for (const char *p = b; p < e; p++) {
        if (*p != '"') continue;
        const char *q = js_str_end(p, e);
        if (!q) return NULL;
        if ((size_t)(q - p - 1) == kl && !strncmp(p + 1, key, kl)) {
            const char *v = js_ws(q + 1, e);
            if (v < e && *v == ':') return js_ws(v + 1, e);
        }
        p = q;
    }
    return NULL;
}
// p en '{' o '[': devuelve el puntero justo despues del cierre correspondiente.
static const char *js_block_end(const char *p, const char *e) {
    int depth = 0;
    for (; p < e; p++) {
        if (*p == '"') { p = js_str_end(p, e); if (!p) return NULL; continue; }
        if (*p == '{' || *p == '[') depth++;
        else if (*p == '}' || *p == ']') { if (--depth == 0) return p + 1; }
    }
    return NULL;
}

static void mc_parse_manifest(const char *s, size_t len, McPack *out) {
    memset(out, 0, sizeof(*out));
    const char *e = s + len;
    if (len >= 3 && (uint8_t)s[0] == 0xEF && (uint8_t)s[1] == 0xBB && (uint8_t)s[2] == 0xBF) s += 3;

    bool hasRes = false, hasBeh = false, hasOther = false;
    const char *m = js_key(s, e, "modules");
    if (m && *m == '[') {
        const char *me = js_block_end(m, e);
        if (!me) me = e;
        for (const char *p = m; p < me; p++) {
            if (*p != '"') continue;
            const char *q = js_str_end(p, me);
            if (!q) break;
            const char *v = js_ws(q + 1, me);
            if ((size_t)(q - p - 1) == 4 && !strncmp(p + 1, "type", 4) && v < me && *v == ':') {
                v = js_ws(v + 1, me);
                if (v < me && *v == '"') {
                    const char *ve = js_str_end(v, me);
                    if (!ve) break;
                    char t[24];
                    size_t tl = (size_t)(ve - v - 1);
                    if (tl >= sizeof(t)) tl = sizeof(t) - 1;
                    memcpy(t, v + 1, tl);
                    t[tl] = 0;
                    if (!strcmp(t, "resources")) hasRes = true;
                    else if (!strcmp(t, "data") || !strcmp(t, "script")) hasBeh = true;
                    else if (strcmp(t, "client_data")) { hasOther = true; }
                    if (out->types[0] && strlen(out->types) + tl + 2 < sizeof(out->types)) strcat(out->types, ",");
                    if (strlen(out->types) + tl + 1 < sizeof(out->types)) strcat(out->types, t);
                    q = ve;
                }
            }
            p = q;
        }
    }

    const char *h = js_key(s, e, "header");
    if (h && *h == '{') {
        const char *he = js_block_end(h, e);
        if (!he) he = e;
        const char *mv = js_key(h, he, "min_engine_version");
        if (mv && *mv == '[') {
            const char *p = mv + 1;
            int v[3] = {0, 0, 0}, n = 0;
            while (p < he && n < 3) {
                p = js_ws(p, he);
                if (*p >= '0' && *p <= '9') {
                    v[n++] = atoi(p);
                    while (p < he && *p >= '0' && *p <= '9') p++;
                } else if (*p == ',') {
                    p++;
                } else {
                    break;
                }
            }
            if (n > 0) { out->hasMin = true; for (int i = 0; i < 3; i++) out->minEng[i] = v[i]; }
        }
        const char *nm = js_key(h, he, "name");
        if (nm && *nm == '"') {
            const char *ne = js_str_end(nm, he);
            if (ne) {
                size_t nl = (size_t)(ne - nm - 1);
                if (nl >= sizeof(out->name)) nl = sizeof(out->name) - 1;
                memcpy(out->name, nm + 1, nl);
                out->name[nl] = 0;
                if (strstr(out->name, "pack.") || strchr(out->name, '\\')) out->name[0] = 0;  // clave de idioma
            }
        }
    }

    if (hasRes && hasBeh) {
        out->kind = PK_BAD;
        snprintf(out->err, sizeof(out->err), "El pack mezcla texturas y comportamiento: no se instala (decide el siguiente intento).");
    } else if (hasRes && !hasOther) {
        out->kind = PK_RES;
    } else if (hasBeh && !hasOther) {
        out->kind = PK_BEH;
    } else {
        out->kind = PK_BAD;
        if (!out->types[0]) snprintf(out->err, sizeof(out->err), "El manifest no declara modulos (\"modules\").");
        else snprintf(out->err, sizeof(out->err), "Tipo de pack no soportado todavia: %s", out->types);
    }
}

// Abre el .mcpack, lee su manifest y lo clasifica. No extrae nada.
static void mc_pack_inspect(const char *path, McPack *out) {
    uint8_t *buf = NULL;
    size_t len = 0;
    char err[120];
    memset(out, 0, sizeof(*out));
    if (!mcz::read_manifest(path, &buf, &len, err, sizeof(err))) {
        out->kind = PK_BAD;
        snprintf(out->err, sizeof(out->err), "No se pudo leer el manifest: %s", err);
        return;
    }
    mc_parse_manifest((const char *)buf, len, out);
    free(buf);
}

// ---------------------------------------------------------------------------------------------
// 4) Version de Minecraft de la consola (opcional): /data/mcstore/mcversion.txt con "1.26.51"
// ---------------------------------------------------------------------------------------------
static bool mc_version_load(int v[3]) {
    char p[300];
    snprintf(p, sizeof(p), "%s/mcversion.txt", plat_data_dir());
    FILE *f = fopen(p, "r");
    if (!f) return false;
    v[0] = v[1] = v[2] = 0;
    int k = fscanf(f, "%d.%d.%d", &v[0], &v[1], &v[2]);
    fclose(f);
    return k >= 1;
}
static int mc_ver_cmp(const int *a, const int *b) {
    for (int i = 0; i < 3; i++)
        if (a[i] != b[i]) return a[i] < b[i] ? -1 : 1;
    return 0;
}

// ---------------------------------------------------------------------------------------------
// 5) Copia (escritura directa con stdio; punto unico a cambiar si hiciera falta otro metodo)
// ---------------------------------------------------------------------------------------------
static const char *mc_sub(int kind) { return kind == PK_RES ? "resource_packs" : "behavior_packs"; }

// Copia TAL CUAL (misma extension .mcpack) a dir/fname, via dir/fname.part y rename.
static bool mc_copy_file(const char *src, const char *dir, const char *fname, char *err, size_t ecap) {
    char dst[460], part[470];
    snprintf(dst, sizeof(dst), "%s/%s", dir, fname);
    snprintf(part, sizeof(part), "%s.part", dst);
    FILE *in = fopen(src, "rb");
    if (!in) { snprintf(err, ecap, "no se pudo abrir %s", src); return false; }
    FILE *out = fopen(part, "wb");
    if (!out) {
        snprintf(err, ecap, "no se pudo escribir en %s (errno %d)", dir, errno);
        fclose(in);
        return false;
    }
    char *buf = (char *)malloc(64 * 1024);
    bool ok = buf != NULL;
    if (!ok) snprintf(err, ecap, "sin memoria");
    while (ok) {
        size_t n = fread(buf, 1, 64 * 1024, in);
        if (n == 0) break;
        if (fwrite(buf, 1, n, out) != n) { snprintf(err, ecap, "error al escribir en %s (errno %d)", dir, errno); ok = false; }
    }
    free(buf);
    fclose(in);
    if (fclose(out) != 0 && ok) { snprintf(err, ecap, "error al cerrar el archivo en %s (errno %d)", dir, errno); ok = false; }
    if (ok && mc_file_size(part) != mc_file_size(src)) { snprintf(err, ecap, "la copia quedo incompleta"); ok = false; }
    if (ok) {
        remove(dst);  // el reemplazo ya fue confirmado por el usuario
        if (rename(part, dst) != 0) { snprintf(err, ecap, "no se pudo renombrar a %s (errno %d)", fname, errno); ok = false; }
    }
    if (!ok) remove(part);
    return ok;
}

// Ya existe el pack en alguna de las carpetas de destino?
static bool mc_already_there(const McTargets *t, int kind, const char *fname) {
    char p[500];
    for (int i = 0; i < t->n; i++) {
        snprintf(p, sizeof(p), "%s/%s/%s", t->path[i], mc_sub(kind), fname);
        if (mc_exists(p)) return true;
    }
    return false;
}

struct McInstallResult {
    int ok, fail;
    char err[220];
};

// Instala el .mcpack en todas las carpetas detectadas.
static void mc_install(const char *src, const char *fname, int kind, const McTargets *t, McInstallResult *r) {
    r->ok = r->fail = 0;
    r->err[0] = 0;
    for (int i = 0; i < t->n; i++) {
        char dir[400], err[200] = "";
        snprintf(dir, sizeof(dir), "%s/%s", t->path[i], mc_sub(kind));
        if (!mc_is_dir(dir)) {
            snprintf(err, sizeof(err), "no existe la carpeta %s", dir);
        } else if (mc_copy_file(src, dir, fname, err, sizeof(err))) {
            r->ok++;
            continue;
        }
        r->fail++;
        if (!r->err[0]) snprintf(r->err, sizeof(r->err), "%s", err);
    }
}
