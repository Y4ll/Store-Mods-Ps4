// Fondos animados: llamas, vaporwave y paisaje de bloques (pixel art). Se incluye desde main.cpp antes de build_bg().
// anim_draw() pinta un cuadro completo sobre FB; con "Fondo animado: No" se usa un cuadro quieto (anim_still).
#pragma once

#define FIRE_W 160
#define FIRE_H 90
#define FIRE_CELL 12
struct FireState { uint8_t h[FIRE_H][FIRE_W]; uint64_t last; unsigned rs; };
static FireState g_fire;

static unsigned an_rnd(unsigned *s) { unsigned x = *s; x ^= x << 13; x ^= x >> 17; x ^= x << 5; *s = x; return x; }

static uint32_t fire_color(int heat) {  // 1..255 -> negro/rojo/naranja/amarillo/blanco
    int r = heat * 3 > 255 ? 255 : heat * 3;
    int g = heat < 85 ? 0 : (heat - 85) * 3 > 255 ? 255 : (heat - 85) * 3;
    int b = heat < 190 ? 0 : (heat - 190) * 4 > 255 ? 255 : (heat - 190) * 4;
    return RGB(r, g, b);
}

static void fire_step(FireState &f) {
    for (int x = 0; x < FIRE_W; x++) {
        unsigned r = an_rnd(&f.rs);
        f.h[FIRE_H - 1][x] = (r % 7 == 0) ? 120 : (uint8_t)(200 + r % 56);
    }
    for (int y = 0; y < FIRE_H - 1; y++)
        for (int x = 0; x < FIRE_W; x++) {
            unsigned r = an_rnd(&f.rs);
            int dx = (int)((r >> 8) % 3) - 1;                     // el viento mueve la llama a los lados
            int below = f.h[y + 1][x], side = f.h[y + 1][(x + dx + FIRE_W) % FIRE_W];
            int v = (below * 2 + side) / 3 - (int)((r >> 16) % 6) - 1;  // pierde calor al subir
            f.h[y][x] = (uint8_t)(v < 0 ? 0 : v);
        }
}

static void draw_fire(uint64_t now, bool still) {
    FireState &f = g_fire;
    if (still || f.last == 0) {  // arranque: calienta el fuego para que ya haya llamas
        memset(&f, 0, sizeof(f));
        f.rs = 7;
        for (int i = 0; i < 90; i++) fire_step(f);
        f.last = now ? now : 1;
    }
    while (!still && now - f.last >= 33) { fire_step(f); f.last += 33; if (now - f.last > 500) f.last = now; }
    fill_vgrad(0, 0, SCREEN_W, SCREEN_H, C_BG, mix(C_BG2, RGB(90, 20, 0), 40));
    for (int y = 0; y < FIRE_H; y++)
        for (int x = 0; x < FIRE_W; x++) {
            int hv = f.h[y][x];
            if (hv < 12) continue;
            uint32_t c = fire_color(hv);
            if (hv < 60) c = mix(C_BG2, c, hv * 100 / 60);
            fill(x * FIRE_CELL, y * FIRE_CELL, FIRE_CELL, FIRE_CELL, c);
        }
}

// ---------- vaporwave: sol a rayas, rejilla en perspectiva que avanza ----------
static void draw_vapor(uint64_t now, bool still) {
    int hz = 640;
    uint32_t top = C_BG, mid = RGB(150, 30, 150), hor = RGB(255, 120, 130);
    fill_vgrad(0, 0, SCREEN_W, 440, top, mid);
    fill_vgrad(0, 440, SCREEN_W, hz - 440, mid, hor);
    for (int i = 0; i < 40; i++) {  // estrellas fijas
        unsigned h = (unsigned)i * 2654435761u;
        fill((int)((h >> 3) % SCREEN_W), (int)((h >> 14) % 330), 4, 4, mix(mid, RGB(255, 255, 255), 60));
    }
    // sol: discos por filas, con rayas que bajan despacio
    int cx = SCREEN_W / 2, cy = 430, r = 250;
    int off = still ? 0 : (int)((now / 60) % 40);
    for (int y = cy - r; y < hz; y++) {
        int dy = y - cy;
        int w = isqrt_i(r * r - dy * dy);
        if (dy > 20) {  // rayas cada vez mas gruesas hacia abajo
            int rel = y - cy - 20 + off;
            int period = 40, thick = 4 + (dy - 20) / 14;
            if (rel % period < thick) continue;
        }
        fill(cx - w, y, 2 * w, 1, mix(RGB(255, 220, 90), RGB(255, 60, 170), (y - (cy - r)) * 100 / (2 * r)));
    }
    // suelo
    fill_vgrad(0, hz, SCREEN_W, SCREEN_H - hz, RGB(30, 6, 60), RGB(70, 12, 110));
    uint32_t gl = RGB(255, 80, 220), gl2 = mix(RGB(70, 12, 110), gl, 55);
    fill(0, hz, SCREEN_W, 4, gl);
    for (int j = -17; j <= 16; j++) {  // lineas que salen del punto de fuga (sin linea central: era una barra vertical rara)
        for (int y = hz + 4; y < SCREEN_H; y += 6) {
            int x = cx + (2 * j + 1) * 75 * (y - hz) / (SCREEN_H - hz);
            fill(x - 1, y, 3, 6, gl2);
        }
    }
    int fr = still ? 0 : (int)((now / 25) % 100);  // 0..99
    for (int i = 0; i < 9; i++) {  // lineas horizontales: se acercan
        long z = (i * 100 + fr);                    // 0..900
        int y = hz + (int)(z * z * (SCREEN_H - hz) / (900L * 900L)) + 4;
        if (y < SCREEN_H) fill(0, y, SCREEN_W, 2 + (int)(z / 300), gl);
    }
}

// ---------- paisaje de bloques ----------
static unsigned hash2(int a, int b) {
    unsigned h = (unsigned)a * 374761393u + (unsigned)b * 668265263u;
    h = (h ^ (h >> 13)) * 1274126177u;
    return h ^ (h >> 16);
}
#define BLK 48
static int col_height(int wx) {  // altura del terreno (en bloques) de la columna wx del mundo
    int a = (int)(hash2(wx / 6, 1) % 4), b = (int)(hash2(wx / 6 + 1, 1) % 4), t = wx % 6;
    return 4 + (a * (6 - t) + b * t) / 6;
}
static void block(int x, int y, uint32_t base, uint32_t dark, int wx, int wy) {
    fill(x, y, BLK, BLK, base);
    for (int k = 0; k < 6; k++) {
        unsigned h = hash2(wx * 7 + k, wy * 13 + k * 5);
        fill(x + (int)(h % 8) * 6, y + (int)((h >> 8) % 8) * 6, 6 + (int)(h % 2) * 6, 6, dark);
    }
}
static void draw_blocks(uint64_t now, bool still) {
    int scroll = still ? 0 : (int)(now / 30);  // px que se ha movido el mundo
    fill_vgrad(0, 0, SCREEN_W, SCREEN_H, RGB(30, 60, 140), RGB(150, 200, 240));
    // sol cuadrado
    fill(1500, 110, 120, 120, RGB(255, 236, 140));
    fill(1516, 126, 88, 88, RGB(255, 250, 200));
    // nubes de bloques que pasan mas rapido que el suelo
    int cs = still ? 0 : (int)(now / 14);
    for (int i = 0; i < 7; i++) {
        int w = 3 + (int)(hash2(i, 9) % 3), y = 80 + (int)(hash2(i, 4) % 6) * 56;
        int x = (int)(((long)i * 330 + cs) % (SCREEN_W + 400)) - 300;
        for (int k = 0; k < w; k++) {
            fill(x + k * BLK, y, BLK, BLK, RGB(176, 200, 236));
            if (k > 0 && k < w - 1) fill(x + k * BLK, y - BLK / 2, BLK, BLK / 2, RGB(170, 195, 232));
        }
    }
    int base = scroll / BLK, sub = scroll % BLK;
    int groundY = SCREEN_H;  // fila 0 = ultima fila de abajo
    for (int c = 0; c < SCREEN_W / BLK + 2; c++) {
        int wx = base + c, h = col_height(wx), x = c * BLK - sub;
        for (int r = 0; r < h; r++) {
            int y = groundY - (r + 1) * BLK, depth = h - 1 - r;  // depth 0 = superficie
            if (depth == 0) block(x, y, RGB(98, 170, 56), RGB(70, 130, 40), wx, r);
            else if (depth < 3) block(x, y, RGB(134, 96, 67), RGB(104, 74, 52), wx, r);
            else {
                block(x, y, RGB(128, 128, 128), RGB(104, 104, 104), wx, r);
                unsigned o = hash2(wx, r + 50);
                if (o % 13 == 0) fill(x + 12, y + 12, 12, 12, RGB(30, 30, 30));          // carbon
                else if (o % 29 == 1) fill(x + 18, y + 6, 12, 12, RGB(216, 175, 147));    // hierro
                else if (o % 71 == 2) fill(x + 12, y + 24, 14, 14, RGB(90, 235, 235));   // diamante
            }
        }
        if (hash2(wx / 5, 3) % 3 == 0 && wx % 5 == 2) {  // arbol: tronco y copa
            int ty = groundY - h * BLK;
            for (int k = 1; k <= 3; k++) block(x, ty - k * BLK, RGB(110, 80, 46), RGB(84, 60, 34), wx, 100 + k);
            for (int dx = -1; dx <= 1; dx++)
                for (int dy = 0; dy < 2; dy++) block(x + dx * BLK, ty - (4 + dy) * BLK, RGB(60, 130, 40), RGB(40, 100, 28), wx + dx, 200 + dy);
            block(x, ty - 6 * BLK, RGB(60, 130, 40), RGB(40, 100, 28), wx, 210);
        }
    }
}

static void anim_draw(int pat, uint64_t now, bool still) {
    if (pat == 5) draw_fire(now, still);
    else if (pat == 6) draw_vapor(now, still);
    else draw_blocks(now, still);
}
