// Novedades del catalogo y lo ya descargado (modo PC)
// (Movido tal cual desde main.cpp; se incluye en el mismo punto, asi que el orden no cambia.)
#pragma once

// ---------- novedades del catalogo (nuevo / actualizado) ----------
// Se compara con el catalogo anterior (en memoria) o, al abrir la app, con la lista guardada de la ultima vez.
struct Seen { char key[96]; long size; };
static Seen g_seen[MAX_ITEMS];
static int g_seenN = 0;
static bool g_seenHave = false;

static const char *item_key(const Item &it) { return it.file[0] ? it.file : it.name; }

static void seen_path(char *out, size_t cap) { snprintf(out, cap, "%s/catalog_seen.txt", plat_data_dir()); }

static void seen_load() {
    g_seenN = 0;
    g_seenHave = false;
    char p[300];
    seen_path(p, sizeof(p));
    FILE *f = fopen(p, "r");
    if (!f) return;
    g_seenHave = true;
    char line[200];
    while (g_seenN < MAX_ITEMS && fgets(line, sizeof(line), f)) {
        char *bar = strrchr(line, '|');
        if (!bar) continue;
        *bar = 0;
        snprintf(g_seen[g_seenN].key, sizeof(g_seen[g_seenN].key), "%s", line);
        g_seen[g_seenN].size = atol(bar + 1);
        g_seenN++;
    }
    fclose(f);
}

static void seen_save(const Item *c, int n) {
    char p[300];
    seen_path(p, sizeof(p));
    FILE *f = fopen(p, "w");
    if (!f) return;
    for (int i = 0; i < n; i++) fprintf(f, "%s|%ld\n", item_key(c[i]), c[i].size);
    fclose(f);
}

// Marca cada item de `fresh` como nuevo/actualizado y devuelve cuantos hay de cada uno.
static void mark_changes(Item *fresh, int n, const Item *old, int oldN, int *nNew, int *nUpd) {
    *nNew = *nUpd = 0;
    bool haveBase = oldN > 0 || g_seenHave;
    for (int i = 0; i < n; i++) {
        Item &it = fresh[i];
        it.flag = 0;
        if (!haveBase) continue;  // primera vez: no marcar todo como nuevo
        const char *k = item_key(it);
        bool found = false;
        long oldSize = 0;
        unsigned char oldFlag = 0;
        if (oldN > 0) {
            for (int j = 0; j < oldN; j++)
                if (!strcmp(item_key(old[j]), k)) { found = true; oldSize = old[j].size; oldFlag = old[j].flag; break; }
        } else {
            for (int j = 0; j < g_seenN; j++)
                if (!strcmp(g_seen[j].key, k)) { found = true; oldSize = g_seen[j].size; break; }
        }
        if (!found) it.flag = 1;
        else if (it.size > 0 && oldSize > 0 && it.size != oldSize) it.flag = 2;
        else it.flag = oldFlag;  // conserva la marca de antes dentro de la misma sesion
        if (it.flag == 1) (*nNew)++;
        else if (it.flag == 2) (*nUpd)++;
    }
    // Si "aparecen" de golpe muchisimos, es que cambiaron todo el catalogo (no que salieron
    // 100+ add-ons): no los marcamos como [NUEVO] para que L2 no intente bajarlos todos.
    if (*nNew > 100) {
        for (int i = 0; i < n; i++) if (fresh[i].flag == 1) fresh[i].flag = 0;
        *nNew = 0;
    }
}

// ---------- lo ya descargado (modo PC): sirve para marcar [DESCARGADO] / [HAY UPDATE] ----------
struct Got { char id[24]; char upd[12]; long size; };
#define MAX_GOT 400
static Got g_got[MAX_GOT];
static int g_gotN = 0;

static void got_path(char *out, size_t cap) { snprintf(out, cap, "%s/got.txt", plat_data_dir()); }

static void got_load() {
    g_gotN = 0;
    char p[300];
    got_path(p, sizeof(p));
    FILE *f = fopen(p, "r");
    if (!f) return;
    char line[120];
    while (g_gotN < MAX_GOT && fgets(line, sizeof(line), f)) {
        char *b1 = strchr(line, '|');
        char *b2 = b1 ? strchr(b1 + 1, '|') : NULL;
        if (!b2) continue;
        *b1 = 0; *b2 = 0;
        Got &g = g_got[g_gotN++];
        snprintf(g.id, sizeof(g.id), "%s", line);
        snprintf(g.upd, sizeof(g.upd), "%s", b1 + 1);
        g.size = atol(b2 + 1);
    }
    fclose(f);
}

static void got_set(const Item &it) {
    int k = -1;
    for (int i = 0; i < g_gotN; i++) if (!strcmp(g_got[i].id, it.id)) { k = i; break; }
    if (k < 0) k = g_gotN < MAX_GOT ? g_gotN++ : MAX_GOT - 1;
    snprintf(g_got[k].id, sizeof(g_got[k].id), "%s", it.id);
    snprintf(g_got[k].upd, sizeof(g_got[k].upd), "%s", it.upd);
    g_got[k].size = it.size;
    char p[300];
    got_path(p, sizeof(p));
    FILE *f = fopen(p, "w");
    if (!f) return;
    for (int i = 0; i < g_gotN; i++) fprintf(f, "%s|%s|%ld\n", g_got[i].id, g_got[i].upd, g_got[i].size);
    fclose(f);
}

// 0 = nunca bajado, 3 = bajado y al dia, 2 = bajado pero el servidor tiene otra version (fecha o tamano distintos)
static void mark_got(Item *arr, int n) {
    for (int i = 0; i < n; i++) {
        arr[i].flag = 0;
        for (int j = 0; j < g_gotN; j++) {
            if (strcmp(g_got[j].id, arr[i].id)) continue;
            bool changed = (arr[i].upd[0] && strcmp(arr[i].upd, g_got[j].upd)) || (arr[i].size > 0 && g_got[j].size > 0 && arr[i].size != g_got[j].size);
            arr[i].flag = changed ? 2 : 3;
            break;
        }
    }
}
