// Entrada: que hace cada boton en cada pantalla
// (Movido tal cual desde main.cpp; se incluye en el mismo punto, asi que el orden no cambia.)
#pragma once

// ---------- entrada ----------

static uint32_t g_prev = 0;
static int g_hold[16];

// Devuelve los botones recien pulsados, con repeticion para direcciones y L1/R1.
static uint32_t poll_input() {
    uint32_t cur = plat_buttons();
    uint32_t pressed = cur & ~g_prev;
    const uint32_t repeatable = BTN_UP | BTN_DOWN | BTN_LEFT | BTN_RIGHT | BTN_L1 | BTN_R1;
    // Botones que se pulsan sin querer al mover los sticks o que hacen algo grande (L2: bajar todo, L3: buscar
    // version nueva, R3: favorito): solo cuentan si se mantienen ~0.15 s.
    const uint32_t slow = BTN_L2 | BTN_L3 | BTN_R3;
    pressed &= ~slow;
    for (int i = 0; i < 16; i++) {
        uint32_t bit = 1u << i;
        if (!(cur & bit)) { g_hold[i] = 0; continue; }
        g_hold[i]++;
        if ((repeatable & bit) && g_hold[i] > 20 && (g_hold[i] - 20) % 4 == 0) pressed |= bit;
        if ((slow & bit) && g_hold[i] == 9) pressed |= bit;
    }
    g_prev = cur;
    if (pressed & (BTN_UP | BTN_DOWN | BTN_LEFT | BTN_RIGHT | BTN_L1 | BTN_R1)) sfx(SFX_MOVE);
    else if (pressed & BTN_CROSS) sfx(SFX_SELECT);
    else if (pressed & BTN_CIRCLE) sfx(SFX_BACK);
    return pressed;
}

static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

static void scroll_to_sel() {
    int r = A.sel / GRID_COLS;
    if (r < A.top) A.top = r;
    if (r >= A.top + GRID_ROWS) A.top = r - GRID_ROWS + 1;
}

static void goto_page(int pg) {
    if (pg < 1 || pg > A.pages || g_job) return;
    A.page = pg;
    start_search(true);
}

static void input_list(uint32_t p) {
    int last = A.n ? A.n - 1 : 0;
    if (p & BTN_RIGHT) { A.sel = clampi(A.sel + 1, 0, last); scroll_to_sel(); }
    if (p & BTN_LEFT) { A.sel = clampi(A.sel - 1, 0, last); scroll_to_sel(); }
    if (p & BTN_DOWN) { A.sel = clampi(A.sel + GRID_COLS, 0, last); scroll_to_sel(); }
    if (p & BTN_UP) { A.sel = clampi(A.sel - GRID_COLS, 0, last); scroll_to_sel(); }
    if (A.mode == M_LAN) {  // L1/R1 cambian de pagina (el servidor devuelve 24 por pagina)
        if (p & BTN_R1) goto_page(A.page + 1);
        if (p & BTN_L1) goto_page(A.page - 1);
    } else {
        if (p & BTN_R1) { A.sel = clampi(A.sel + GRID_COLS * GRID_ROWS, 0, last); scroll_to_sel(); }
        if (p & BTN_L1) { A.sel = clampi(A.sel - GRID_COLS * GRID_ROWS, 0, last); scroll_to_sel(); }
    }
    if (p & BTN_CROSS) open_detail();
    if ((p & BTN_CIRCLE) && A.mode == M_LAN && !g_job) {  // cambia el orden
        A.sort = (A.sort + 1) % 5;
        A.page = 1;
        start_search(true);
    }
    if ((p & BTN_CIRCLE) && A.mode == M_GITHUB) { g_fRow = 0; A.scr = S_FILTER; }  // filtros y tema
    if ((p & BTN_R3) && A.n > 0) {
        bool on = fav_toggle(A.items[A.sel]);
        set_status(C_OK, on ? "Agregado a favoritos: %.50s" : "Quitado de favoritos: %.50s", A.items[A.sel].name);
    }
    if (p & BTN_TOUCH) { g_helpBack = S_LIST; g_helpTop = 0; g_helpFirst = false; A.scr = S_HELP; }
    if (p & BTN_L2) start_bulk();
    if (p & BTN_L3) check_app_update();
    if (p & BTN_OPTIONS) start_search(true);
    if (p & BTN_R2) {
        I.modal = MD_NONE;
        install_rescan();
        I.top = 0;
        set_status(C_DIM, "Elige un pack y pulsa X (Minecraft abierto).");
        A.scr = S_INSTALL;
    }
    if (p & BTN_SQUARE) {
        snprintf(A.kbuf, sizeof(A.kbuf), "%s", A.query);
        A.kr = A.kc = 0;
        A.kcat = A.catSel;
        A.scr = S_KEYBOARD;
    }
    if (p & BTN_TRIANGLE) {
        A.edit = A.srv;
        A.editMode = A.mode;
        A.field = 0;
        A.scr = S_SETTINGS;
    }
}

static void input_detail(uint32_t p) {
    if (p & BTN_DOWN) g_dTop = clampi(g_dTop + 1, 0, g_dN > 17 ? g_dN - 17 : 0);
    if (p & BTN_UP) g_dTop = clampi(g_dTop - 1, 0, g_dN > 17 ? g_dN - 17 : 0);
    if (p & BTN_R1) g_dTop = clampi(g_dTop + 12, 0, g_dN > 17 ? g_dN - 17 : 0);
    if (p & BTN_L1) g_dTop = clampi(g_dTop - 12, 0, g_dN > 17 ? g_dN - 17 : 0);
    if ((p & BTN_CROSS) && !g_job) start_download();
    if ((p & BTN_TRIANGLE) && !g_job) {
        g_autoInst = true;
        start_download();
        if (!g_job) g_autoInst = false;
    }
    if (p & BTN_SQUARE) {
        bool on = fav_toggle(g_det);
        set_status(C_OK, on ? "Agregado a favoritos." : "Quitado de favoritos.");
    }
    if (p & BTN_R2) {
        if (g_job) job_cancel();
        I.modal = MD_NONE;
        install_rescan();
        I.top = 0;
        set_status(C_DIM, "Elige un pack y pulsa X (Minecraft abierto).");
        A.scr = S_INSTALL;
    }
    if (p & BTN_CIRCLE) {
        if (g_job) job_cancel();
        A.scr = S_LIST;
    }
}

static void delete_downloads(bool all) {
    char dir[300], f[460];
    snprintf(dir, sizeof(dir), "%s/downloads", plat_data_dir());
    int n = 0;
    if (all) {
        for (int i = 0; i < I.n; i++) {
            snprintf(f, sizeof(f), "%s/%s", dir, I.rows[i].file);
            if (remove(f) == 0) n++;
        }
    } else if (I.n > 0) {
        snprintf(f, sizeof(f), "%s/%s", dir, I.rows[I.sel].file);
        if (remove(f) == 0) n++;
    }
    install_rescan();
    refresh_have();
    if (n == 1) set_status(C_OK, "Borrado.");
    else if (n > 1) set_status(C_OK, "Borrados %d archivos.", n);
    else set_status(C_ERR, "No se pudo borrar.");
}

static void input_install(uint32_t p) {
    if (I.modal != MD_NONE) {
        if (I.modal == MD_DELETE || I.modal == MD_DELALL) {
            if (p & BTN_CROSS) { bool all = I.modal == MD_DELALL; I.modal = MD_NONE; delete_downloads(all); }
            else if (p & BTN_CIRCLE) { I.modal = MD_NONE; set_status(C_DIM, "Cancelado."); }
        } else if (I.modal == MD_VERSION) {
            if (p & BTN_CROSS) { I.modal = MD_NONE; install_begin(true, false); }
            else if (p & BTN_CIRCLE) { I.modal = MD_NONE; set_status(C_DIM, "Cancelado."); }
        } else if (I.modal == MD_REPLACE) {
            if (p & BTN_CROSS) { I.modal = MD_NONE; install_begin(true, true); }
            else if (p & BTN_CIRCLE) { I.modal = MD_NONE; set_status(C_DIM, "Cancelado."); }
        } else if (I.modal == MD_DONE && (p & BTN_TRIANGLE)) {
            I.modal = MD_NONE;
            char cusa[16] = "";
            const char *t = strstr(I.tg.path[0], "CUSA");
            if (t) { snprintf(cusa, sizeof(cusa), "%.9s", t); }
            if (!cusa[0] || plat_resume_game(cusa) != 0) set_status(C_ERR, "No pude volver a Minecraft: usa el menu de la consola.");
        } else if (p & (BTN_CROSS | BTN_CIRCLE)) {
            I.modal = MD_NONE;
        }
        return;
    }
    if (p & BTN_DOWN) { I.sel = clampi(I.sel + 1, 0, I.n ? I.n - 1 : 0); }
    if (p & BTN_UP) { I.sel = clampi(I.sel - 1, 0, I.n ? I.n - 1 : 0); }
    if (p & BTN_R1) { I.sel = clampi(I.sel + LIST_ROWS, 0, I.n ? I.n - 1 : 0); }
    if (p & BTN_L1) { I.sel = clampi(I.sel - LIST_ROWS, 0, I.n ? I.n - 1 : 0); }
    if (I.sel < I.top) I.top = I.sel;
    if (I.sel >= I.top + LIST_ROWS) I.top = I.sel - LIST_ROWS + 1;
    if (p & BTN_OPTIONS) { install_rescan(); set_status(C_DIM, "Lista actualizada."); }
    if (p & BTN_L2) install_all();
    if ((p & BTN_SQUARE) && I.n > 0) modal_open(MD_DELETE, 2, I.rows[I.sel].file, "Se borra de las descargas de McStore (no toca lo ya instalado en Minecraft).");
    if ((p & BTN_TRIANGLE) && I.n > 0) {
        char m[80];
        snprintf(m, sizeof(m), "Se van a borrar los %d archivos de la lista.", I.n);
        modal_open(MD_DELALL, 2, m, "No se puede deshacer. Podras volver a bajarlos desde el catalogo.");
    }
    if (p & BTN_CROSS) install_begin(false, false);
    if (p & BTN_CIRCLE) A.scr = S_LIST;
}

static void input_filter(uint32_t p) {
    if (p & BTN_DOWN) g_fRow = clampi(g_fRow + 1, 0, 4);
    if (p & BTN_UP) g_fRow = clampi(g_fRow - 1, 0, 4);
    int d = ((p & BTN_RIGHT) ? 1 : 0) - ((p & BTN_LEFT) ? 1 : 0);
    if (d) {
        if (g_fRow == 0) g_fType = (g_fType + 4 + d) % 4;
        else if (g_fRow == 1) {
            int idx = -1;  // -1 = todas
            for (int i = 0; i < g_verN; i++) if (!strcmp(g_verList[i], g_fVer)) idx = i;
            if (g_verN > 0) {
                idx += d;
                if (idx < -1) idx = g_verN - 1;
                if (idx >= g_verN) idx = -1;
            }
            snprintf(g_fVer, sizeof(g_fVer), "%s", idx < 0 ? "" : g_verList[idx]);
        } else if (g_fRow == 2) g_fSort = (g_fSort + 5 + d) % 5;
        else if (g_fRow == 3) g_fSet = (g_fSet + 5 + d) % 5;
        else apply_theme((g_theme + NTHEMES + d) % NTHEMES);
    }
    if (p & BTN_TRIANGLE) { g_fType = 0; g_fVer[0] = 0; g_fSort = 0; g_fSet = 0; }
    if (p & (BTN_CROSS | BTN_CIRCLE)) {
        ui_save();
        filter_catalog();
        A.scr = S_LIST;
    }
}

static void input_keyboard(uint32_t p) {
    if (p & BTN_RIGHT) A.kc = (A.kc + 1) % 10;
    if (p & BTN_LEFT) A.kc = (A.kc + 9) % 10;
    if (p & BTN_DOWN) A.kr = (A.kr + 1) % 4;
    if (p & BTN_UP) A.kr = (A.kr + 3) % 4;
    size_t l = strlen(A.kbuf);
    if ((p & BTN_CROSS) && l + 1 < sizeof(A.kbuf)) { A.kbuf[l] = KB_ROWS[A.kr][A.kc]; A.kbuf[l + 1] = 0; }
    if ((p & BTN_TRIANGLE) && l + 1 < sizeof(A.kbuf)) { A.kbuf[l] = ' '; A.kbuf[l + 1] = 0; }
    if ((p & BTN_SQUARE) && l > 0) A.kbuf[l - 1] = 0;
    if (g_catN > 1 && A.mode == M_LAN) {
        if (p & BTN_R1) A.kcat = (A.kcat + 1) % g_catN;
        if (p & BTN_L1) A.kcat = (A.kcat + g_catN - 1) % g_catN;
    }
    if (p & BTN_CIRCLE) A.scr = S_LIST;
    if (p & BTN_OPTIONS) {
        A.catSel = A.kcat;
        snprintf(A.query, sizeof(A.query), "%s", A.kbuf);
        A.scr = S_LIST;
        A.page = 1;
        start_search();
    }
}

static void input_settings(uint32_t p) {
    if (p & BTN_RIGHT) A.field = clampi(A.field + 1, 0, 5);
    if (p & BTN_LEFT) A.field = clampi(A.field - 1, 0, 5);
    if (A.field == 0) {
        if (p & (BTN_UP | BTN_DOWN | BTN_L1 | BTN_R1)) A.editMode = (A.editMode == M_GITHUB) ? M_LAN : M_GITHUB;
    } else {
        int idx = A.field - 1;  // 0..3 = octetos, 4 = puerto
        int step = 0;
        if (p & BTN_UP) step += 1;
        if (p & BTN_DOWN) step -= 1;
        if (p & BTN_R1) step += (idx == 4 ? 100 : 10);
        if (p & BTN_L1) step -= (idx == 4 ? 100 : 10);
        if (step) {
            if (idx < 4) A.edit.ip[idx] = clampi(A.edit.ip[idx] + step, 0, 255);
            else A.edit.port = clampi(A.edit.port + step, 1, 65535);
        }
    }
    if (p & BTN_SQUARE) { g_prefRow = 0; A.scr = S_PREFS; }
    if (p & BTN_TRIANGLE) { g_helpBack = S_SETTINGS; g_helpTop = 0; g_helpFirst = false; A.scr = S_HELP; }
    if (p & BTN_CIRCLE) A.scr = S_LIST;
    if (p & BTN_CROSS) {
        A.srv = A.edit;
        A.mode = A.editMode;
        config_save();
        A.scr = S_LIST;
        A.catLoaded = false;
        A.n = 0;
        A.page = 1;
        A.catSel = 0;
        g_catsTried = false;
        g_catN = 0;
        start_search(true);
    }
}
