// Temas de color y fondo con imagen propia (PNG/JPG). Se incluye desde main.cpp.
// Las imagenes se ponen en /data/mcstore/fondos/ (por FTP desde el iPhone) y se eligen en Apariencia.
#pragma once
#include <mutex>
#include <string.h>

struct Theme {
    const char *name;
    uint8_t bg[3], panel[3], sel[3], text[3], dim[3], accent[3], ok[3], err[3];
    bool light;
};

static const Theme THEMES[] = {
    {"Verde", {18, 22, 20}, {30, 38, 34}, {44, 84, 56}, {235, 240, 235}, {150, 165, 155}, {96, 200, 96}, {110, 220, 120}, {240, 100, 90}, false},
    {"Negro", {0, 0, 0}, {18, 18, 18}, {58, 58, 58}, {245, 245, 245}, {150, 150, 150}, {235, 235, 235}, {120, 225, 135}, {245, 100, 90}, false},
    {"Blanco", {243, 245, 243}, {221, 226, 222}, {178, 214, 186}, {24, 30, 26}, {96, 106, 100}, {28, 125, 48}, {16, 125, 46}, {196, 46, 36}, true},
    {"Azul", {10, 16, 30}, {20, 30, 52}, {36, 72, 134}, {236, 241, 250}, {140, 155, 182}, {82, 164, 255}, {100, 220, 150}, {250, 110, 100}, false},
    {"Morado", {19, 13, 29}, {34, 24, 52}, {88, 54, 136}, {242, 236, 250}, {160, 146, 182}, {192, 124, 255}, {120, 220, 150}, {250, 110, 110}, false},
    {"Rojo", {24, 11, 11}, {42, 22, 22}, {134, 40, 40}, {250, 238, 236}, {178, 150, 148}, {255, 104, 92}, {120, 220, 130}, {255, 170, 90}, false},
    {"Ambar", {24, 17, 9}, {44, 33, 19}, {132, 84, 28}, {250, 242, 230}, {182, 164, 140}, {255, 176, 56}, {130, 220, 120}, {250, 100, 90}, false},
    {"Cian", {9, 24, 26}, {17, 42, 46}, {22, 102, 112}, {232, 248, 250}, {138, 170, 176}, {70, 222, 234}, {110, 226, 140}, {250, 110, 100}, false},
};
#define N_THEMES ((int)(sizeof(THEMES) / sizeof(THEMES[0])))

static uint32_t C_BG, C_PANEL, C_SEL, C_TEXT, C_DIM, C_ACCENT, C_OK, C_ERR, C_BAR;

static int g_theme = 0;      // indice en THEMES
static int g_dim = 5;        // 0..9 -> oscurecer (o aclarar, en tema claro) el fondo de 0% a 90%
static bool g_light = false;

static void mkdir_p(const char *dir);

static void theme_apply() {
    if (g_theme < 0 || g_theme >= N_THEMES) g_theme = 0;
    const Theme &t = THEMES[g_theme];
    C_BG = RGB(t.bg[0], t.bg[1], t.bg[2]);
    C_PANEL = RGB(t.panel[0], t.panel[1], t.panel[2]);
    C_SEL = RGB(t.sel[0], t.sel[1], t.sel[2]);
    C_TEXT = RGB(t.text[0], t.text[1], t.text[2]);
    C_DIM = RGB(t.dim[0], t.dim[1], t.dim[2]);
    C_ACCENT = RGB(t.accent[0], t.accent[1], t.accent[2]);
    C_OK = RGB(t.ok[0], t.ok[1], t.ok[2]);
    C_ERR = RGB(t.err[0], t.err[1], t.err[2]);
    C_BAR = RGB(60, 70, 64);
    g_light = t.light;
}

// ---------- fondo con imagen ----------

#define BG_MAXFILES 32
struct BgList {
    int n;
    char name[BG_MAXFILES][96];
};
static BgList g_bgList;
static int g_bgIdx = -1;               // -1 = sin imagen
static char g_bgName[96] = "";         // archivo elegido
static bool g_bgOn = false;            // hay imagen lista para dibujar
static uint32_t *g_bgRaw = NULL;       // imagen escalada a 1920x1080, sin oscurecer
static uint32_t *g_bgShow = NULL;      // la misma, ya oscurecida (lo que se copia a pantalla)
static std::atomic<int> g_bgSeq(0);
static std::atomic<int> g_bgState(0);  // 0 = nada, 1 = cargando, 2 = lista (pendiente de recoger), 3 = fallo
static uint32_t *g_bgPending = NULL;
static char g_bgErr[120] = "";
static std::mutex g_bgMu;

static void bg_dir(char *out, size_t cap) { snprintf(out, cap, "%s/fondos", plat_data_dir()); }

static int ci_cmp(const char *a, const char *b) {
    for (;; a++, b++) {
        int x = (unsigned char)*a, y = (unsigned char)*b;
        if (x >= 'A' && x <= 'Z') x += 32;
        if (y >= 'A' && y <= 'Z') y += 32;
        if (x != y) return x - y;
        if (!x) return 0;
    }
}

static bool bg_is_image(const char *n) {
    size_t l = strlen(n);
    if (l < 5 || n[0] == '.') return false;
    const char *e = n + l - 4;
    if (!ci_cmp(e, ".png") || !ci_cmp(e, ".jpg")) return true;
    return l >= 6 && !ci_cmp(n + l - 5, ".jpeg");
}

static void bg_scan_cb(const char *name, void *) {
    if (g_bgList.n >= BG_MAXFILES || !bg_is_image(name)) return;
    int i = g_bgList.n++;
    snprintf(g_bgList.name[i], sizeof(g_bgList.name[i]), "%s", name);
    while (i > 0 && ci_cmp(g_bgList.name[i - 1], g_bgList.name[i]) > 0) {  // ordenado
        char t[96];
        memcpy(t, g_bgList.name[i - 1], sizeof(t));
        memcpy(g_bgList.name[i - 1], g_bgList.name[i], sizeof(t));
        memcpy(g_bgList.name[i], t, sizeof(t));
        i--;
    }
}

static void bg_scan() {
    g_bgList.n = 0;
    char d[300];
    bg_dir(d, sizeof(d));
    mkdir_p(d);
    plat_listdir(d, bg_scan_cb, NULL);
    g_bgIdx = -1;
    for (int i = 0; i < g_bgList.n; i++)
        if (!strcmp(g_bgList.name[i], g_bgName)) g_bgIdx = i;
}

// Oscurece (o aclara, en tema claro) la imagen: g_bgShow = mezcla de g_bgRaw con negro/blanco.
static void bg_rebuild() {
    if (!g_bgRaw || !g_bgShow) return;
    int p = g_dim * 10;
    int t = g_light ? 255 : 0;
    size_t n = (size_t)SCREEN_W * SCREEN_H;
    if (p <= 0) { memcpy(g_bgShow, g_bgRaw, n * 4); return; }
    int q = 100 - p;
    int add = t * p;
    for (size_t i = 0; i < n; i++) {
        uint32_t c = g_bgRaw[i];
        uint32_t r = (((c >> 16) & 255) * q + add) / 100;
        uint32_t g = (((c >> 8) & 255) * q + add) / 100;
        uint32_t b = ((c & 255) * q + add) / 100;
        g_bgShow[i] = 0x80000000u | (r << 16) | (g << 8) | b;
    }
}

static bool bg_read_file(const char *path, unsigned char **buf, long *len, long max) {
    FILE *f = fopen(path, "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (n <= 0 || n > max) { fclose(f); return false; }
    *buf = (unsigned char *)malloc((size_t)n);
    if (!*buf) { fclose(f); return false; }
    *len = (long)fread(*buf, 1, (size_t)n, f);
    fclose(f);
    return *len == n;
}

struct BgJob { char path[400]; int seq; };

static void bg_thread(BgJob *job) {
    char err[120] = "";
    uint32_t *out = NULL;
    unsigned char *file = NULL;
    long flen = 0;
    if (!bg_read_file(job->path, &file, &flen, 24L * 1024 * 1024)) {
        snprintf(err, sizeof(err), "No pude leer la imagen (maximo 24 MB)");
    } else {
        int w = 0, h = 0, comp = 0;
        if (!stbi_info_from_memory(file, (int)flen, &w, &h, &comp)) snprintf(err, sizeof(err), "Imagen no valida (solo PNG o JPG normales)");
        else if ((long long)w * h > 20000000LL) snprintf(err, sizeof(err), "Imagen muy grande (%dx%d): usa una de 1920x1080", w, h);
        else {
            unsigned char *px = stbi_load_from_memory(file, (int)flen, &w, &h, &comp, 4);
            if (!px) snprintf(err, sizeof(err), "No pude decodificar la imagen");
            else {
                out = (uint32_t *)malloc((size_t)SCREEN_W * SCREEN_H * 4);
                if (!out) snprintf(err, sizeof(err), "Sin memoria para la imagen");
                else {
                    // "cover": llena toda la pantalla recortando lo que sobre, con interpolacion bilineal
                    float sx = (float)w / SCREEN_W, sy = (float)h / SCREEN_H;
                    float s = sx < sy ? sx : sy;  // pixeles de origen por pixel de pantalla
                    float ox = (w - SCREEN_W * s) * 0.5f, oy = (h - SCREEN_H * s) * 0.5f;
                    static int xi[SCREEN_W];
                    static float xf[SCREEN_W];
                    for (int x = 0; x < SCREEN_W; x++) {
                        float fx = ox + (x + 0.5f) * s - 0.5f;
                        if (fx < 0) fx = 0;
                        if (fx > w - 1) fx = (float)(w - 1);
                        xi[x] = (int)fx;
                        xf[x] = fx - xi[x];
                    }
                    for (int y = 0; y < SCREEN_H; y++) {
                        if (g_bgSeq.load() != job->seq) break;  // eligieron otra: deja de trabajar
                        float fy = oy + (y + 0.5f) * s - 0.5f;
                        if (fy < 0) fy = 0;
                        if (fy > h - 1) fy = (float)(h - 1);
                        int y0 = (int)fy, y1 = y0 + 1 < h ? y0 + 1 : y0;
                        float wy = fy - y0;
                        const unsigned char *r0 = px + (size_t)y0 * w * 4, *r1 = px + (size_t)y1 * w * 4;
                        uint32_t *dst = out + (size_t)y * SCREEN_W;
                        for (int x = 0; x < SCREEN_W; x++) {
                            int x0 = xi[x], x1 = x0 + 1 < w ? x0 + 1 : x0;
                            float wx = xf[x];
                            float ch[3];
                            for (int c = 0; c < 3; c++) {
                                float a = r0[x0 * 4 + c] * (1 - wx) + r0[x1 * 4 + c] * wx;
                                float b = r1[x0 * 4 + c] * (1 - wx) + r1[x1 * 4 + c] * wx;
                                ch[c] = a * (1 - wy) + b * wy;
                            }
                            dst[x] = 0x80000000u | ((uint32_t)(ch[0] + 0.5f) << 16) | ((uint32_t)(ch[1] + 0.5f) << 8) | (uint32_t)(ch[2] + 0.5f);
                        }
                    }
                }
                stbi_image_free(px);
            }
        }
    }
    free(file);
    {
        std::lock_guard<std::mutex> g(g_bgMu);
        if (g_bgSeq.load() == job->seq) {
            if (out) {
                free(g_bgPending);
                g_bgPending = out;
                out = NULL;
                g_bgState = 2;
            } else {
                snprintf(g_bgErr, sizeof(g_bgErr), "%s", err);
                g_bgState = 3;
            }
        }
    }
    free(out);
    delete job;
}

// Elige el fondo por nombre ("" = ninguno). La imagen se prepara en un hilo.
static void bg_select(const char *name) {
    snprintf(g_bgName, sizeof(g_bgName), "%s", name);
    int seq = ++g_bgSeq;
    g_bgErr[0] = 0;
    if (!name[0]) {
        g_bgOn = false;
        g_bgState = 0;
        return;
    }
    g_bgState = 1;
    BgJob *j = new BgJob();
    char d[300];
    bg_dir(d, sizeof(d));
    snprintf(j->path, sizeof(j->path), "%s/%s", d, name);
    j->seq = seq;
    try {
        std::thread(bg_thread, j).detach();
    } catch (...) {
        delete j;
        g_bgState = 3;
        snprintf(g_bgErr, sizeof(g_bgErr), "No se pudo iniciar el hilo");
    }
}

// Cada fotograma: recoge la imagen cuando el hilo termina.
static void bg_tick() {
    if (g_bgState.load() != 2) return;
    std::lock_guard<std::mutex> g(g_bgMu);
    if (!g_bgPending) return;
    size_t bytes = (size_t)SCREEN_W * SCREEN_H * 4;
    if (!g_bgShow) g_bgShow = (uint32_t *)malloc(bytes);
    if (!g_bgShow) { free(g_bgPending); g_bgPending = NULL; g_bgState = 3; snprintf(g_bgErr, sizeof(g_bgErr), "Sin memoria"); return; }
    free(g_bgRaw);
    g_bgRaw = g_bgPending;
    g_bgPending = NULL;
    bg_rebuild();
    g_bgOn = true;
    g_bgState = 0;
}

// ---------- panel translucido (deja ver la imagen de fondo) ----------

static void panel(int x, int y, int w, int h, uint32_t c) {
    if (!g_bgOn) { fill(x, y, w, h, c); return; }
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > SCREEN_W) w = SCREEN_W - x;
    if (y + h > SCREEN_H) h = SCREEN_H - y;
    if (w <= 0 || h <= 0) return;
    const unsigned A8 = 214, B8 = 256 - A8;
    unsigned cr = ((c >> 16) & 255) * A8, cg = ((c >> 8) & 255) * A8, cb = (c & 255) * A8;
    for (int yy = y; yy < y + h; yy++) {
        uint32_t *row = FB + (size_t)yy * SCREEN_W + x;
        for (int xx = 0; xx < w; xx++) {
            uint32_t d = row[xx];
            unsigned r = (cr + ((d >> 16) & 255) * B8) >> 8;
            unsigned g = (cg + ((d >> 8) & 255) * B8) >> 8;
            unsigned b = (cb + (d & 255) * B8) >> 8;
            row[xx] = 0x80000000u | (r << 16) | (g << 8) | b;
        }
    }
}

// Fondo de toda la pantalla (imagen o color liso).
static void draw_background() {
    if (g_bgOn && g_bgShow) memcpy(FB, g_bgShow, (size_t)SCREEN_W * SCREEN_H * 4);
    else fill(0, 0, SCREEN_W, SCREEN_H, C_BG);
}

// ---------- guardar / leer ----------
// /data/mcstore/theme.txt: linea 1 = "tema oscurecer", linea 2 = archivo de fondo

static void theme_save() {
    char p[300];
    mkdir_p(plat_data_dir());
    snprintf(p, sizeof(p), "%s/theme.txt", plat_data_dir());
    FILE *f = fopen(p, "w");
    if (!f) return;
    fprintf(f, "%d %d\n%s\n", g_theme, g_dim, g_bgName);
    fclose(f);
}

static void theme_load() {
    char p[300];
    snprintf(p, sizeof(p), "%s/theme.txt", plat_data_dir());
    FILE *f = fopen(p, "r");
    if (f) {
        int t = 0, d = 5;
        if (fscanf(f, "%d %d", &t, &d) == 2) {
            g_theme = (t >= 0 && t < N_THEMES) ? t : 0;
            g_dim = (d >= 0 && d <= 9) ? d : 5;
        }
        char line[96];
        if (fgets(line, sizeof(line), f) && fgets(line, sizeof(line), f)) {
            size_t l = strlen(line);
            while (l && (line[l - 1] == '\n' || line[l - 1] == '\r')) line[--l] = 0;
            snprintf(g_bgName, sizeof(g_bgName), "%s", line);
        }
        fclose(f);
    }
    theme_apply();
    bg_scan();
    if (g_bgName[0]) {
        if (g_bgIdx >= 0) bg_select(g_bgName);
        else g_bgName[0] = 0;
    }
}
