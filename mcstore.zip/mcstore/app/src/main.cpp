// McStore: busca y descarga add-ons (.mcpack/.mcaddon/.mcworld) desde un servidor en tu red local.
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/stat.h>

#include "platform.h"
#include "gfx.h"
#include "net.h"

#define MAX_ITEMS 200
#define MAX_JSON (512 * 1024)

enum Screen { S_LIST, S_KEYBOARD, S_SETTINGS };

// Colores
static uint32_t C_BG, C_PANEL, C_SEL, C_TEXT, C_DIM, C_ACCENT, C_OK, C_ERR, C_BAR;

struct App {
    Screen scr;
    Server srv;
    Item items[MAX_ITEMS];
    int n, sel, top;
    char query[40];
    char status[260];
    uint32_t statusCol;
    bool busy;
    // descarga en curso
    char dlName[96];
    long dlDone, dlTotal;
    // teclado
    int kr, kc;
    char kbuf[40];
    // ajustes
    int field;
    Server edit;
};

static App A;

static const char *KB_ROWS[4] = {"abcdefghij", "klmnopqrst", "uvwxyz0123", "456789'-_."};

// ---------- utilidades ----------

static void mkdir_p(const char *dir) {
    char tmp[256];
    snprintf(tmp, sizeof(tmp), "%s", dir);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') { *p = 0; mkdir(tmp, 0777); *p = '/'; }
    }
    mkdir(tmp, 0777);
}

static void set_status(uint32_t col, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
static void set_status(uint32_t col, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(A.status, sizeof(A.status), fmt, ap);
    va_end(ap);
    A.statusCol = col;
}

static void fmt_size(long b, char *out, size_t cap) {
    if (b <= 0) snprintf(out, cap, "?");
    else if (b < 1024) snprintf(out, cap, "%ld B", b);
    else if (b < 1024 * 1024) snprintf(out, cap, "%.1f KB", b / 1024.0);
    else snprintf(out, cap, "%.1f MB", b / 1048576.0);
}

// ---------- configuración ----------

static void config_path(char *out, size_t cap) { snprintf(out, cap, "%s/config.txt", plat_data_dir()); }

static bool config_load() {
    char p[300];
    config_path(p, sizeof(p));
    FILE *f = fopen(p, "r");
    if (!f) return false;
    int a, b, c, d, port;
    int k = fscanf(f, "%d.%d.%d.%d:%d", &a, &b, &c, &d, &port);
    fclose(f);
    if (k != 5) return false;
    A.srv.ip[0] = a; A.srv.ip[1] = b; A.srv.ip[2] = c; A.srv.ip[3] = d; A.srv.port = port;
    return true;
}

static void config_save() {
    char p[300];
    mkdir_p(plat_data_dir());
    config_path(p, sizeof(p));
    FILE *f = fopen(p, "w");
    if (!f) { set_status(C_ERR, "No se pudo guardar la configuracion en %s", p); return; }
    fprintf(f, "%d.%d.%d.%d:%d\n", A.srv.ip[0], A.srv.ip[1], A.srv.ip[2], A.srv.ip[3], A.srv.port);
    fclose(f);
}

// ---------- dibujo ----------

static void draw_header(const char *title) {
    fill(0, 0, SCREEN_W, 90, C_PANEL);
    fill(0, 88, SCREEN_W, 2, C_ACCENT);
    text(40, 28, title, 3, C_ACCENT);
    char s[96];
    snprintf(s, sizeof(s), "Servidor %d.%d.%d.%d:%d", A.srv.ip[0], A.srv.ip[1], A.srv.ip[2], A.srv.ip[3], A.srv.port);
    text(SCREEN_W - 40 - text_w(s, 2), 30, s, 2, C_DIM);
}

static void draw_footer(const char *hints) {
    fill(0, SCREEN_H - 120, SCREEN_W, 120, C_PANEL);
    fill(0, SCREEN_H - 120, SCREEN_W, 2, C_ACCENT);
    text(40, SCREEN_H - 108, A.status, 2, A.statusCol, 110);
    text(40, SCREEN_H - 52, hints, 2, C_DIM, 110);
}

#define ROW_H 46
#define LIST_Y 190
#define LIST_ROWS 15

static void draw_list() {
    draw_header("McStore - Add-ons");

    char q[80];
    snprintf(q, sizeof(q), "Busqueda: %s", A.query[0] ? A.query : "(todo el catalogo)");
    text(40, 108, q, 2, C_TEXT, 90);
    char cnt[48];
    snprintf(cnt, sizeof(cnt), "%d resultados", A.n);
    text(SCREEN_W - 40 - text_w(cnt, 2), 108, cnt, 2, C_DIM);

    if (A.n == 0) {
        text(60, LIST_Y + 20, "Sin resultados. Cuadrado: buscar | Triangulo: ajustes del servidor", 2, C_DIM);
    }
    for (int i = 0; i < LIST_ROWS; i++) {
        int idx = A.top + i;
        if (idx >= A.n) break;
        int y = LIST_Y + i * ROW_H;
        bool sel = idx == A.sel;
        if (sel) fill(30, y - 4, SCREEN_W - 60, ROW_H - 2, C_SEL);
        text(50, y + 4, A.items[idx].name, 2, sel ? C_TEXT : C_DIM, 66);
        char sz[24], right[160];
        fmt_size(A.items[idx].size, sz, sizeof(sz));
        snprintf(right, sizeof(right), "%s  %s", A.items[idx].file, sz);
        int maxc = 44;
        int len = (int)strlen(right);
        text(SCREEN_W - 50 - (len > maxc ? maxc : len) * 16, y + 4, right, 2, C_DIM, maxc);
    }
    // detalle del seleccionado
    if (A.n > 0) {
        int y = LIST_Y + LIST_ROWS * ROW_H + 6;
        text(50, y, A.items[A.sel].summary, 2, C_DIM, 114);
    }

    // barra de scroll
    if (A.n > LIST_ROWS) {
        int h = LIST_ROWS * ROW_H;
        int bh = h * LIST_ROWS / A.n;
        if (bh < 30) bh = 30;
        int by = LIST_Y + (h - bh) * A.top / (A.n - LIST_ROWS);
        fill(SCREEN_W - 22, LIST_Y, 8, h, C_PANEL);
        fill(SCREEN_W - 22, by, 8, bh, C_ACCENT);
    }

    // superposición de descarga
    if (A.busy && A.dlName[0]) {
        int w = 1200, h = 220, x = (SCREEN_W - w) / 2, y = (SCREEN_H - h) / 2;
        fill(x - 4, y - 4, w + 8, h + 8, C_ACCENT);
        fill(x, y, w, h, C_PANEL);
        text(x + 40, y + 30, "Descargando", 2, C_ACCENT);
        text(x + 40, y + 70, A.dlName, 2, C_TEXT, 66);
        int bx = x + 40, by = y + 120, bw = w - 80, bh = 30;
        fill(bx, by, bw, bh, C_BG);
        if (A.dlTotal > 0) fill(bx, by, (int)((long long)bw * A.dlDone / A.dlTotal), bh, C_OK);
        char s[96], a[24], b[24];
        fmt_size(A.dlDone, a, sizeof(a));
        fmt_size(A.dlTotal, b, sizeof(b));
        snprintf(s, sizeof(s), "%s / %s    (Circulo: cancelar)", a, b);
        text(bx, by + 44, s, 2, C_DIM);
    }

    draw_footer("X: descargar | Cuadrado: buscar | Triangulo: servidor | Options: recargar | L1/R1: pagina");
}

static void draw_keyboard() {
    draw_header("Buscar");
    char q[80];
    snprintf(q, sizeof(q), "%s_", A.kbuf);
    fill(300, 150, 1320, 70, C_PANEL);
    text(330, 168, q, 3, C_TEXT, 40);

    int cell = 100, gx = (SCREEN_W - 10 * cell) / 2, gy = 290;
    for (int r = 0; r < 4; r++) {
        for (int c = 0; c < 10; c++) {
            int x = gx + c * cell, y = gy + r * (cell + 10);
            bool sel = (r == A.kr && c == A.kc);
            fill(x, y, cell - 8, cell, sel ? C_ACCENT : C_PANEL);
            char ch[2] = {KB_ROWS[r][c], 0};
            text(x + (cell - 8 - 24) / 2, y + (cell - 48) / 2, ch, 3, sel ? C_BG : C_TEXT);
        }
    }
    draw_footer("X: escribir | Cuadrado: borrar | Triangulo: espacio | Options: buscar | Circulo: cancelar");
}

static void draw_settings() {
    draw_header("Servidor");
    text(200, 170, "Direccion IP del PC que corre server.py y su puerto:", 2, C_TEXT);

    int x = 200, y = 260;
    for (int i = 0; i < 5; i++) {
        char s[16];
        int v = i < 4 ? A.edit.ip[i] : A.edit.port;
        snprintf(s, sizeof(s), "%d", v);
        int w = i < 4 ? 180 : 260;
        bool sel = i == A.field;
        fill(x, y, w, 100, sel ? C_ACCENT : C_PANEL);
        text(x + (w - text_w(s, 4)) / 2, y + 18, s, 4, sel ? C_BG : C_TEXT);
        x += w + 10;
        if (i < 3) { text(x - 8, y + 36, ".", 4, C_DIM); }
        if (i == 3) { text(x - 8, y + 36, ":", 4, C_DIM); }
        x += 24;
    }
    text(200, 440, "Izquierda/Derecha: elegir campo   Arriba/Abajo: +1/-1   L1/R1: +10/-10 (puerto: +-100)", 2, C_DIM);
    text(200, 480, "La PC y la PS4 deben estar en la misma red. El puerto por defecto es 8080.", 2, C_DIM);
    draw_footer("X: guardar | Circulo: cancelar");
}

static void render() {
    gfx_begin();
    fill(0, 0, SCREEN_W, SCREEN_H, C_BG);
    if (A.scr == S_LIST) draw_list();
    else if (A.scr == S_KEYBOARD) draw_keyboard();
    else draw_settings();
    plat_present();
}

// ---------- acciones de red ----------

static void do_search() {
    A.busy = true;
    A.dlName[0] = 0;
    set_status(C_TEXT, "Buscando...");
    render();

    char enc[160], path[256], err[200];
    urlenc(A.query, enc, sizeof(enc));
    snprintf(path, sizeof(path), "/search?q=%s", enc);

    char *json = NULL;
    long len = 0;
    int st = http_get(A.srv, path, &json, &len, MAX_JSON, NULL, NULL, err, sizeof(err));
    A.busy = false;
    if (st != 200) {
        A.n = 0;
        set_status(C_ERR, "Error: %s", err);
        return;
    }
    A.n = parse_items(json, A.items, MAX_ITEMS);
    free(json);
    A.sel = A.top = 0;
    if (A.n) set_status(C_OK, "%d resultado(s). Pulsa X para descargar.", A.n);
    else set_status(C_DIM, "No hay resultados para esa busqueda.");
}

static uint64_t g_lastDraw = 0;
static bool dl_progress(long done, long total) {
    A.dlDone = done;
    A.dlTotal = total;
    uint64_t now = plat_ms();
    if (now - g_lastDraw >= 100) {
        g_lastDraw = now;
        render();
        if (plat_buttons() & BTN_CIRCLE) return false;
    }
    return true;
}

static void do_download() {
    if (A.n == 0) return;
    const Item &it = A.items[A.sel];

    char fname[128];
    safe_filename(it.file[0] ? it.file : it.name, fname, sizeof(fname));

    char dir[256], final_path[400], part_path[420];
    snprintf(dir, sizeof(dir), "%s/downloads", plat_data_dir());
    mkdir_p(dir);
    snprintf(final_path, sizeof(final_path), "%s/%s", dir, fname);
    snprintf(part_path, sizeof(part_path), "%s.part", final_path);

    FILE *fp = fopen(part_path, "wb");
    if (!fp) { set_status(C_ERR, "No se pudo crear %s", part_path); return; }

    A.busy = true;
    snprintf(A.dlName, sizeof(A.dlName), "%s", it.name);
    A.dlDone = 0;
    A.dlTotal = it.size;
    g_lastDraw = 0;
    set_status(C_TEXT, "Descargando %s...", fname);

    char path[128], err[200];
    snprintf(path, sizeof(path), "/download/%s", it.id);
    int st = http_get(A.srv, path, NULL, NULL, 0, fp, dl_progress, err, sizeof(err));
    fclose(fp);
    A.busy = false;
    A.dlName[0] = 0;

    if (st != 200) {
        remove(part_path);
        set_status(C_ERR, "Error: %s", err);
        return;
    }
    remove(final_path);
    if (rename(part_path, final_path) != 0) {
        set_status(C_ERR, "No se pudo renombrar a %s", final_path);
        return;
    }
    set_status(C_OK, "Guardado en %s", final_path);
}

// ---------- entrada ----------

static uint32_t g_prev = 0;
static int g_hold[16];

// Devuelve los botones recien pulsados, con repeticion para direcciones y L1/R1.
static uint32_t poll_input() {
    uint32_t cur = plat_buttons();
    uint32_t pressed = cur & ~g_prev;
    const uint32_t repeatable = BTN_UP | BTN_DOWN | BTN_LEFT | BTN_RIGHT | BTN_L1 | BTN_R1;
    for (int i = 0; i < 11; i++) {
        uint32_t bit = 1u << i;
        if (!(cur & bit)) { g_hold[i] = 0; continue; }
        g_hold[i]++;
        if ((repeatable & bit) && g_hold[i] > 24 && (g_hold[i] - 24) % 4 == 0) pressed |= bit;
    }
    g_prev = cur;
    return pressed;
}

static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

static void scroll_to_sel() {
    if (A.sel < A.top) A.top = A.sel;
    if (A.sel >= A.top + LIST_ROWS) A.top = A.sel - LIST_ROWS + 1;
}

static void input_list(uint32_t p) {
    if (p & BTN_DOWN) { A.sel = clampi(A.sel + 1, 0, A.n ? A.n - 1 : 0); scroll_to_sel(); }
    if (p & BTN_UP) { A.sel = clampi(A.sel - 1, 0, A.n ? A.n - 1 : 0); scroll_to_sel(); }
    if (p & BTN_R1) { A.sel = clampi(A.sel + LIST_ROWS, 0, A.n ? A.n - 1 : 0); scroll_to_sel(); }
    if (p & BTN_L1) { A.sel = clampi(A.sel - LIST_ROWS, 0, A.n ? A.n - 1 : 0); scroll_to_sel(); }
    if (p & BTN_CROSS) do_download();
    if (p & BTN_OPTIONS) do_search();
    if (p & BTN_SQUARE) {
        snprintf(A.kbuf, sizeof(A.kbuf), "%s", A.query);
        A.kr = A.kc = 0;
        A.scr = S_KEYBOARD;
    }
    if (p & BTN_TRIANGLE) {
        A.edit = A.srv;
        A.field = 0;
        A.scr = S_SETTINGS;
    }
}

static void input_keyboard(uint32_t p) {
    if (p & BTN_RIGHT) A.kc = (A.kc + 1) % 10;
    if (p & BTN_LEFT) A.kc = (A.kc + 9) % 10;
    if (p & BTN_DOWN) A.kr = (A.kr + 1) % 4;
    if (p & BTN_UP) A.kr = (A.kr + 3) % 4;
    size_t l = strlen(A.kbuf);
    if ((p & BTN_CROSS) && l + 1 < sizeof(A.kbuf)) { A.kbuf[l] = KB_ROWS[A.kr][A.kc]; A.kbuf[l + 1] = 0; }
    if ((p & BTN_TRIANGLE) && l + 1 < sizeof(A.kbuf)) { A.kbuf[l] = ' '; A.kbuf[l + 1] = 0; }
    if ((p & BTN_SQUARE) && l > 0) A.kbuf[l - 1] = 0;
    if (p & BTN_CIRCLE) A.scr = S_LIST;
    if (p & BTN_OPTIONS) {
        snprintf(A.query, sizeof(A.query), "%s", A.kbuf);
        A.scr = S_LIST;
        do_search();
    }
}

static void input_settings(uint32_t p) {
    if (p & BTN_RIGHT) A.field = clampi(A.field + 1, 0, 4);
    if (p & BTN_LEFT) A.field = clampi(A.field - 1, 0, 4);
    int step = 0;
    if (p & BTN_UP) step += 1;
    if (p & BTN_DOWN) step -= 1;
    if (p & BTN_R1) step += (A.field == 4 ? 100 : 10);
    if (p & BTN_L1) step -= (A.field == 4 ? 100 : 10);
    if (step) {
        if (A.field < 4) A.edit.ip[A.field] = clampi(A.edit.ip[A.field] + step, 0, 255);
        else A.edit.port = clampi(A.edit.port + step, 1, 65535);
    }
    if (p & BTN_CIRCLE) A.scr = S_LIST;
    if (p & BTN_CROSS) {
        A.srv = A.edit;
        config_save();
        A.scr = S_LIST;
        do_search();
    }
}

// ---------- main ----------

int main(void) {
    C_BG = RGB(18, 22, 20);
    C_PANEL = RGB(30, 38, 34);
    C_SEL = RGB(44, 84, 56);
    C_TEXT = RGB(235, 240, 235);
    C_DIM = RGB(150, 165, 155);
    C_ACCENT = RGB(96, 200, 96);
    C_OK = RGB(110, 220, 120);
    C_ERR = RGB(240, 100, 90);
    C_BAR = RGB(60, 70, 64);
    (void)C_BAR;

    memset(&A, 0, sizeof(A));
    A.srv.ip[0] = 192; A.srv.ip[1] = 168; A.srv.ip[2] = 1; A.srv.ip[3] = 100;
    A.srv.port = 8080;
    A.statusCol = C_DIM;

    if (!plat_init()) {
        // Sin video no hay nada que mostrar.
        for (;;) plat_sleep_ms(1000);
    }

    mkdir_p(plat_data_dir());
    bool haveConfig = config_load();
    if (haveConfig) {
        A.scr = S_LIST;
        set_status(C_DIM, "Conectando...");
        render();
        do_search();
    } else {
        A.edit = A.srv;
        A.scr = S_SETTINGS;
        set_status(C_TEXT, "Primera vez: configura la IP de tu PC (donde corre server.py).");
    }

    for (;;) {
        uint32_t p = poll_input();
        if (A.scr == S_LIST) input_list(p);
        else if (A.scr == S_KEYBOARD) input_keyboard(p);
        else input_settings(p);
        render();
    }
    return 0;
}
