// McStore: busca y descarga add-ons (.mcpack/.mcaddon/.mcworld).
// Fuentes: catalogo en GitHub (HTTPS, sin PC) o servidor propio en la red local.
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/stat.h>
#include <atomic>
#include <thread>
#include <mutex>

#include "platform.h"
#include "gfx.h"
#include "net.h"
#include "install.h"

#define MAX_ITEMS 2500
#define MAX_JSON (2 * 1024 * 1024)
#ifndef AUTO_CHECK_MS
#define AUTO_CHECK_MS (10ull * 60ull * 1000ull)  // revisa GitHub solo cada 10 min en la lista
#endif

// Lo define el Makefile con tu repositorio de GitHub; se puede cambiar con /data/mcstore/source.txt
#ifndef APP_VERSION
#define APP_VERSION "1.00"
#endif
#ifndef CATALOG_URL
#define CATALOG_URL "https://raw.githubusercontent.com/OWNER/REPO/main/catalog.json"
#endif

enum Screen { S_LIST, S_KEYBOARD, S_SETTINGS, S_INSTALL, S_DETAIL, S_FILTER };
enum Mode { M_GITHUB = 0, M_LAN = 1 };

// Colores
static uint32_t C_BG, C_BG2, C_PANEL, C_SEL, C_TEXT, C_DIM, C_ACCENT, C_ACC2, C_OK, C_ERR, C_BAR;

struct App {
    Screen scr;
    Server srv;
    int mode;
    char catalogUrl[300];
    Item *cat;
    int catN;
    bool catLoaded;
    Item items[MAX_ITEMS];
    int n, sel, top;             // top = primera FILA visible de la cuadricula
    int page, pages, sort;       // pagina actual / total (modo PC) y orden
    int catSel, kcat;            // categoria aplicada / elegida en el teclado (0 = todas)
    char query[40];
    char status[260];
    uint32_t statusCol;
    bool busy;
    uint64_t jobStart;
    // descarga en curso
    char dlName[96];
    long dlDone, dlTotal;
    // teclado
    int kr, kc;
    char kbuf[40];
    // ajustes
    int field;
    Server edit;
    int editMode;
};

static App A;
static char g_updHint[48] = "";   // "Nueva version X (L3)" cuando la app encontro una actualizacion
static bool g_catSilent = false;  // recarga automatica del catalogo (sin ventana, sin molestar)
static bool g_updSilent = false;  // la busqueda de version corre sin ventana (al abrir la app)

// ---------- pantalla "Instalar en Minecraft" ----------
#define MAX_PACKS 120
struct PackRow {
    char file[128];
    long size;
    bool isMcpack, isAddon;
    McPack info;  // solo para .mcpack
};
enum Modal { MD_NONE, MD_NOGAME, MD_VERSION, MD_REPLACE, MD_DONE, MD_ERROR, MD_DELETE, MD_DELALL };
struct Inst {
    PackRow *rows;
    int n, sel, top;
    int modal;
    char line[8][220];
    int nlines;
    McTargets tg;
    int consoleVer[3];
    bool haveVer;
    bool installing; bool resumeOk;
};
static Inst I;

static const char *KB_ROWS[4] = {"abcdefghij", "klmnopqrst", "uvwxyz0123", "456789'-_."};

// ---------- miniaturas: un hilo las baja del servidor (/thumb) sin frenar la pantalla ----------
#define MAX_THUMBS 72
#define THUMB_LIST 128   // tamano que se pide para las tarjetas
#define THUMB_BIG 256    // tamano para la pantalla de detalle
struct Thumb { char id[24]; int size; int w, h; uint32_t *px; int stamp; };
struct ThReq { char id[24]; int size; Server srv; bool gh; char url[420]; };
static Thumb g_th[MAX_THUMBS];
static int g_thN = 0, g_thStamp = 0;
static ThReq g_thQ[64];
static int g_thQN = 0;
static bool g_thWorker = false;
static std::mutex g_thMx;

static Thumb *th_find(const char *id, int size) {
    for (int i = 0; i < g_thN; i++)
        if (g_th[i].size == size && !strcmp(g_th[i].id, id)) return &g_th[i];
    return NULL;
}

static void th_store(const char *id, int size, int w, int h, uint32_t *px) {
    std::lock_guard<std::mutex> lk(g_thMx);
    int slot = g_thN;
    if (g_thN < MAX_THUMBS) g_thN++;
    else {
        slot = 0;
        for (int i = 1; i < g_thN; i++) if (g_th[i].stamp < g_th[slot].stamp) slot = i;
        free(g_th[slot].px);
    }
    Thumb &t = g_th[slot];
    snprintf(t.id, sizeof(t.id), "%s", id);
    t.size = size; t.w = w; t.h = h; t.px = px; t.stamp = ++g_thStamp;
}

static void th_worker() {
    for (;;) {
        ThReq r;
        bool have = false;
        {
            std::lock_guard<std::mutex> lk(g_thMx);
            if (g_thQN > 0) {
                r = g_thQ[0];
                memmove(&g_thQ[0], &g_thQ[1], sizeof(ThReq) * (size_t)(g_thQN - 1));
                g_thQN--;
                have = true;
            }
        }
        if (!have) { plat_sleep_ms(15); continue; }
        char path[80], err[100];
        char enc[48];
        urlenc(r.id, enc, sizeof(enc));
        snprintf(path, sizeof(path), "/thumb/%s?s=%d", enc, r.size);
        char *buf = NULL;
        long len = 0;
        uint32_t *px = NULL;
        int w = 0, h = 0;
        if (r.gh) {  // catalogo de GitHub: archivo .t96 = 96x96 RGB565 sin cabecera
            if (fetch(r.url, &buf, &len, 20000, NULL, NULL, NULL, err, sizeof(err)) == 200 && len == 96 * 96 * 2) {
                px = (uint32_t *)malloc(96 * 96 * 4);
                if (px) {
                    for (int i = 0; i < 96 * 96; i++) {
                        unsigned v = (unsigned char)buf[i * 2] | ((unsigned char)buf[i * 2 + 1] << 8);
                        int r5 = (v >> 11) & 31, g6 = (v >> 5) & 63, b5 = v & 31;
                        px[i] = RGB((r5 << 3) | (r5 >> 2), (g6 << 2) | (g6 >> 4), (b5 << 3) | (b5 >> 2));
                    }
                    w = h = 96;
                }
            }
        } else if (http_get(r.srv, path, &buf, &len, 8 + 256 * 256 * 4, NULL, NULL, NULL, err, sizeof(err)) == 200 &&
            len >= 8 && !memcmp(buf, "MCT1", 4)) {
            w = (unsigned char)buf[4] | ((unsigned char)buf[5] << 8);
            h = (unsigned char)buf[6] | ((unsigned char)buf[7] << 8);
            if (w > 0 && h > 0 && w <= 256 && h <= 256 && len == 8 + (long)w * h * 4) {
                px = (uint32_t *)malloc((size_t)w * h * 4);
                if (px) memcpy(px, buf + 8, (size_t)w * h * 4);
            }
        }
        free(buf);
        th_store(r.id, r.size, px ? w : 0, px ? h : 0, px);  // px NULL = no hay imagen (no se vuelve a pedir)
    }
}

static void th_request(const char *id, int size, const char *url = NULL) {
    std::lock_guard<std::mutex> lk(g_thMx);
    if (th_find(id, size)) return;
    for (int i = 0; i < g_thQN; i++)
        if (g_thQ[i].size == size && !strcmp(g_thQ[i].id, id)) return;
    if (g_thQN >= 64) return;
    snprintf(g_thQ[g_thQN].id, sizeof(g_thQ[g_thQN].id), "%s", id);
    g_thQ[g_thQN].size = size;
    g_thQ[g_thQN].srv = A.srv;
    g_thQ[g_thQN].gh = url != NULL;
    snprintf(g_thQ[g_thQN].url, sizeof(g_thQ[g_thQN].url), "%s", url ? url : "");
    g_thQN++;
    if (!g_thWorker) {
        g_thWorker = true;
        try { std::thread(th_worker).detach(); } catch (...) { g_thWorker = false; }
    }
}

static void th_clear_queue() {
    std::lock_guard<std::mutex> lk(g_thMx);
    g_thQN = 0;
}

// Dibuja la miniatura (de d x d) si ya llego; si no, un recuadro de color con la inicial. Devuelve true si hay imagen.
static bool draw_thumb(int x, int y, int d, const Item &it, int want) {
    bool drawn = false;
    bool gh = A.mode == M_GITHUB && it.img[0];       // miniatura del catalogo de GitHub (una sola medida)
    bool lan = A.mode == M_LAN && it.th;
    const char *key = gh ? it.img : it.id;
    if (gh) want = THUMB_LIST;
    if (gh || lan) {
        std::lock_guard<std::mutex> lk(g_thMx);
        Thumb *t = th_find(key, want);
        if (!t || !t->px) t = th_find(key, THUMB_LIST);  // mientras llega la grande, se usa la chica
        if (t && t->px) { t->stamp = ++g_thStamp; blit_scaled(x, y, d, t->px, t->w, t->h); drawn = true; }
    }
    if (!drawn) {
        unsigned hsh = 7;
        for (const char *c = it.name; *c; c++) hsh = hsh * 31 + (unsigned char)*c;
        fill(x, y, d, d, RGB(40 + hsh % 40, 60 + (hsh >> 8) % 50, 50 + (hsh >> 16) % 50));
        char ch[2] = {it.name[0] >= 'a' && it.name[0] <= 'z' ? (char)(it.name[0] - 32) : (it.name[0] ? it.name[0] : '?'), 0};
        int sc = d >= 200 ? 12 : 6;
        text(x + (d - 8 * sc) / 2, y + (d - 16 * sc) / 2, ch, sc, C_DIM);
        if (gh || lan) {
            bool asked;
            { std::lock_guard<std::mutex> lk(g_thMx); asked = th_find(key, want) != NULL; }
            if (!asked) {
                if (gh) {
                    char rel[48], url[420];
                    snprintf(rel, sizeof(rel), "thumbs/%s.t96", it.img);
                    resolve_url(A.catalogUrl, rel, url, sizeof(url));
                    th_request(key, want, url);
                } else th_request(key, want);
            }
        }
    } else if (want == THUMB_BIG && lan) {
        bool have;
        { std::lock_guard<std::mutex> lk(g_thMx); Thumb *t = th_find(it.id, THUMB_BIG); have = t && t->px; }
        if (!have) th_request(it.id, THUMB_BIG);
    }
    return drawn;
}

// ---------- categorias (las pide la app al servidor; 0 = todas) ----------
#define MAX_CATS 12
struct Cat { char id[12]; char name[32]; };
static Cat g_cats[MAX_CATS];
static int g_catN = 0;
static bool g_catsTried = false;

// ---------- pantalla de detalle ----------
#define DLINES 120
#define DCOLS 78
static Item g_det;                 // el add-on abierto
static char g_dVer[64];
static char g_dl[DLINES][96];      // descripcion ya partida en lineas
static int g_dN = 0, g_dTop = 0;

static void wrap_desc(const char *s, int cols) {
    g_dN = 0;
    g_dTop = 0;
    char line[100], word[100];
    int ll = 0, wl = 0;
    auto flush = [&]() {
        if (g_dN < DLINES) { line[ll] = 0; snprintf(g_dl[g_dN], sizeof(g_dl[0]), "%s", line); }
        g_dN++;
        ll = 0;
    };
    auto endword = [&]() {
        if (!wl) return;
        if (ll && ll + 1 + wl > cols) flush();
        if (ll) line[ll++] = ' ';
        memcpy(line + ll, word, (size_t)wl);
        ll += wl;
        wl = 0;
    };
    for (const char *p = s; *p; p++) {
        if (*p == '\n') { endword(); flush(); }
        else if (*p == ' ') endword();
        else {
            if (wl >= cols) endword();
            word[wl++] = *p;
        }
    }
    endword();
    if (ll) flush();
    if (g_dN > DLINES) g_dN = DLINES;
}

// ---------- utilidades ----------

static void mkdir_p(const char *dir) {
    char tmp[256];
    snprintf(tmp, sizeof(tmp), "%s", dir);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') { *p = 0; mkdir(tmp, 0777); *p = '/'; }
    }
    mkdir(tmp, 0777);
}

static void set_status(uint32_t col, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
static void set_status(uint32_t col, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(A.status, sizeof(A.status), fmt, ap);
    va_end(ap);
    A.statusCol = col;
}

static void fmt_size(long b, char *out, size_t cap) {
    if (b <= 0) snprintf(out, cap, "?");
    else if (b < 1024) snprintf(out, cap, "%ld B", b);
    else if (b < 1024 * 1024) snprintf(out, cap, "%.1f KB", b / 1024.0);
    else snprintf(out, cap, "%.1f MB", b / 1048576.0);
}

// ---------- configuración ----------

static void config_path(char *out, size_t cap) { snprintf(out, cap, "%s/config.txt", plat_data_dir()); }

static bool config_load() {
    char p[300];
    config_path(p, sizeof(p));
    FILE *f = fopen(p, "r");
    if (!f) return false;
    int a, b, c, d, port, mode = 0;
    int k = fscanf(f, "%d.%d.%d.%d:%d %d", &a, &b, &c, &d, &port, &mode);
    fclose(f);
    if (k < 5) return false;
    A.srv.ip[0] = a; A.srv.ip[1] = b; A.srv.ip[2] = c; A.srv.ip[3] = d; A.srv.port = port;
    A.mode = (k >= 6 && mode == M_LAN) ? M_LAN : M_GITHUB;
    return true;
}

static void config_save() {
    char p[300];
    mkdir_p(plat_data_dir());
    config_path(p, sizeof(p));
    FILE *f = fopen(p, "w");
    if (!f) { set_status(C_ERR, "No se pudo guardar la configuracion en %s", p); return; }
    fprintf(f, "%d.%d.%d.%d:%d\n%d\n", A.srv.ip[0], A.srv.ip[1], A.srv.ip[2], A.srv.ip[3], A.srv.port, A.mode);
    fclose(f);
}

// Catalogo: el del Makefile, o el de /data/mcstore/source.txt (primera linea) si existe.
static void source_load() {
    snprintf(A.catalogUrl, sizeof(A.catalogUrl), "%s", CATALOG_URL);
    char p[300];
    snprintf(p, sizeof(p), "%s/source.txt", plat_data_dir());
    FILE *f = fopen(p, "r");
    if (!f) return;
    char line[300];
    if (fgets(line, sizeof(line), f)) {
        size_t l = strlen(line);
        while (l && (line[l - 1] == '\n' || line[l - 1] == '\r' || line[l - 1] == ' ')) line[--l] = 0;
        if (!strncmp(line, "http", 4)) snprintf(A.catalogUrl, sizeof(A.catalogUrl), "%s", line);
    }
    fclose(f);
}

// ---------- dibujo ----------

// ---------- filtros (tipo / version de Minecraft) y tema de color ----------
static int g_fType = 0;       // 0 todos, 1 texturas, 2 addons, 3 otros
static char g_fVer[12] = "";  // "" = todas las versiones; si no, grupo "1.21"
static int g_theme = 0;       // indice en THEMES
static int g_fRow = 0;        // fila elegida en el menu de filtros
static char g_verList[40][12];  // grupos de version que existen en el catalogo, de la mas nueva a la mas vieja
static int g_verN = 0;
static const char *TYPE_LABEL[4] = {"Todos", "Texturas", "Addons", "Otros"};
#define NTHEMES 11
struct ThemeDef { const char *name; int bg[3], bg2[3], panel[3], sel[3], text[3], dim[3], acc[3], acc2[3], bar[3]; int pat; };  // pat: 0 liso, 1 gotico, 2 y2k, 3 drip, 4 tablero
static const ThemeDef THEMES[NTHEMES] = {
    {"Esmeralda", {8, 20, 15}, {14, 38, 29}, {20, 44, 35}, {30, 98, 68}, {236, 248, 240}, {130, 172, 152}, {64, 224, 150}, {250, 214, 90}, {42, 78, 63}},
    {"Nether", {22, 6, 8}, {48, 12, 10}, {50, 17, 16}, {132, 36, 24}, {255, 240, 226}, {192, 142, 122}, {255, 122, 40}, {255, 204, 72}, {96, 42, 36}},
    {"Oceano", {4, 14, 28}, {8, 36, 62}, {12, 38, 66}, {14, 102, 142}, {234, 250, 255}, {120, 166, 192}, {40, 214, 236}, {180, 244, 255}, {30, 72, 104}},
    {"Amatista", {14, 8, 26}, {34, 14, 58}, {36, 21, 64}, {100, 46, 176}, {246, 238, 255}, {162, 142, 198}, {192, 124, 255}, {255, 124, 204}, {68, 46, 114}},
    {"Oro negro", {8, 8, 8}, {26, 21, 10}, {30, 26, 18}, {96, 74, 14}, {250, 244, 226}, {172, 162, 132}, {255, 200, 40}, {255, 238, 154}, {76, 66, 34}},
    {"Hielo", {10, 14, 20}, {28, 38, 52}, {32, 43, 58}, {62, 96, 136}, {255, 255, 255}, {152, 168, 188}, {200, 228, 255}, {120, 192, 255}, {56, 72, 94}},
    {"Gotico", {6, 4, 8}, {30, 8, 16}, {26, 14, 20}, {100, 18, 36}, {240, 232, 236}, {164, 144, 154}, {222, 40, 70}, {208, 208, 224}, {74, 32, 44}, 1},
    {"Y2K", {26, 10, 54}, {104, 26, 116}, {52, 22, 94}, {150, 40, 170}, {255, 246, 255}, {206, 176, 236}, {255, 84, 198}, {96, 242, 255}, {100, 58, 154}, 2},
    {"Drip", {6, 8, 6}, {14, 24, 10}, {18, 27, 16}, {40, 98, 26}, {236, 255, 230}, {152, 184, 142}, {100, 255, 66}, {228, 255, 92}, {42, 68, 36}, 3},
    {"Sangre", {8, 4, 4}, {34, 6, 8}, {32, 14, 14}, {116, 16, 22}, {255, 236, 232}, {194, 144, 140}, {240, 26, 46}, {255, 136, 116}, {88, 30, 30}, 3},
    {"Punk", {10, 10, 12}, {22, 22, 30}, {28, 26, 34}, {124, 20, 104}, {255, 255, 255}, {180, 172, 194}, {255, 48, 164}, {255, 255, 255}, {74, 62, 88}, 4},
};
#define C3(a) RGB((a)[0], (a)[1], (a)[2])

static void apply_theme(int t) {
    g_theme = t < 0 || t >= NTHEMES ? 0 : t;
    const ThemeDef &d = THEMES[g_theme];
    C_BG = C3(d.bg); C_BG2 = C3(d.bg2); C_PANEL = C3(d.panel); C_SEL = C3(d.sel);
    C_TEXT = C3(d.text); C_DIM = C3(d.dim); C_ACCENT = C3(d.acc); C_ACC2 = C3(d.acc2);
    C_BAR = C3(d.bar); C_OK = C3(d.acc2); C_ERR = RGB(255, 100, 90);
}

// ---------- fondos con dibujo (gotico, y2k, drip, tablero): se pintan una vez por tema y se copian en cada cuadro ----------
static uint32_t *g_bg = NULL;
static int g_bgTheme = -1;
static unsigned g_rs = 1;
static unsigned rnd() { g_rs = g_rs * 1664525u + 1013904223u; return g_rs >> 8; }
static int isqrt_i(int v) { int r = 0; while ((r + 1) * (r + 1) <= v) r++; return r; }
static void fcircle(int cx, int cy, int r, uint32_t c) {
    for (int dy = -r; dy <= r; dy++) { int dx = isqrt_i(r * r - dy * dy); fill(cx - dx, cy + dy, dx * 2 + 1, 1, c); }
}
static void ring(int cx, int cy, int r, int th, uint32_t c) {
    for (int dy = -r; dy <= r; dy++) {
        int o = isqrt_i(r * r - dy * dy);
        int ri = r - th, in = (dy > -ri && dy < ri) ? isqrt_i(ri * ri - dy * dy) : -1;
        if (in < 0) fill(cx - o, cy + dy, o * 2 + 1, 1, c);
        else { fill(cx - o, cy + dy, o - in, 1, c); fill(cx + in + 1, cy + dy, o - in, 1, c); }
    }
}
static void sparkle(int cx, int cy, int r, uint32_t c) {
    for (int k = 0; k <= r; k++) {
        int w = (r - k) / 4 + 1;
        fill(cx - k, cy - w / 2, 1, w, c); fill(cx + k, cy - w / 2, 1, w, c);
        fill(cx - w / 2, cy - k, w, 1, c); fill(cx - w / 2, cy + k, w, 1, c);
    }
}
static void gothic_arch(int cx, int yb, int w, uint32_t c) {  // arco apuntado: ancho w, arranca en yb
    int hw = w / 2, apex = yb - (w * 866) / 1000;
    for (int y = apex; y <= yb; y++) {
        int dy = yb - y, s = isqrt_i(w * w - dy * dy);
        fill(cx + hw - s, y, 3, 1, c);
        fill(cx - hw + s - 2, y, 3, 1, c);
    }
    fill(cx - hw, yb, 3, 150, c);
    fill(cx + hw - 2, yb, 3, 150, c);
}
static void build_bg() {
    if (!g_bg) g_bg = (uint32_t *)malloc((size_t)SCREEN_W * SCREEN_H * 4);
    if (!g_bg) { g_bgTheme = g_theme; return; }
    uint32_t *save = FB;
    FB = g_bg;
    fill_vgrad(0, 0, SCREEN_W, SCREEN_H, C_BG, C_BG2);
    int pat = THEMES[g_theme].pat;
    g_rs = 12345;
    if (pat == 1) {  // gotico: ventanas de arco apuntado en ladrillo + rosetones
        uint32_t c1 = mix(C_BG2, C_ACCENT, 40), c2 = mix(C_BG2, C_ACCENT, 24);
        for (int j = -1; j < 6; j++)
            for (int i = -1; i < 14; i++) {
                int cx = i * 170 + ((j & 1) ? 85 : 0), yb = j * 230 + 150;
                gothic_arch(cx, yb, 120, c1);
                gothic_arch(cx, yb + 14, 84, c2);
                ring(cx, yb - 36, 15, 3, c1);
                fill(cx - 1, yb - 90, 3, 38, c2);
            }
    } else if (pat == 2) {  // y2k: rejilla, burbujas y destellos
        uint32_t g = mix(C_BG2, C_ACC2, 12);
        for (int x = 0; x < SCREEN_W; x += 60) fill(x, 0, 2, SCREEN_H, g);
        for (int y = 0; y < SCREEN_H; y += 60) fill(0, y, SCREEN_W, 2, g);
        for (int i = 0; i < 9; i++) ring(rnd() % SCREEN_W, rnd() % SCREEN_H, 30 + rnd() % 70, 3, mix(C_BG2, C_ACC2, 26));
        for (int i = 0; i < 46; i++) {
            int r = 8 + rnd() % 18;
            sparkle(rnd() % SCREEN_W, rnd() % SCREEN_H, r, (i & 1) ? mix(C_BG2, C_TEXT, 70) : mix(C_BG2, C_ACC2, 75));
        }
    } else if (pat == 3) {  // drip: baba que cuelga de la cabecera + manchas
        uint32_t col = mix(C_ACCENT, C_BG, 52), hi = mix(col, C_TEXT, 30);
        for (int i = 0; i < 16; i++) fcircle(rnd() % SCREEN_W, 200 + rnd() % 760, 6 + rnd() % 26, mix(C_BG2, C_ACCENT, 9));
        fill(0, 90, SCREEN_W, 10, col);
        for (int x = 4; x < SCREEN_W - 20;) {
            int w = 10 + rnd() % 18, len = 12 + rnd() % 44;
            fill(x, 100, w, len, col);
            fcircle(x + w / 2, 100 + len, w / 2 + 2, col);
            fill(x + 3, 100, 3, len - 4, hi);
            x += w + 14 + rnd() % 56;
        }
        for (int i = 0; i < 40; i++) fcircle(rnd() % SCREEN_W, 150 + rnd() % 800, 2 + rnd() % 4, mix(C_BG2, C_ACCENT, 22));
    } else if (pat == 4) {  // tablero punk
        uint32_t c = mix(C_BG, C_ACCENT, 15);
        for (int y = 0; y < SCREEN_H; y += 54)
            for (int x = 0; x < SCREEN_W; x += 54)
                if (((x / 54) + (y / 54)) & 1) fill(x, y, 54, 54, c);
    }
    FB = save;
    g_bgTheme = g_theme;
}

static bool has_ci(const char *hay, const char *needle) {
    size_t n = strlen(needle);
    for (; *hay; hay++) if (!strncasecmp(hay, needle, n)) return true;
    return false;
}

// 1 = textura, 2 = addon, 3 = otro (mapa, skin...). Si el catalogo no trae "cls", se adivina por el texto.
static int item_type(const Item &it) {
    if (!strcmp(it.cls, "tex")) return 1;
    if (!strcmp(it.cls, "add")) return 2;
    if (it.cls[0]) return 3;
    if (has_ci(it.name, "texture") || has_ci(it.name, "textura") || has_ci(it.name, "resource pack") ||
        has_ci(it.summary, "texture pack") || has_ci(it.summary, "resource pack") || has_ci(it.summary, "textura")) return 1;
    return 2;
}

// "1.21.50" -> "1.21" (grupo). Devuelve false si no parece una version.
static bool ver_group(const char *v, char *out, size_t cap) {
    int a = 0, b = 0, n = 0;
    if (sscanf(v, "%d.%d%n", &a, &b, &n) < 2) return false;
    snprintf(out, cap, "%d.%d", a, b);
    return true;
}

static bool item_has_ver(const Item &it, const char *grp) {
    char tok[24], g[12];
    const char *p = it.vers[0] ? it.vers : it.ver;
    while (*p) {
        size_t l = strcspn(p, ",");
        if (l > 0 && l < sizeof(tok)) {
            memcpy(tok, p, l);
            tok[l] = 0;
            if (ver_group(tok, g, sizeof(g)) && !strcmp(g, grp)) return true;
        }
        p += l;
        if (*p == ',') p++;
    }
    return false;
}

static bool item_passes_filters(const Item &it) {
    if (g_fType && item_type(it) != g_fType) return false;
    if (g_fVer[0] && !item_has_ver(it, g_fVer)) return false;
    return true;
}

static int ver_key(const char *g) { int a = 0, b = 0; sscanf(g, "%d.%d", &a, &b); return a * 1000 + b; }

// Junta los grupos de version que trae el catalogo (ordenados de mas nuevo a mas viejo).
static void build_ver_list() {
    g_verN = 0;
    for (int i = 0; i < A.catN; i++) {
        const Item &it = A.cat[i];
        const char *p = it.vers[0] ? it.vers : it.ver;
        while (*p) {
            size_t l = strcspn(p, ",");
            char tok[24], g[12];
            if (l > 0 && l < sizeof(tok)) {
                memcpy(tok, p, l);
                tok[l] = 0;
                if (ver_group(tok, g, sizeof(g))) {
                    bool have = false;
                    for (int k = 0; k < g_verN; k++) if (!strcmp(g_verList[k], g)) { have = true; break; }
                    if (!have && g_verN < 40) snprintf(g_verList[g_verN++], 12, "%s", g);
                }
            }
            p += l;
            if (*p == ',') p++;
        }
    }
    for (int i = 1; i < g_verN; i++) {  // orden descendente (insercion)
        char t[12];
        snprintf(t, sizeof(t), "%s", g_verList[i]);
        int j = i - 1;
        while (j >= 0 && ver_key(g_verList[j]) < ver_key(t)) { memcpy(g_verList[j + 1], g_verList[j], 12); j--; }
        snprintf(g_verList[j + 1], 12, "%s", t);
    }
}

static void ui_path(char *out, size_t cap) { snprintf(out, cap, "%s/ui.txt", plat_data_dir()); }

static void ui_save() {
    char p[300];
    ui_path(p, sizeof(p));
    FILE *f = fopen(p, "w");
    if (!f) return;
    fprintf(f, "%d %s %d\n", g_fType, g_fVer[0] ? g_fVer : "-", g_theme);
    fclose(f);
}

static void ui_load() {
    char p[300], v[16] = "-";
    int t = 0, th = 0;
    ui_path(p, sizeof(p));
    FILE *f = fopen(p, "r");
    if (f) {
        if (fscanf(f, "%d %15s %d", &t, v, &th) >= 2) {
            g_fType = t < 0 || t > 3 ? 0 : t;
            snprintf(g_fVer, sizeof(g_fVer), "%s", v[0] == '-' ? "" : v);
        }
        fclose(f);
    }
    apply_theme(th);
}

static void draw_header(const char *title) {
    fill_vgrad(0, 0, SCREEN_W, 90, mix(C_PANEL, C_ACCENT, 28), C_PANEL);
    fill(0, 86, SCREEN_W, 4, C_BAR);
    fill(0, 86, 420, 4, C_ACCENT);
    fill(420, 86, 140, 4, C_ACC2);
    // logo: bloque con tapa y sombra
    fill(34, 22, 48, 48, C_BG);
    fill(38, 26, 40, 40, C_ACCENT);
    fill(38, 26, 40, 12, C_ACC2);
    fill(38, 54, 40, 12, mix(C_ACCENT, C_BG, 35));
    text(103, 29, title, 3, C_BG);       // sombra
    text(100, 26, title, 3, C_TEXT);
    char s[96];
    if (g_updHint[0]) snprintf(s, sizeof(s), "%s", g_updHint);
    else if (A.mode == M_GITHUB) snprintf(s, sizeof(s), "Fuente: GitHub");
    else snprintf(s, sizeof(s), "Fuente: PC %d.%d.%d.%d:%d", A.srv.ip[0], A.srv.ip[1], A.srv.ip[2], A.srv.ip[3], A.srv.port);
    int w = text_w(s, 2) + 28;
    fill(SCREEN_W - 44 - w, 20, w + 8, 48, mix(C_BG, C_ACCENT, 50));
    fill(SCREEN_W - 40 - w, 24, w, 40, g_updHint[0] ? C_ACCENT : mix(C_PANEL, C_ACCENT, 30));
    text(SCREEN_W - 26 - w, 34, s, 2, g_updHint[0] ? C_BG : C_TEXT);
}

// Pie con chips de botones: "X: instalar | Cuad: borrar" -> [X] instalar  [Cuad] borrar
static void draw_footer(const char *hints) {
    fill_vgrad(0, SCREEN_H - 120, SCREEN_W, 120, C_PANEL, mix(C_PANEL, C_BG, 60));
    fill(0, SCREEN_H - 120, SCREEN_W, 2, C_BAR);
    fill(0, SCREEN_H - 120, 420, 2, C_ACCENT);
    text(40, SCREEN_H - 108, A.status, 2, A.statusCol, 115);
    int x = 40, y = SCREEN_H - 58;
    const char *p = hints;
    while (*p) {
        const char *e = strstr(p, " | ");
        int len = e ? (int)(e - p) : (int)strlen(p);
        char seg[96];
        snprintf(seg, sizeof(seg), "%.*s", len < 95 ? len : 95, p);
        char *c = strchr(seg, ':');
        if (c) {
            *c = 0;
            const char *lab = c + 1;
            while (*lab == ' ') lab++;
            int kw = (int)strlen(seg) * 16 + 14;
            fill(x, y - 4, kw, 40, C_ACCENT);
            text(x + 7, y, seg, 2, C_BG);
            x += kw + 8;
            text(x, y, lab, 2, C_TEXT);
            x += (int)strlen(lab) * 16;
        } else {
            text(x, y, seg, 2, C_DIM);
            x += (int)strlen(seg) * 16;
        }
        x += 22;
        if (!e) break;
        p = e + 3;
    }
}

#define ROW_H 46
#define LIST_Y 190
#define LIST_ROWS 15

static bool g_updCheck = false;  // true mientras se busca una version nueva de la app
static int g_busyKind = 0;        // tipo del trabajo de red en curso (4 = detalle: no tapa la pantalla)

#define GRID_COLS 4
#define GRID_ROWS 4
#define CARD_W 450
#define CARD_H 182
#define CARD_GAP 10
#define GRID_X0 ((SCREEN_W - (GRID_COLS * CARD_W + (GRID_COLS - 1) * CARD_GAP)) / 2)
#define GRID_Y 146

static const char *SORT_KEY[5] = {"popular", "downloads", "updated", "new", "name"};
static const char *SORT_LABEL[5] = {"Popular", "Mas bajado", "Actualizado", "Nuevo", "Nombre"};

static void fmt_count(long n, char *out, size_t cap) {
    if (n < 1000) snprintf(out, cap, "%ld", n);
    else if (n < 1000000) snprintf(out, cap, "%.1fK", n / 1000.0);
    else snprintf(out, cap, "%.1fM", n / 1000000.0);
}

static bool quiet_job() { return g_busyKind == 4 || g_busyKind == 5 || (g_busyKind == 3 && g_updSilent) || (g_busyKind == 1 && g_catSilent); }

static void draw_busy() {
    if (quiet_job()) return;
    if (A.busy) {
        int w = 1300, h = 240, x = (SCREEN_W - w) / 2, y = (SCREEN_H - h) / 2;
        fill(x - 4, y - 4, w + 8, h + 8, C_ACCENT);
        fill(x, y, w, h, C_PANEL);
        unsigned long secs = (unsigned long)((plat_ms() - A.jobStart) / 1000);
        char s[160];
        if (A.dlName[0]) {
            text(x + 40, y + 30, "Descargando", 2, C_ACCENT);
            text(x + 40, y + 70, A.dlName, 2, C_TEXT, 70);
            int bx = x + 40, by = y + 120, bw = w - 80, bh = 30;
            fill(bx, by, bw, bh, C_BG);
            if (A.dlTotal > 0) fill(bx, by, (int)((long long)bw * A.dlDone / A.dlTotal), bh, C_OK);
            char a1[24], b1[24];
            fmt_size(A.dlDone, a1, sizeof(a1));
            fmt_size(A.dlTotal, b1, sizeof(b1));
            snprintf(s, sizeof(s), "%s / %s   %lus   (Circulo: cancelar)", a1, b1, secs);
            text(bx, by + 50, s, 2, C_DIM);
        } else {
            if (A.mode == M_GITHUB) {
                text(x + 40, y + 30, g_updCheck ? "Buscando actualizacion de McStore..." : "Cargando catalogo...", 2, C_ACCENT);
                snprintf(s, sizeof(s), "Conectando con GitHub   %lus", secs);
            } else {
                text(x + 40, y + 30, "Buscando...", 2, C_ACCENT);
                snprintf(s, sizeof(s), "Conectando con %d.%d.%d.%d:%d   %lus", A.srv.ip[0], A.srv.ip[1], A.srv.ip[2], A.srv.ip[3], A.srv.port, secs);
            }
            text(x + 40, y + 80, s, 2, C_TEXT);
            text(x + 40, y + 130, "Circulo: cancelar", 2, C_DIM);
            if (secs >= 6)
                text(x + 40, y + 175, A.mode == M_GITHUB ? "Tarda mucho: revisa tu conexion a internet." : "Tarda mucho: revisa la IP (cancela y pulsa Triangulo).", 2, C_ERR, 70);
        }
    }
}

// Una tarjeta: miniatura a la izquierda; nombre (2 lineas), autor y descargas a la derecha.
static void draw_card(int idx, int x, int y, bool sel) {
    const Item &it = A.items[idx];
    if (sel) {
        fill(x - 6, y - 6, CARD_W + 12, CARD_H + 12, mix(C_BG, C_ACCENT, 40));
        fill(x - 3, y - 3, CARD_W + 6, CARD_H + 6, C_ACCENT);
        fill_vgrad(x, y, CARD_W, CARD_H, mix(C_SEL, C_TEXT, 14), C_SEL);
        fill(x, y, 6, CARD_H, C_ACC2);
    } else {
        fill_vgrad(x, y, CARD_W, CARD_H, mix(C_PANEL, C_TEXT, 7), C_PANEL);
        fill(x, y, CARD_W, 2, mix(C_PANEL, C_TEXT, 16));
    }
    draw_thumb(x + 12, y + (CARD_H - THUMB_LIST) / 2, THUMB_LIST, it, THUMB_LIST);
    if (it.ver[0]) {  // insignia con la version de Minecraft del pack
        char vb[9];
        snprintf(vb, sizeof(vb), "%.7s", it.ver);
        int bw = (int)strlen(vb) * 16 + 10, by0 = y + (CARD_H - THUMB_LIST) / 2 + THUMB_LIST - 34;
        fill(x + 12, by0, bw, 34, C_ACC2);
        text(x + 17, by0 + 1, vb, 2, C_BG);
    }
    int tx = x + 12 + THUMB_LIST + 14, cols = (CARD_W - (tx - x) - 8) / 16;  // caracteres por linea (escala 2)
    uint32_t col = sel ? C_TEXT : mix(C_TEXT, C_ACC2, 40);
    char l1[64], l2[64];
    int len = (int)strlen(it.name);
    if (len <= cols) { snprintf(l1, sizeof(l1), "%s", it.name); l2[0] = 0; }
    else {
        int cut = cols;
        for (int i = cols; i > cols / 2; i--) if (it.name[i] == ' ') { cut = i; break; }
        snprintf(l1, sizeof(l1), "%.*s", cut, it.name);
        const char *rest = it.name + cut;
        while (*rest == ' ') rest++;
        snprintf(l2, sizeof(l2), "%s", rest);
    }
    text(tx, y + 10, l1, 2, col, cols);
    if (l2[0]) text(tx, y + 44, l2, 2, col, cols);
    char by[64];
    if (it.author[0]) snprintf(by, sizeof(by), "por %s", it.author);
    else snprintf(by, sizeof(by), "%s", it.summary);
    text(tx, y + 90, by, 2, C_DIM, cols);
    char a1[24], b1[24], info[64];
    fmt_count(it.dl, a1, sizeof(a1));
    fmt_size(it.size, b1, sizeof(b1));
    if (it.dl > 0) snprintf(info, sizeof(info), "%s desc. %s", a1, b1);
    else snprintf(info, sizeof(info), "%s", b1);
    text(tx, y + 124, info, 2, C_ACCENT, cols);
    if (it.flag) {
        const char *tg = it.flag == 1 ? "[NUEVO]" : it.flag == 2 ? (A.mode == M_LAN ? "[HAY UPDATE]" : "[ACTUALIZADO]") : "[DESCARGADO]";
        text(tx, y + 152, tg, 2, it.flag == 1 ? C_OK : it.flag == 2 ? C_ACCENT : C_DIM, cols);
    }
}

// Pantalla de detalle: foto grande, datos y descripcion con scroll.
static void draw_detail() {
    draw_header("McStore - Detalle");
    int ix = 50, iy = 120, isz = 384;
    fill(ix - 4, iy - 4, isz + 8, isz + 8, C_ACCENT);
    draw_thumb(ix, iy, isz, g_det, THUMB_BIG);
    int tx = ix + isz + 50;
    text(tx, 120, g_det.name, 3, C_TEXT, (SCREEN_W - tx - 40) / 24);
    char s[160], a1[24], b1[24];
    s[0] = 0;
    if (g_det.author[0]) snprintf(s, sizeof(s), "por %s     ", g_det.author);
    if (g_dVer[0]) snprintf(s + strlen(s), sizeof(s) - strlen(s), "Minecraft: %s", g_dVer);
    if (s[0]) text(tx, 176, s, 2, C_ACCENT, 80);
    fmt_count(g_det.dl, a1, sizeof(a1));
    fmt_size(g_det.size, b1, sizeof(b1));
    snprintf(s, sizeof(s), "Descargas: %s    Actualizado: %s    Tamano: %s", a1, g_det.upd[0] ? g_det.upd : "?", b1);
    text(tx, 214, s, 2, C_DIM, 80);
    snprintf(s, sizeof(s), "Archivo: %s", g_det.file);
    text(tx, 248, s, 2, C_DIM, 80);
    if (g_det.flag == 3) text(tx, 282, "Ya descargado (al dia)", 2, C_DIM);
    else if (g_det.flag == 2) text(tx, 282, A.mode == M_LAN ? "Hay una version mas nueva: pulsa X para actualizar" : "Actualizado en el catalogo: pulsa X para bajarlo", 2, C_ACCENT, 80);
    else if (g_det.flag == 1) text(tx, 282, "Nuevo en el catalogo", 2, C_OK);
    fill(tx, 322, SCREEN_W - tx - 40, 2, C_BAR);
    int y0 = 336, lh = 34, vis = 17;
    if (A.busy && g_busyKind == 4) text(tx, y0, "Cargando descripcion...", 2, C_DIM);
    for (int i = 0; i < vis && g_dTop + i < g_dN; i++) text(tx, y0 + i * lh, g_dl[g_dTop + i], 2, C_TEXT, DCOLS + 2);
    if (g_dN > vis) {
        int h = vis * lh, bh = h * vis / g_dN;
        if (bh < 30) bh = 30;
        int by = y0 + (h - bh) * g_dTop / (g_dN - vis);
        fill(SCREEN_W - 22, y0, 8, h, C_PANEL);
        fill(SCREEN_W - 22, by, 8, bh, C_ACCENT);
    }
    draw_busy();
    draw_footer(g_det.flag == 2 ? "X: actualizar | Arriba/Abajo: leer | R2: instalar en Minecraft | Circulo: volver" : "X: descargar | Arriba/Abajo: leer | R2: instalar en Minecraft | Circulo: volver");
}

static void draw_list() {
    draw_header("McStore - Add-ons");

    char q[120];
    if (A.catSel > 0 && A.catSel < g_catN) snprintf(q, sizeof(q), "Busqueda: %s  |  %s", A.query[0] ? A.query : "(todo)", g_cats[A.catSel].name);
    else snprintf(q, sizeof(q), "Busqueda: %s", A.query[0] ? A.query : "(todo)");
    if (A.mode == M_GITHUB && (g_fType || g_fVer[0])) {
        size_t l = strlen(q);
        snprintf(q + l, sizeof(q) - l, "  |  %s%s%s%s", g_fType ? TYPE_LABEL[g_fType] : "", g_fType && g_fVer[0] ? " " : "",
                 g_fVer[0] ? "MC " : "", g_fVer);
    }
    text(40, 108, q, 2, C_TEXT, 62);
    char cnt[96];
    if (A.mode == M_LAN) snprintf(cnt, sizeof(cnt), "Orden: %s   Pagina %d/%d", SORT_LABEL[A.sort], A.page, A.pages);
    else snprintf(cnt, sizeof(cnt), "%d resultados", A.n);
    text(SCREEN_W - 40 - text_w(cnt, 2), 108, cnt, 2, C_DIM);

    if (A.n == 0 && !A.busy) {
        if (A.mode == M_GITHUB && A.catLoaded && A.catN == 0)
            text(60, LIST_Y + 20, "El catalogo esta vacio: agrega add-ons a catalog.json en tu repositorio.", 2, C_DIM);
        else
            text(60, LIST_Y + 20, "Sin resultados. Cuadrado: buscar | Triangulo: ajustes", 2, C_DIM);
    }
    if (A.n > 0) {
        int rows = (A.n + GRID_COLS - 1) / GRID_COLS;
        for (int r = 0; r < GRID_ROWS; r++) {
            for (int col = 0; col < GRID_COLS; col++) {
                int idx = (A.top + r) * GRID_COLS + col;
                if (idx >= A.n) break;
                draw_card(idx, GRID_X0 + col * (CARD_W + CARD_GAP), GRID_Y + r * (CARD_H + CARD_GAP), idx == A.sel);
            }
        }
        if (rows > GRID_ROWS) {  // barra de scroll
            int h = GRID_ROWS * (CARD_H + CARD_GAP);
            int bh = h * GRID_ROWS / rows;
            if (bh < 30) bh = 30;
            int by = GRID_Y + (h - bh) * A.top / (rows - GRID_ROWS);
            fill(SCREEN_W - 16, GRID_Y, 8, h, C_PANEL);
            fill(SCREEN_W - 16, by, 8, bh, C_ACCENT);
        }
    }

    draw_busy();
    if (A.mode == M_GITHUB) draw_footer("X: detalle | Cuad: buscar | Circ: filtros | Opt: recargar | L2: updates | R2: instalar | L3: app | Tri: ajustes");
    else draw_footer("X: detalle | Cuad: buscar | Circ: orden | L1/R1: pag. | Opt: recargar | L2: updates | R2: instalar | Tri: ajustes");
}

static void draw_keyboard() {
    draw_header("Buscar");
    char q[80];
    snprintf(q, sizeof(q), "%s_", A.kbuf);
    fill(300, 150, 1320, 70, C_PANEL);
    text(330, 168, q, 3, C_TEXT, 40);

    if (A.mode == M_LAN && g_catN > 1) {
        char cs[80];
        snprintf(cs, sizeof(cs), "Categoria (L1/R1):  < %s >", g_cats[A.kcat].name);
        text(300, 236, cs, 2, A.kcat ? C_ACCENT : C_DIM, 70);
    }
    int cell = 100, gx = (SCREEN_W - 10 * cell) / 2, gy = 290;
    for (int r = 0; r < 4; r++) {
        for (int c = 0; c < 10; c++) {
            int x = gx + c * cell, y = gy + r * (cell + 10);
            bool sel = (r == A.kr && c == A.kc);
            fill(x, y, cell - 8, cell, sel ? C_ACCENT : C_PANEL);
            char ch[2] = {KB_ROWS[r][c], 0};
            text(x + (cell - 8 - 24) / 2, y + (cell - 48) / 2, ch, 3, sel ? C_BG : C_TEXT);
        }
    }
    draw_footer("X: escribir | Cuadrado: borrar | Triangulo: espacio | L1/R1: categoria | Options: buscar | Circulo: cancelar");
}

static void draw_settings() {
    draw_header("Ajustes");
    text(200, 140, "Fuente de add-ons:", 2, C_TEXT);
    bool selMode = A.field == 0;
    fill(200, 185, 1000, 80, selMode ? C_ACCENT : C_PANEL);
    text(230, 205, A.editMode == M_GITHUB ? "GitHub (sin PC, por internet)" : "PC en mi red (server.py)", 3, selMode ? C_BG : C_TEXT);

    uint32_t lbl = A.editMode == M_LAN ? C_TEXT : C_DIM;
    text(200, 320, "Direccion del PC (solo para la fuente PC):", 2, lbl);
    int x = 200, y = 370;
    for (int i = 0; i < 5; i++) {
        char s[16];
        int v = i < 4 ? A.edit.ip[i] : A.edit.port;
        snprintf(s, sizeof(s), "%d", v);
        int w = i < 4 ? 180 : 260;
        bool sel = (i + 1) == A.field;
        fill(x, y, w, 100, sel ? C_ACCENT : C_PANEL);
        text(x + (w - text_w(s, 4)) / 2, y + 18, s, 4, sel ? C_BG : lbl);
        x += w + 10;
        if (i < 3) { text(x - 8, y + 36, ".", 4, C_DIM); }
        if (i == 3) { text(x - 8, y + 36, ":", 4, C_DIM); }
        x += 24;
    }
    text(200, 520, "Izquierda/Derecha: elegir campo   Arriba/Abajo: cambiar   L1/R1: +-10 (puerto: +-100)", 2, C_DIM);
    text(200, 560, "GitHub: lee catalog.json de tu repositorio. PC: usa server.py en tu red.", 2, C_DIM);
    draw_footer("X: guardar | Circulo: cancelar");
}

static const char *pack_kind_label(const PackRow &r, uint32_t *col) {
    *col = C_DIM;
    if (r.isAddon) return ".mcaddon (pendiente)";
    if (!r.isMcpack) return "formato no soportado";
    if (r.info.kind == PK_RES) { *col = C_OK; return "Texturas -> resource_packs"; }
    if (r.info.kind == PK_BEH) { *col = C_OK; return "Comportamiento -> behavior_packs"; }
    *col = C_ERR;
    return "no instalable";
}

static void draw_install() {
    draw_header("McStore - Instalar en Minecraft");
    char d[300];
    snprintf(d, sizeof(d), "Descargas: %s/downloads   (Minecraft debe estar abierto)", plat_data_dir());
    text(40, 108, d, 2, C_TEXT, 100);
    char cnt[48];
    snprintf(cnt, sizeof(cnt), "%d archivo(s)", I.n);
    text(SCREEN_W - 40 - text_w(cnt, 2), 108, cnt, 2, C_DIM);

    if (I.n == 0) text(60, LIST_Y + 20, "No hay archivos descargados. Vuelve (Circulo) y descarga uno con X.", 2, C_DIM);
    for (int i = 0; i < LIST_ROWS; i++) {
        int idx = I.top + i;
        if (idx >= I.n) break;
        const PackRow &r = I.rows[idx];
        int y = LIST_Y + i * ROW_H;
        bool sel = idx == I.sel;
        if (sel) { fill(30, y - 4, SCREEN_W - 60, ROW_H - 2, C_SEL); fill(30, y - 4, 8, ROW_H - 2, C_ACC2); }
        else if (i & 1) fill(30, y - 4, SCREEN_W - 60, ROW_H - 2, mix(C_BG, C_PANEL, 55));
        text(50, y + 4, r.file, 2, sel ? C_TEXT : C_DIM, 52);
        uint32_t col;
        const char *k = pack_kind_label(r, &col);
        char sz[24];
        fmt_size(r.size, sz, sizeof(sz));
        char right[96];
        snprintf(right, sizeof(right), "%s  %s", k, sz);
        text(SCREEN_W - 50 - (int)strlen(right) * 16, y + 4, right, 2, col, 60);
    }
    if (I.n > 0) {
        const PackRow &r = I.rows[I.sel];
        char s[300] = "";
        if (r.isMcpack && r.info.kind != PK_BAD) {
            if (r.info.hasMin) snprintf(s, sizeof(s), "%s  |  Requiere Minecraft %d.%d.%d o mas nuevo", r.info.name[0] ? r.info.name : "(sin nombre)", r.info.minEng[0], r.info.minEng[1], r.info.minEng[2]);
            else snprintf(s, sizeof(s), "%s  |  Sin min_engine_version", r.info.name[0] ? r.info.name : "(sin nombre)");
        } else if (r.isMcpack) {
            snprintf(s, sizeof(s), "%s", r.info.err);
        } else if (r.isAddon) {
            snprintf(s, sizeof(s), "Los .mcaddon traen varios packs: el soporte llega mas adelante.");
        }
        text(50, LIST_Y + LIST_ROWS * ROW_H + 6, s, 2, (r.isMcpack && r.info.kind == PK_BAD) ? C_ERR : C_DIM, 114);
    }

    if (I.installing) {
        int w = 1100, h = 160, x = (SCREEN_W - w) / 2, y = (SCREEN_H - h) / 2;
        fill(x - 4, y - 4, w + 8, h + 8, C_ACCENT);
        fill(x, y, w, h, C_PANEL);
        text(x + 40, y + 55, "Instalando... no apagues la consola", 3, C_TEXT);
    } else if (I.modal != MD_NONE) {
        int w = 1500, h = 120 + I.nlines * 44 + 70, x = (SCREEN_W - w) / 2, y = (SCREEN_H - h) / 2 - 40;
        uint32_t edge = (I.modal == MD_DONE) ? C_OK : (I.modal == MD_NOGAME || I.modal == MD_ERROR || I.modal == MD_DELETE || I.modal == MD_DELALL) ? C_ERR : C_ACCENT;
        fill(x - 4, y - 4, w + 8, h + 8, edge);
        fill(x, y, w, h, C_PANEL);
        static const char *titles[] = {"", "Minecraft no esta abierto", "Version de Minecraft", "El pack ya existe", "Listo", "No se pudo instalar", "Borrar archivo", "Borrar todo"};
        text(x + 40, y + 28, titles[I.modal], 3, edge);
        for (int i = 0; i < I.nlines; i++) text(x + 40, y + 100 + i * 44, I.line[i], 2, C_TEXT, 88);
        const char *hint = (I.modal == MD_VERSION) ? "X: instalar igual | Circulo: cancelar"
                         : (I.modal == MD_REPLACE) ? "X: reemplazar | Circulo: cancelar"
                         : (I.modal == MD_DELETE || I.modal == MD_DELALL) ? "X: borrar | Circulo: cancelar"
                         : (I.modal == MD_DONE) ? "Triangulo: volver a Minecraft | X o Circulo: cerrar"
                                                   : "X o Circulo: cerrar";
        text(x + 40, y + h - 56, hint, 2, C_DIM);
    }
    draw_footer("X: instalar | Cuad: borrar | Tri: borrar todos | L2: instalar todos | Opt: refrescar | Circ: volver");
}

// Menu de filtros y tema: tipo, version de Minecraft y color de la app.
static int filter_count() {
    int c = 0;
    for (int i = 0; i < A.catN; i++) if (item_passes_filters(A.cat[i])) c++;
    return c;
}

static void draw_filter() {
    draw_header("McStore - Filtros y tema");
    char val[3][64];
    snprintf(val[0], sizeof(val[0]), "%s", TYPE_LABEL[g_fType]);
    if (g_fVer[0]) snprintf(val[1], sizeof(val[1]), "%s.x", g_fVer);
    else snprintf(val[1], sizeof(val[1]), "%s", g_verN ? "Todas" : "Todas (el catalogo aun no trae versiones)");
    snprintf(val[2], sizeof(val[2]), "%s", THEMES[g_theme].name);
    static const char *lbl[3] = {"Tipo de add-on", "Version de Minecraft", "Tema de color"};
    static const char *hint[3] = {"Texturas = resource packs. Addons = comportamiento, mobs, items.",
                                  "Muestra solo packs hechos para esa version (1.21.x incluye 1.21.0, 1.21.50...).",
                                  "Cambia al instante. Se guarda."};
    for (int i = 0; i < 3; i++) {
        int y = 150 + i * 190;
        bool sel = g_fRow == i;
        if (sel) fill_vgrad(200, y, 1520, 150, C_ACCENT, mix(C_ACCENT, C_BG, 30));
        else fill_vgrad(200, y, 1520, 150, mix(C_PANEL, C_TEXT, 7), C_PANEL);
        fill(200, y, 12, 150, sel ? C_TEXT : C_ACC2);
        text(240, y + 18, lbl[i], 2, sel ? C_BG : C_DIM);
        text(240, y + 56, val[i], 4, sel ? C_BG : C_TEXT, 44);
        text(240, y + 116, hint[i], 2, sel ? C_BG : C_DIM, 90);
        if (sel) {
            text(1500, y + 56, "<   >", 4, C_BG);
        }
        if (i == 2) {  // muestras de todos los temas
            for (int t = 0; t < NTHEMES; t++) {
                int sx = 700 + t * 70;
                if (t == g_theme) fill(sx - 5, y + 36, 64, 78, sel ? C_BG : C_ACCENT);
                fill(sx, y + 41, 54, 68, C3(THEMES[t].bg2));
                fill(sx, y + 41, 54, 20, C3(THEMES[t].panel));
                fill(sx + 6, y + 70, 28, 26, C3(THEMES[t].acc));
                fill(sx + 38, y + 70, 12, 26, C3(THEMES[t].acc2));
            }
        }
    }
    char info[120];
    snprintf(info, sizeof(info), "%d de %d add-ons con este filtro", filter_count(), A.catN);
    text(200, 730, info, 3, C_OK);
    draw_footer("Arriba/Abajo: fila | Izq/Der: cambiar | X o Circulo: aplicar y volver | Triangulo: quitar filtros");
}

static void render() {
    gfx_begin();
    if (g_bgTheme != g_theme) build_bg();
    if (g_bg) memcpy(FB, g_bg, (size_t)SCREEN_W * SCREEN_H * 4);
    else fill_vgrad(0, 0, SCREEN_W, SCREEN_H, C_BG, C_BG2);
    if (A.scr == S_LIST) draw_list();
    else if (A.scr == S_KEYBOARD) draw_keyboard();
    else if (A.scr == S_INSTALL) draw_install();
    else if (A.scr == S_DETAIL) draw_detail();
    else if (A.scr == S_FILTER) draw_filter();
    else draw_settings();
    plat_present();
}

// ---------- trabajos de red (en un hilo, para no congelar la pantalla) ----------

struct Job {
    std::atomic<int> refs;       // 2: hilo de red + hilo principal; el ultimo lo libera
    std::atomic<int> finished;
    std::atomic<bool> cancel;
    std::atomic<long> done, total;
    int kind;                    // 1 = buscar, 2 = descargar
    int mode;                    // M_GITHUB o M_LAN
    char url[420];               // modo GitHub: URL completa
    Server srv;
    char path[320];
    char finalPath[400];
    int ok;
    char err[200];
    Item *items;
    int n;
    int page, pages;             // modo PC: pagina devuelta y total
    char *raw;                   // kind 4: JSON del detalle
    char id[24];                 // kind 4: add-on pedido
};
static Job *g_job = NULL;
static Item g_prevCat[MAX_ITEMS];  // catalogo anterior, para detectar novedades al actualizar
static int g_prevN = 0;

static void job_release(Job *j) {
    if (j->refs.fetch_sub(1) == 1) {
        free(j->raw);
        delete[] j->items;
        delete j;
    }
}

static bool job_progress(long done, long total, void *ctx) {
    Job *j = (Job *)ctx;
    j->done = done;
    j->total = total;
    return !j->cancel.load();
}

static void job_main(Job *j) {
    if (j->kind == 4) {  // detalle de un add-on (modo PC)
        char *json = NULL;
        long len = 0;
        if (http_get(j->srv, j->path, &json, &len, MAX_JSON, NULL, job_progress, j, j->err, sizeof(j->err)) == 200) {
            j->raw = json;
            j->ok = 1;
        } else free(json);
    } else if (j->kind == 1 || j->kind == 3 || j->kind == 5) {
        char *json = NULL;
        long len = 0;
        int st = (j->mode == M_GITHUB)
                     ? fetch(j->url, &json, &len, MAX_JSON, NULL, job_progress, j, j->err, sizeof(j->err))
                     : http_get(j->srv, j->path, &json, &len, MAX_JSON, NULL, job_progress, j, j->err, sizeof(j->err));
        if (st == 200) {
            j->items = new Item[MAX_ITEMS];
            j->n = parse_items(json, j->items, MAX_ITEMS);
            j->page = json_int(json, "\"page\":", 1);
            j->pages = json_int(json, "\"pages\":", 1);
            j->ok = 1;
        }
        free(json);
    } else {
        char part[420];
        snprintf(part, sizeof(part), "%s.part", j->finalPath);
        FILE *fp = fopen(part, "wb");
        if (!fp) {
            snprintf(j->err, sizeof(j->err), "No se pudo crear %s", part);
        } else {
            int st = (j->mode == M_GITHUB)
                         ? fetch(j->url, NULL, NULL, 0, fp, job_progress, j, j->err, sizeof(j->err))
                         : http_get(j->srv, j->path, NULL, NULL, 0, fp, job_progress, j, j->err, sizeof(j->err));
            fclose(fp);
            if (st != 200) {
                remove(part);
            } else {
                remove(j->finalPath);
                if (rename(part, j->finalPath) == 0) j->ok = 1;
                else snprintf(j->err, sizeof(j->err), "No se pudo renombrar a %s", j->finalPath);
            }
        }
    }
    j->finished = 1;
    job_release(j);
}

static Job *job_new(int kind) {
    Job *j = new Job();
    j->refs = 2;
    j->finished = 0;
    j->cancel = false;
    j->done = 0;
    j->total = 0;
    j->kind = kind;
    j->mode = A.mode;
    j->url[0] = 0;
    j->srv = A.srv;
    j->path[0] = 0;
    j->finalPath[0] = 0;
    j->ok = 0;
    j->err[0] = 0;
    j->items = NULL;
    j->n = 0;
    j->page = 1;
    j->pages = 1;
    j->raw = NULL;
    j->id[0] = 0;
    return j;
}

static void job_start(Job *j) {
    g_job = j;
    g_busyKind = j->kind;
    A.busy = true;
    A.jobStart = plat_ms();
    try {
        std::thread(job_main, j).detach();
    } catch (...) {
        g_job = NULL;
        A.busy = false;
        A.dlName[0] = 0;
        set_status(C_ERR, "No se pudo iniciar el hilo de red");
        job_release(j);
        job_release(j);
    }
}

static void lower_in_place(char *t) {
    for (; *t; t++) if (*t >= 'A' && *t <= 'Z') *t = (char)(*t + 32);
}

// Copia a la lista los add-ons del catalogo que coinciden con la busqueda (sin usar la red).
static void filter_catalog() {
    char q[48];
    snprintf(q, sizeof(q), "%s", A.query);
    lower_in_place(q);
    A.n = 0;
    for (int i = 0; i < A.catN && A.n < MAX_ITEMS; i++) {
        char hay[320];
        snprintf(hay, sizeof(hay), "%s %s", A.cat[i].name, A.cat[i].summary);
        lower_in_place(hay);
        if ((!q[0] || strstr(hay, q)) && item_passes_filters(A.cat[i])) A.items[A.n++] = A.cat[i];
    }
    A.sel = A.top = 0;
    if (A.catN == 0) set_status(C_DIM, "El catalogo esta vacio (agrega add-ons a catalog.json en tu repositorio).");
    else if (A.n == 0 && g_fVer[0] && g_verN == 0) set_status(C_DIM, "El catalogo aun no trae versiones: ejecuta Build catalog en GitHub y recarga (Options).");
    else if (A.n == 0) set_status(C_DIM, "No hay resultados con esa busqueda y esos filtros (Circulo: filtros).");
    else set_status(C_OK, "%d add-on(s). Pulsa X para descargar.", A.n);
}

// ---------- novedades del catalogo (nuevo / actualizado) ----------
// Se compara con el catalogo anterior (en memoria) o, al abrir la app, con la lista guardada de la ultima vez.
struct Seen { char key[96]; long size; };
static Seen g_seen[MAX_ITEMS];
static int g_seenN = 0;
static bool g_seenHave = false;

static const char *item_key(const Item &it) { return it.file[0] ? it.file : it.name; }

static void seen_path(char *out, size_t cap) { snprintf(out, cap, "%s/catalog_seen.txt", plat_data_dir()); }

static void seen_load() {
    g_seenN = 0;
    g_seenHave = false;
    char p[300];
    seen_path(p, sizeof(p));
    FILE *f = fopen(p, "r");
    if (!f) return;
    g_seenHave = true;
    char line[200];
    while (g_seenN < MAX_ITEMS && fgets(line, sizeof(line), f)) {
        char *bar = strrchr(line, '|');
        if (!bar) continue;
        *bar = 0;
        snprintf(g_seen[g_seenN].key, sizeof(g_seen[g_seenN].key), "%s", line);
        g_seen[g_seenN].size = atol(bar + 1);
        g_seenN++;
    }
    fclose(f);
}

static void seen_save(const Item *c, int n) {
    char p[300];
    seen_path(p, sizeof(p));
    FILE *f = fopen(p, "w");
    if (!f) return;
    for (int i = 0; i < n; i++) fprintf(f, "%s|%ld\n", item_key(c[i]), c[i].size);
    fclose(f);
}

// Marca cada item de `fresh` como nuevo/actualizado y devuelve cuantos hay de cada uno.
static void mark_changes(Item *fresh, int n, const Item *old, int oldN, int *nNew, int *nUpd) {
    *nNew = *nUpd = 0;
    bool haveBase = oldN > 0 || g_seenHave;
    for (int i = 0; i < n; i++) {
        Item &it = fresh[i];
        it.flag = 0;
        if (!haveBase) continue;  // primera vez: no marcar todo como nuevo
        const char *k = item_key(it);
        bool found = false;
        long oldSize = 0;
        unsigned char oldFlag = 0;
        if (oldN > 0) {
            for (int j = 0; j < oldN; j++)
                if (!strcmp(item_key(old[j]), k)) { found = true; oldSize = old[j].size; oldFlag = old[j].flag; break; }
        } else {
            for (int j = 0; j < g_seenN; j++)
                if (!strcmp(g_seen[j].key, k)) { found = true; oldSize = g_seen[j].size; break; }
        }
        if (!found) it.flag = 1;
        else if (it.size > 0 && oldSize > 0 && it.size != oldSize) it.flag = 2;
        else it.flag = oldFlag;  // conserva la marca de antes dentro de la misma sesion
        if (it.flag == 1) (*nNew)++;
        else if (it.flag == 2) (*nUpd)++;
    }
    // Si "aparecen" de golpe muchisimos, es que cambiaron todo el catalogo (no que salieron
    // 100+ add-ons): no los marcamos como [NUEVO] para que L2 no intente bajarlos todos.
    if (*nNew > 100) {
        for (int i = 0; i < n; i++) if (fresh[i].flag == 1) fresh[i].flag = 0;
        *nNew = 0;
    }
}

// ---------- lo ya descargado (modo PC): sirve para marcar [DESCARGADO] / [HAY UPDATE] ----------
struct Got { char id[24]; char upd[12]; long size; };
#define MAX_GOT 400
static Got g_got[MAX_GOT];
static int g_gotN = 0;

static void got_path(char *out, size_t cap) { snprintf(out, cap, "%s/got.txt", plat_data_dir()); }

static void got_load() {
    g_gotN = 0;
    char p[300];
    got_path(p, sizeof(p));
    FILE *f = fopen(p, "r");
    if (!f) return;
    char line[120];
    while (g_gotN < MAX_GOT && fgets(line, sizeof(line), f)) {
        char *b1 = strchr(line, '|');
        char *b2 = b1 ? strchr(b1 + 1, '|') : NULL;
        if (!b2) continue;
        *b1 = 0; *b2 = 0;
        Got &g = g_got[g_gotN++];
        snprintf(g.id, sizeof(g.id), "%s", line);
        snprintf(g.upd, sizeof(g.upd), "%s", b1 + 1);
        g.size = atol(b2 + 1);
    }
    fclose(f);
}

static void got_set(const Item &it) {
    int k = -1;
    for (int i = 0; i < g_gotN; i++) if (!strcmp(g_got[i].id, it.id)) { k = i; break; }
    if (k < 0) k = g_gotN < MAX_GOT ? g_gotN++ : MAX_GOT - 1;
    snprintf(g_got[k].id, sizeof(g_got[k].id), "%s", it.id);
    snprintf(g_got[k].upd, sizeof(g_got[k].upd), "%s", it.upd);
    g_got[k].size = it.size;
    char p[300];
    got_path(p, sizeof(p));
    FILE *f = fopen(p, "w");
    if (!f) return;
    for (int i = 0; i < g_gotN; i++) fprintf(f, "%s|%s|%ld\n", g_got[i].id, g_got[i].upd, g_got[i].size);
    fclose(f);
}

// 0 = nunca bajado, 3 = bajado y al dia, 2 = bajado pero el servidor tiene otra version (fecha o tamano distintos)
static void mark_got(Item *arr, int n) {
    for (int i = 0; i < n; i++) {
        arr[i].flag = 0;
        for (int j = 0; j < g_gotN; j++) {
            if (strcmp(g_got[j].id, arr[i].id)) continue;
            bool changed = (arr[i].upd[0] && strcmp(arr[i].upd, g_got[j].upd)) || (arr[i].size > 0 && g_got[j].size > 0 && arr[i].size != g_got[j].size);
            arr[i].flag = changed ? 2 : 3;
            break;
        }
    }
}

static void start_search(bool reload = false) {
    if (g_job) return;
    if (A.mode == M_GITHUB && A.catLoaded && !reload) { filter_catalog(); return; }
    Job *j = job_new(1);
    if (A.mode == M_GITHUB) {
        snprintf(j->url, sizeof(j->url), "%s", A.catalogUrl);
        if (!g_catSilent) set_status(C_TEXT, "Cargando catalogo...");
    } else {
        char enc[160];
        urlenc(A.query, enc, sizeof(enc));
        snprintf(j->path, sizeof(j->path), "/browse?q=%s&page=%d&sort=%s", enc, A.page < 1 ? 1 : A.page, SORT_KEY[A.sort]);
        if (A.catSel > 0 && A.catSel < g_catN) {
            size_t l = strlen(j->path);
            snprintf(j->path + l, sizeof(j->path) - l, "&cat=%s", g_cats[A.catSel].id);
        }
        set_status(C_TEXT, "Buscando...");
        th_clear_queue();
    }
    A.dlName[0] = 0;
    job_start(j);
}

static bool g_bulk = false;
static int g_bulkTotal = 0, g_bulkDone = 0;
static int g_dlIdx = -1;  // indice (en A.items) de la descarga en curso

// Al abrir la app: borra de /data/pkg los McStore-X.pkg que ya estan instalados (version <= la actual),
// para que no queden en Package Installer despues de actualizar.
static void pkg_cleanup_cb(const char *name, void *) {
    int b[3] = {0, 0, 0}, a[3] = {0, 0, 0};
    if (strncmp(name, "McStore-", 8) || !strstr(name, ".pkg")) return;
    sscanf(name + 8, "%d.%d.%d", &b[0], &b[1], &b[2]);
    sscanf(APP_VERSION, "%d.%d.%d", &a[0], &a[1], &a[2]);
    int cmp = 0;
    for (int i = 0; i < 3 && !cmp; i++) cmp = b[i] > a[i] ? 1 : (b[i] < a[i] ? -1 : 0);
    if (cmp <= 0) {
        char p[300];
        snprintf(p, sizeof(p), "/data/pkg/%s", name);
        remove(p);
    }
}
static void pkg_cleanup() { plat_listdir("/data/pkg", pkg_cleanup_cb, NULL); }

// ---------- actualizacion de la propia app (app_update.json junto a catalog.json) ----------
// Formato: [{"name":"1.01","summary":"que cambia","url":"McStore.pkg","size":123456}]
struct AppUpd { bool avail; char ver[32]; char url[420]; long size; };
static AppUpd g_upd = {false, "", "", 0};
static bool g_pkgDl = false;  // true si la descarga en curso es el PKG de la app

static void check_app_update() {
    if (g_job) return;
    if (A.mode != M_GITHUB) { set_status(C_DIM, "La actualizacion de la app solo funciona con la fuente GitHub."); return; }
    if (g_upd.avail) {
        // segunda pulsacion: bajar el PKG nuevo a /data/pkg (se instala luego desde Debug Settings > Package Installer)
        mkdir_p("/data/pkg");
        Job *j = job_new(2);
        snprintf(j->finalPath, sizeof(j->finalPath), "/data/pkg/McStore-%s.pkg", g_upd.ver);
        snprintf(j->url, sizeof(j->url), "%s", g_upd.url);
        snprintf(A.dlName, sizeof(A.dlName), "McStore %s (PKG)", g_upd.ver);
        A.dlDone = 0;
        A.dlTotal = g_upd.size;
        g_bulk = false;
        g_dlIdx = -1;
        g_pkgDl = true;
        set_status(C_TEXT, "Descargando McStore %s...", g_upd.ver);
        job_start(j);
        return;
    }
    Job *j = job_new(3);
    resolve_url(A.catalogUrl, "app_update.json", j->url, sizeof(j->url));
    A.dlName[0] = 0;
    g_updCheck = true;
    if (!g_updSilent) set_status(C_TEXT, "Buscando actualizacion de McStore...");
    job_start(j);
}

// Descarga en cadena de todo lo marcado [NUEVO] / [ACTUALIZADO] (boton L2).

static int next_flagged() {
    for (int i = 0; i < A.n; i++)
        if ((A.items[i].flag == 1 || A.items[i].flag == 2) && (A.items[i].url[0] || A.mode == M_LAN)) return i;
    return -1;
}

static void start_download_idx(int idx) {
    if (g_job || idx < 0 || idx >= A.n) return;
    const Item &it = A.items[idx];
    if (A.mode == M_GITHUB && !it.url[0]) {
        set_status(C_ERR, "Esta entrada no tiene \"url\" en catalog.json");
        g_bulk = false;
        return;
    }
    g_dlIdx = idx;

    char fname[128], dir[256];
    safe_filename(it.file[0] ? it.file : it.name, fname, sizeof(fname));
    snprintf(dir, sizeof(dir), "%s/downloads", plat_data_dir());
    mkdir_p(dir);

    Job *j = job_new(2);
    snprintf(j->finalPath, sizeof(j->finalPath), "%s/%s", dir, fname);
    if (A.mode == M_GITHUB) snprintf(j->url, sizeof(j->url), "%s", it.url);
    else snprintf(j->path, sizeof(j->path), "/download/%s", it.id);
    snprintf(A.dlName, sizeof(A.dlName), "%s", it.name);
    A.dlDone = 0;
    A.dlTotal = it.size;
    if (g_bulk) set_status(C_TEXT, "Descargando %d de %d: %s", g_bulkDone + 1, g_bulkTotal, fname);
    else set_status(C_TEXT, "Descargando %s...", fname);
    job_start(j);
}

// Abre la pantalla de detalle del add-on seleccionado (en modo PC pide la descripcion completa).
static void open_detail() {
    if (A.n == 0) return;
    g_det = A.items[A.sel];
    snprintf(g_dVer, sizeof(g_dVer), "%s", g_det.vers[0] ? g_det.vers : g_det.ver);
    wrap_desc(g_det.summary, DCOLS);
    A.scr = S_DETAIL;
    set_status(C_DIM, "Pulsa X para descargar.");
    if (A.mode != M_LAN || g_job) return;
    th_request(g_det.id, THUMB_BIG);
    Job *j = job_new(4);
    char enc[48];
    urlenc(g_det.id, enc, sizeof(enc));
    snprintf(j->path, sizeof(j->path), "/detail/%s", enc);
    snprintf(j->id, sizeof(j->id), "%s", g_det.id);
    A.dlName[0] = 0;
    job_start(j);
}

static void start_download() {
    if (g_job || A.n == 0) return;
    g_bulk = false;
    start_download_idx(A.sel);
}

static void start_bulk() {
    if (g_job || A.n == 0) return;
    int c = 0;
    for (int i = 0; i < A.n; i++)
        if ((A.items[i].flag == 1 || A.items[i].flag == 2) && (A.items[i].url[0] || A.mode == M_LAN)) c++;
    if (!c) {
        if (A.mode == M_LAN) set_status(C_DIM, "No hay actualizaciones en esta pagina (solo se actualiza lo que ya descargaste).");
        else set_status(C_DIM, "No hay nada [NUEVO] ni [ACTUALIZADO]. Pulsa Options para buscar novedades en GitHub.");
        return;
    }
    g_bulk = true;
    g_bulkTotal = c;
    g_bulkDone = 0;
    start_download_idx(next_flagged());
}

// Se llama en cada fotograma: pasa el progreso a la pantalla y recoge el resultado.
static void job_poll() {
    Job *j = g_job;
    if (!j) return;
    A.dlDone = j->done.load();
    if (j->total.load() > 0) A.dlTotal = j->total.load();
    if (!j->finished.load()) return;

    if (j->kind == 4) {
        if (j->ok && A.scr == S_DETAIL && !strcmp(g_det.id, j->id)) {
            char desc[2000];
            json_str(j->raw, "desc", desc, sizeof(desc), true);
            json_str(j->raw, "ver", g_dVer, sizeof(g_dVer));
            json_str(j->raw, "author", g_det.author, sizeof(g_det.author));
            json_str(j->raw, "upd", g_det.upd, sizeof(g_det.upd));
            g_det.dl = json_int(j->raw, "\"dl\":", (int)g_det.dl);
            if (desc[0]) wrap_desc(desc, DCOLS);
        } else if (!j->ok) {
            set_status(C_ERR, "No pude cargar la descripcion: %s", j->err);
        }
    } else if (j->kind == 5) {  // categorias del servidor
        if (j->ok && j->n > 0) {
            g_catN = 1;
            g_cats[0].id[0] = 0;
            snprintf(g_cats[0].name, sizeof(g_cats[0].name), "Todas");
            for (int i = 0; i < j->n && g_catN < MAX_CATS; i++) {
                snprintf(g_cats[g_catN].id, sizeof(g_cats[g_catN].id), "%s", j->items[i].id);
                snprintf(g_cats[g_catN].name, sizeof(g_cats[g_catN].name), "%s", j->items[i].name);
                g_catN++;
            }
        }
    } else if (j->kind == 3) {
        bool silent = g_updSilent;
        g_updCheck = false;
        g_updSilent = false;
        if (!j->ok) {
            if (!silent) set_status(C_ERR, "No pude mirar GitHub: %s (falta app_update.json en tu repo?)", j->err);
        } else if (j->n == 0) {
            if (!silent) set_status(C_ERR, "app_update.json no tiene datos.");
        } else {
            const Item &u = j->items[0];
            int a[3] = {0, 0, 0}, b[3] = {0, 0, 0};
            sscanf(APP_VERSION, "%d.%d.%d", &a[0], &a[1], &a[2]);
            sscanf(u.name, "%d.%d.%d", &b[0], &b[1], &b[2]);
            int cmp = 0;
            for (int i = 0; i < 3 && !cmp; i++) cmp = b[i] > a[i] ? 1 : (b[i] < a[i] ? -1 : 0);
            if (cmp > 0 && u.url[0]) {
                g_upd.avail = true;
                snprintf(g_upd.ver, sizeof(g_upd.ver), "%s", u.name);
                resolve_url(j->url, u.url, g_upd.url, sizeof(g_upd.url));
                g_upd.size = u.size;
                snprintf(g_updHint, sizeof(g_updHint), "Nueva version %s (L3)", u.name);
                set_status(C_OK, "Hay version nueva %s (tienes %s): %s. Pulsa L3 para bajar el PKG.", u.name, APP_VERSION, u.summary);
            } else {
                g_upd.avail = false;
                g_updHint[0] = 0;
                if (!silent) set_status(C_OK, "McStore %s esta al dia.", APP_VERSION);
            }
        }
    } else if (j->kind == 1) {
        if (j->ok && j->mode == M_GITHUB) {
            if (!A.cat) A.cat = new Item[MAX_ITEMS];
            g_prevN = A.catLoaded ? A.catN : 0;
            if (g_prevN > 0) memcpy(g_prevCat, A.cat, sizeof(Item) * (size_t)g_prevN);
            for (int i = 0; i < j->n; i++) {
                Item &it = j->items[i];
                if (!it.url[0] && it.file[0]) snprintf(it.url, sizeof(it.url), "addons/%s", it.file);
                if (!it.file[0] && it.url[0]) {
                    const char *b = strrchr(it.url, '/');
                    snprintf(it.file, sizeof(it.file), "%s", b ? b + 1 : it.url);
                }
                if (it.url[0]) {
                    char full[420];
                    resolve_url(j->url, it.url, full, sizeof(full));
                    snprintf(it.url, sizeof(it.url), "%s", full);
                }
                A.cat[i] = it;
            }
            int nNew = 0, nUpd = 0;
            bool wasLoaded = A.catLoaded;
            if (!wasLoaded) seen_load();
            // A.cat ya contiene lo nuevo: comparamos contra una copia de lo anterior
            mark_changes(A.cat, j->n, wasLoaded ? g_prevCat : NULL, wasLoaded ? g_prevN : 0, &nNew, &nUpd);
            seen_save(A.cat, j->n);
            A.catN = j->n;
            A.catLoaded = true;
            build_ver_list();
            // Revision automatica sin novedades: no tocamos la lista que el usuario esta viendo.
            if (!(g_catSilent && wasLoaded && nNew + nUpd == 0)) filter_catalog();
            if (wasLoaded) {
                if (nNew + nUpd == 0) {
                    if (!g_catSilent) set_status(C_OK, "Catalogo al dia: %d add-on(s), sin novedades.", A.catN);
                } else set_status(C_OK, "Hay novedades en GitHub: %d nuevo(s), %d actualizado(s). Pulsa L2 para bajarlos.", nNew, nUpd);
            } else if (nNew + nUpd > 0) {
                set_status(C_OK, "Desde la ultima vez: %d nuevo(s), %d actualizado(s).", nNew, nUpd);
            }
        } else if (j->ok) {
            memcpy(A.items, j->items, sizeof(Item) * (size_t)j->n);
            A.n = j->n;
            A.sel = A.top = 0;
            mark_got(A.items, A.n);
            A.page = j->page < 1 ? 1 : j->page;
            A.pages = j->pages < 1 ? 1 : j->pages;
            if (A.n) set_status(C_OK, "Pagina %d de %d. Pulsa X para ver el detalle.", A.page, A.pages);
            else set_status(C_DIM, "No hay resultados para esa busqueda.");
        } else if (g_catSilent && A.catLoaded) {
            // revision automatica fallida (sin internet, etc.): se ignora y se reintenta luego
        } else {
            A.n = 0;
            set_status(C_ERR, "Error: %s", j->err);
        }
    } else {
        if (j->ok) {
            if (g_pkgDl) set_status(C_OK, "PKG nuevo en %s: instalalo desde Debug Settings > Package Installer.", j->finalPath);
            else set_status(C_OK, "Guardado en %s", j->finalPath);
            if (A.mode == M_LAN && !g_pkgDl && g_dlIdx >= 0 && g_dlIdx < A.n) {
                got_set(A.items[g_dlIdx]);
                A.items[g_dlIdx].flag = 3;
                if (!strcmp(g_det.id, A.items[g_dlIdx].id)) g_det.flag = 3;
            } else if (g_dlIdx >= 0 && g_dlIdx < A.n) {
                // ya descargado: quita la marca de nuevo/actualizado
                const char *k = item_key(A.items[g_dlIdx]);
                for (int i = 0; A.cat && i < A.catN; i++)
                    if (!strcmp(item_key(A.cat[i]), k)) A.cat[i].flag = 0;
                A.items[g_dlIdx].flag = 0;
            }
            if (g_bulk) g_bulkDone++;
        } else {
            set_status(C_ERR, "Error: %s", j->err);
            g_bulk = false;
        }
    }
    A.busy = false;
    A.dlName[0] = 0;
    g_pkgDl = false;
    g_busyKind = 0;
    g_catSilent = false;
    g_job = NULL;
    job_release(j);
    if (g_bulk) {
        int nx = next_flagged();
        if (nx >= 0) start_download_idx(nx);
        else {
            g_bulk = false;
            set_status(C_OK, "Listo: %d add-on(s) descargado(s). Pulsa R2 para instalar.", g_bulkDone);
        }
    }
    static bool updAuto = false;
    if (!g_job && !g_bulk && A.scr == S_LIST) {
        if (A.mode == M_LAN && !g_catsTried) {  // categorias para el filtro del teclado
            g_catsTried = true;
            Job *c = job_new(5);
            snprintf(c->path, sizeof(c->path), "/categories");
            A.dlName[0] = 0;
            job_start(c);
        } else if (A.mode == M_GITHUB && A.catLoaded && !updAuto) {  // aviso de version nueva, sin molestar
            updAuto = true;
            g_updSilent = true;
            check_app_update();
            if (!g_job) g_updSilent = false;
        }
    }
}

// Abandona el trabajo actual. El hilo termina solo (o por timeout) y limpia lo suyo.
static void job_cancel() {
    Job *j = g_job;
    if (!j) return;
    j->cancel = true;
    g_bulk = false;
    g_job = NULL;
    g_busyKind = 0;
    A.busy = false;
    A.dlName[0] = 0;
    if (j->kind != 4 && j->kind != 5) set_status(C_DIM, "Cancelado.");
    g_updCheck = false;
    g_updSilent = false;
    g_catSilent = false;
    job_release(j);
}

// ---------- instalacion de packs en Minecraft ----------

struct ScanCtx { PackRow *rows; int n; };
static bool ends_with_ci(const char *s, const char *suf) {
    size_t a = strlen(s), b = strlen(suf);
    if (a < b) return false;
    for (size_t i = 0; i < b; i++) {
        char c = s[a - b + i];
        if (c >= 'A' && c <= 'Z') c = (char)(c + 32);
        if (c != suf[i]) return false;
    }
    return true;
}
static void scan_cb(const char *name, void *ctx) {
    ScanCtx *c = (ScanCtx *)ctx;
    if (c->n >= MAX_PACKS || ends_with_ci(name, ".part")) return;
    PackRow &r = c->rows[c->n];
    memset(&r, 0, sizeof(r));
    snprintf(r.file, sizeof(r.file), "%s", name);
    r.isMcpack = ends_with_ci(name, ".mcpack");
    r.isAddon = ends_with_ci(name, ".mcaddon");
    c->n++;
}

static void install_rescan() {
    if (!I.rows) I.rows = new PackRow[MAX_PACKS];
    char dir[300];
    snprintf(dir, sizeof(dir), "%s/downloads", plat_data_dir());
    ScanCtx c = {I.rows, 0};
    plat_listdir(dir, scan_cb, &c);
    for (int i = 1; i < c.n; i++)  // orden alfabetico (insercion)
        for (int j = i; j > 0 && strcmp(I.rows[j].file, I.rows[j - 1].file) < 0; j--) {
            PackRow t = I.rows[j]; I.rows[j] = I.rows[j - 1]; I.rows[j - 1] = t;
        }
    for (int i = 0; i < c.n; i++) {
        char p[460];
        snprintf(p, sizeof(p), "%s/%s", dir, I.rows[i].file);
        I.rows[i].size = mc_file_size(p);
        if (I.rows[i].isMcpack) mc_pack_inspect(p, &I.rows[i].info);
    }
    I.n = c.n;
    if (I.sel >= I.n) I.sel = I.n ? I.n - 1 : 0;
    if (I.top > I.sel) I.top = I.sel;
}

// Diagnostico: lo que la app realmente ve dentro de /app_tmp (arbol de hasta 4 niveles, recortado).
struct DiagCtx { char *out; size_t cap; int depth; char path[300]; };
static void diag_walk(const char *path, int depth, char *out, size_t cap);
static void diag_cb(const char *name, void *c) {
    DiagCtx *d = (DiagCtx *)c;
    size_t l = strlen(d->out);
    if (l + strlen(name) + 4 >= d->cap) return;
    snprintf(d->out + l, d->cap - l, "%s", name);
    if (d->depth < 4) {
        char sub[300];
        snprintf(sub, sizeof(sub), "%s/%s", d->path, name);
        bool isDir = false; long sz = 0;
        if (plat_stat(sub, &isDir, &sz) && isDir) {
            l = strlen(d->out);
            snprintf(d->out + l, d->cap - l, "/");
            diag_walk(sub, d->depth + 1, d->out, d->cap);
        }
    }
    l = strlen(d->out);
    if (l + 3 < d->cap) snprintf(d->out + l, d->cap - l, " ; ");
}
static void diag_walk(const char *path, int depth, char *out, size_t cap) {
    DiagCtx d; d.out = out; d.cap = cap; d.depth = depth;
    snprintf(d.path, sizeof(d.path), "%s", path);
    if (!plat_listdir(path, diag_cb, &d)) {
        size_t l = strlen(out);
        if (l + 8 < cap) snprintf(out + l, cap - l, "(ilegible)");
    }
}

static void modal_open(int kind, int nlines, ...) {
    I.modal = kind;
    I.nlines = nlines;
    va_list ap;
    va_start(ap, nlines);
    for (int i = 0; i < nlines; i++) snprintf(I.line[i], sizeof(I.line[i]), "%s", va_arg(ap, const char *));
    va_end(ap);
}

static void modal_nogame() {
            static char tree[600];
            tree[0] = 0;
            diag_walk(plat_apptmp_dir(), 1, tree, sizeof(tree));
            char d0[220], d1[220] = "", d2[220] = "", d3[220] = "";
            snprintf(d0, sizeof(d0), "Diagnostico: jailbreak=%d ; juego(id)=%d ; ruta: %s", plat_jb_status(), plat_big_app_id(), plat_apptmp_dir());
            size_t n = strlen(tree);
            if (n == 0) snprintf(d1, sizeof(d1), "%s esta vacia o la app no la ve.", plat_apptmp_dir());
            else {
                snprintf(d1, sizeof(d1), "%.86s", tree);
                if (n > 86) snprintf(d2, sizeof(d2), "%.86s", tree + 86);
                if (n > 172) snprintf(d3, sizeof(d3), "%.86s", tree + 172);
            }
            modal_open(MD_NOGAME, 7, "Minecraft no esta abierto o no veo su carpeta.",
                       "Abrelo hasta el menu, pulsa PS y abre McStore (sin cerrarlo).", "", d0, d1, d2, d3);
}

// Instala de una vez todos los .mcpack de la lista (reemplaza los que ya estan): sirve para "actualizar".
static void install_all() {
    if (I.n == 0) return;
    if (mc_detect(&I.tg) == 0) { modal_nogame(); return; }
    I.modal = MD_NONE;
    I.installing = true;
    render();
    int ok = 0, fail = 0, skip = 0;
    char firstErr[200] = "";
    for (int i = 0; i < I.n; i++) {
        const PackRow &r = I.rows[i];
        if (!r.isMcpack || (r.info.kind != PK_RES && r.info.kind != PK_BEH)) { skip++; continue; }
        char src[460];
        snprintf(src, sizeof(src), "%s/downloads/%s", plat_data_dir(), r.file);
        McInstallResult res;
        mc_install(src, r.file, r.info.kind, &I.tg, &res);
        if (res.ok > 0) ok++;
        else {
            fail++;
            if (!firstErr[0]) snprintf(firstErr, sizeof(firstErr), "%s: %s", r.file, res.err[0] ? res.err : "error desconocido");
        }
    }
    I.installing = false;
    char a[200], b[200];
    snprintf(a, sizeof(a), "Instalados %d pack(s)%s.", ok, skip ? " (se omitieron los que no son .mcpack)" : "");
    if (fail) snprintf(b, sizeof(b), "Fallaron %d. Primero: %s", fail, firstErr);
    else snprintf(b, sizeof(b), "Pulsa TRIANGULO para volver a Minecraft.");
    if (ok > 0) {
        modal_open(MD_DONE, 5, a, "1) Cierra y vuelve a abrir Minecraft para que los packs aparezcan.",
                   "2) Activalos en el mundo (Recursos o Comportamiento).", "Se pierden al cerrar Minecraft o apagar la consola: vuelve a instalar.", b);
        set_status(C_OK, "Instalados %d pack(s)", ok);
    } else {
        modal_open(MD_ERROR, 2, firstErr[0] ? firstErr : "no habia .mcpack validos para instalar", "No se copio nada.");
        set_status(C_ERR, "No se pudo instalar");
    }
}

// Un paso del flujo de instalacion. Cada confirmacion del usuario vuelve a llamar con el salto correspondiente.
static void install_begin(bool skipVersion, bool skipReplace) {
    if (I.n == 0) return;
    const PackRow &r = I.rows[I.sel];
    if (r.isAddon) { set_status(C_DIM, ".mcaddon: soporte pendiente (por ahora solo .mcpack)."); return; }
    if (!r.isMcpack) { set_status(C_DIM, "Formato no soportado: solo .mcpack."); return; }
    if (r.info.kind != PK_RES && r.info.kind != PK_BEH) {
        modal_open(MD_ERROR, 2, r.info.err, "No se copio nada.");
        return;
    }

    // 1) Minecraft abierto? (detecta la ruta cada vez; nada fijo)
    if (mc_detect(&I.tg) == 0) {
        modal_nogame();
        return;
    }

    // 2) El pack pide una version mas nueva que la de la consola?
    I.haveVer = mc_version_load(I.consoleVer);
    if (!skipVersion && I.haveVer && r.info.hasMin && mc_ver_cmp(I.consoleVer, r.info.minEng) < 0) {
        char a[160], b[160];
        snprintf(a, sizeof(a), "Este pack pide Minecraft %d.%d.%d o mas nuevo.", r.info.minEng[0], r.info.minEng[1], r.info.minEng[2]);
        snprintf(b, sizeof(b), "Tu consola tiene %d.%d.%d (mcversion.txt): puede no cargar.", I.consoleVer[0], I.consoleVer[1], I.consoleVer[2]);
        modal_open(MD_VERSION, 2, a, b);
        return;
    }

    // 3) Ya existe?
    if (!skipReplace && mc_already_there(&I.tg, r.info.kind, r.file)) {
        char a[200];
        snprintf(a, sizeof(a), "%s ya esta en %s.", r.file, mc_sub(r.info.kind));
        modal_open(MD_REPLACE, 2, a, "Quieres reemplazarlo?");
        return;
    }

    // 4) Copiar tal cual (.mcpack) a la carpeta que toca segun el manifest
    I.modal = MD_NONE;
    I.installing = true;
    render();  // muestra "Instalando..." antes de empezar a copiar
    char src[460];
    snprintf(src, sizeof(src), "%s/downloads/%s", plat_data_dir(), r.file);
    McInstallResult res;
    mc_install(src, r.file, r.info.kind, &I.tg, &res);
    I.installing = false;

    if (res.ok > 0) {
        char a[200], b[200] = "";
        snprintf(a, sizeof(a), "Copiado en %s de %d carpeta(s) de usuario.", mc_sub(r.info.kind), res.ok);
        if (res.fail) snprintf(b, sizeof(b), "Fallo en %d carpeta(s): %s", res.fail, res.err);
        modal_open(MD_DONE, 5, a, "1) Cierra y vuelve a abrir Minecraft para que el pack aparezca.",
                   "2) Activalo en el mundo (Recursos o Comportamiento).", "Se pierde al cerrar Minecraft o apagar la consola: vuelve a instalar.",
                   b[0] ? b : "Pulsa TRIANGULO para volver a Minecraft.");
        I.resumeOk = true;
        set_status(C_OK, "Instalado: %s", r.file);
    } else {
        modal_open(MD_ERROR, 2, res.err[0] ? res.err : "error desconocido", "No se cambio de metodo: avisame para decidir el siguiente intento.");
        set_status(C_ERR, "No se pudo instalar %s", r.file);
    }
}

// ---------- entrada ----------

static uint32_t g_prev = 0;
static int g_hold[16];

// Devuelve los botones recien pulsados, con repeticion para direcciones y L1/R1.
static uint32_t poll_input() {
    uint32_t cur = plat_buttons();
    uint32_t pressed = cur & ~g_prev;
    const uint32_t repeatable = BTN_UP | BTN_DOWN | BTN_LEFT | BTN_RIGHT | BTN_L1 | BTN_R1;
    for (int i = 0; i < 14; i++) {
        uint32_t bit = 1u << i;
        if (!(cur & bit)) { g_hold[i] = 0; continue; }
        g_hold[i]++;
        if ((repeatable & bit) && g_hold[i] > 24 && (g_hold[i] - 24) % 4 == 0) pressed |= bit;
    }
    g_prev = cur;
    return pressed;
}

static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

static void scroll_to_sel() {
    int r = A.sel / GRID_COLS;
    if (r < A.top) A.top = r;
    if (r >= A.top + GRID_ROWS) A.top = r - GRID_ROWS + 1;
}

static void goto_page(int pg) {
    if (pg < 1 || pg > A.pages || g_job) return;
    A.page = pg;
    start_search(true);
}

static void input_list(uint32_t p) {
    int last = A.n ? A.n - 1 : 0;
    if (p & BTN_RIGHT) { A.sel = clampi(A.sel + 1, 0, last); scroll_to_sel(); }
    if (p & BTN_LEFT) { A.sel = clampi(A.sel - 1, 0, last); scroll_to_sel(); }
    if (p & BTN_DOWN) { A.sel = clampi(A.sel + GRID_COLS, 0, last); scroll_to_sel(); }
    if (p & BTN_UP) { A.sel = clampi(A.sel - GRID_COLS, 0, last); scroll_to_sel(); }
    if (A.mode == M_LAN) {  // L1/R1 cambian de pagina (el servidor devuelve 24 por pagina)
        if (p & BTN_R1) goto_page(A.page + 1);
        if (p & BTN_L1) goto_page(A.page - 1);
    } else {
        if (p & BTN_R1) { A.sel = clampi(A.sel + GRID_COLS * GRID_ROWS, 0, last); scroll_to_sel(); }
        if (p & BTN_L1) { A.sel = clampi(A.sel - GRID_COLS * GRID_ROWS, 0, last); scroll_to_sel(); }
    }
    if (p & BTN_CROSS) open_detail();
    if ((p & BTN_CIRCLE) && A.mode == M_LAN && !g_job) {  // cambia el orden
        A.sort = (A.sort + 1) % 5;
        A.page = 1;
        start_search(true);
    }
    if ((p & BTN_CIRCLE) && A.mode == M_GITHUB) { g_fRow = 0; A.scr = S_FILTER; }  // filtros y tema
    if (p & BTN_L2) start_bulk();
    if (p & BTN_L3) check_app_update();
    if (p & BTN_OPTIONS) start_search(true);
    if (p & BTN_R2) {
        I.modal = MD_NONE;
        install_rescan();
        I.top = 0;
        set_status(C_DIM, "Elige un pack y pulsa X (Minecraft abierto).");
        A.scr = S_INSTALL;
    }
    if (p & BTN_SQUARE) {
        snprintf(A.kbuf, sizeof(A.kbuf), "%s", A.query);
        A.kr = A.kc = 0;
        A.kcat = A.catSel;
        A.scr = S_KEYBOARD;
    }
    if (p & BTN_TRIANGLE) {
        A.edit = A.srv;
        A.editMode = A.mode;
        A.field = 0;
        A.scr = S_SETTINGS;
    }
}

static void input_detail(uint32_t p) {
    if (p & BTN_DOWN) g_dTop = clampi(g_dTop + 1, 0, g_dN > 17 ? g_dN - 17 : 0);
    if (p & BTN_UP) g_dTop = clampi(g_dTop - 1, 0, g_dN > 17 ? g_dN - 17 : 0);
    if (p & BTN_R1) g_dTop = clampi(g_dTop + 12, 0, g_dN > 17 ? g_dN - 17 : 0);
    if (p & BTN_L1) g_dTop = clampi(g_dTop - 12, 0, g_dN > 17 ? g_dN - 17 : 0);
    if ((p & BTN_CROSS) && !g_job) start_download();
    if (p & BTN_R2) {
        if (g_job) job_cancel();
        I.modal = MD_NONE;
        install_rescan();
        I.top = 0;
        set_status(C_DIM, "Elige un pack y pulsa X (Minecraft abierto).");
        A.scr = S_INSTALL;
    }
    if (p & BTN_CIRCLE) {
        if (g_job) job_cancel();
        A.scr = S_LIST;
    }
}

static void delete_downloads(bool all) {
    char dir[300], f[460];
    snprintf(dir, sizeof(dir), "%s/downloads", plat_data_dir());
    int n = 0;
    if (all) {
        for (int i = 0; i < I.n; i++) {
            snprintf(f, sizeof(f), "%s/%s", dir, I.rows[i].file);
            if (remove(f) == 0) n++;
        }
    } else if (I.n > 0) {
        snprintf(f, sizeof(f), "%s/%s", dir, I.rows[I.sel].file);
        if (remove(f) == 0) n++;
    }
    install_rescan();
    if (n == 1) set_status(C_OK, "Borrado.");
    else if (n > 1) set_status(C_OK, "Borrados %d archivos.", n);
    else set_status(C_ERR, "No se pudo borrar.");
}

static void input_install(uint32_t p) {
    if (I.modal != MD_NONE) {
        if (I.modal == MD_DELETE || I.modal == MD_DELALL) {
            if (p & BTN_CROSS) { bool all = I.modal == MD_DELALL; I.modal = MD_NONE; delete_downloads(all); }
            else if (p & BTN_CIRCLE) { I.modal = MD_NONE; set_status(C_DIM, "Cancelado."); }
        } else if (I.modal == MD_VERSION) {
            if (p & BTN_CROSS) { I.modal = MD_NONE; install_begin(true, false); }
            else if (p & BTN_CIRCLE) { I.modal = MD_NONE; set_status(C_DIM, "Cancelado."); }
        } else if (I.modal == MD_REPLACE) {
            if (p & BTN_CROSS) { I.modal = MD_NONE; install_begin(true, true); }
            else if (p & BTN_CIRCLE) { I.modal = MD_NONE; set_status(C_DIM, "Cancelado."); }
        } else if (I.modal == MD_DONE && (p & BTN_TRIANGLE)) {
            I.modal = MD_NONE;
            char cusa[16] = "";
            const char *t = strstr(I.tg.path[0], "CUSA");
            if (t) { snprintf(cusa, sizeof(cusa), "%.9s", t); }
            if (!cusa[0] || plat_resume_game(cusa) != 0) set_status(C_ERR, "No pude volver a Minecraft: usa el menu de la consola.");
        } else if (p & (BTN_CROSS | BTN_CIRCLE)) {
            I.modal = MD_NONE;
        }
        return;
    }
    if (p & BTN_DOWN) { I.sel = clampi(I.sel + 1, 0, I.n ? I.n - 1 : 0); }
    if (p & BTN_UP) { I.sel = clampi(I.sel - 1, 0, I.n ? I.n - 1 : 0); }
    if (p & BTN_R1) { I.sel = clampi(I.sel + LIST_ROWS, 0, I.n ? I.n - 1 : 0); }
    if (p & BTN_L1) { I.sel = clampi(I.sel - LIST_ROWS, 0, I.n ? I.n - 1 : 0); }
    if (I.sel < I.top) I.top = I.sel;
    if (I.sel >= I.top + LIST_ROWS) I.top = I.sel - LIST_ROWS + 1;
    if (p & BTN_OPTIONS) { install_rescan(); set_status(C_DIM, "Lista actualizada."); }
    if (p & BTN_L2) install_all();
    if ((p & BTN_SQUARE) && I.n > 0) modal_open(MD_DELETE, 2, I.rows[I.sel].file, "Se borra de las descargas de McStore (no toca lo ya instalado en Minecraft).");
    if ((p & BTN_TRIANGLE) && I.n > 0) {
        char m[80];
        snprintf(m, sizeof(m), "Se van a borrar los %d archivos de la lista.", I.n);
        modal_open(MD_DELALL, 2, m, "No se puede deshacer. Podras volver a bajarlos desde el catalogo.");
    }
    if (p & BTN_CROSS) install_begin(false, false);
    if (p & BTN_CIRCLE) A.scr = S_LIST;
}

static void input_filter(uint32_t p) {
    if (p & BTN_DOWN) g_fRow = clampi(g_fRow + 1, 0, 2);
    if (p & BTN_UP) g_fRow = clampi(g_fRow - 1, 0, 2);
    int d = ((p & BTN_RIGHT) ? 1 : 0) - ((p & BTN_LEFT) ? 1 : 0);
    if (d) {
        if (g_fRow == 0) g_fType = (g_fType + 4 + d) % 4;
        else if (g_fRow == 1) {
            int idx = -1;  // -1 = todas
            for (int i = 0; i < g_verN; i++) if (!strcmp(g_verList[i], g_fVer)) idx = i;
            if (g_verN > 0) {
                idx += d;
                if (idx < -1) idx = g_verN - 1;
                if (idx >= g_verN) idx = -1;
            }
            snprintf(g_fVer, sizeof(g_fVer), "%s", idx < 0 ? "" : g_verList[idx]);
        } else apply_theme((g_theme + NTHEMES + d) % NTHEMES);
    }
    if (p & BTN_TRIANGLE) { g_fType = 0; g_fVer[0] = 0; }
    if (p & (BTN_CROSS | BTN_CIRCLE)) {
        ui_save();
        filter_catalog();
        A.scr = S_LIST;
    }
}

static void input_keyboard(uint32_t p) {
    if (p & BTN_RIGHT) A.kc = (A.kc + 1) % 10;
    if (p & BTN_LEFT) A.kc = (A.kc + 9) % 10;
    if (p & BTN_DOWN) A.kr = (A.kr + 1) % 4;
    if (p & BTN_UP) A.kr = (A.kr + 3) % 4;
    size_t l = strlen(A.kbuf);
    if ((p & BTN_CROSS) && l + 1 < sizeof(A.kbuf)) { A.kbuf[l] = KB_ROWS[A.kr][A.kc]; A.kbuf[l + 1] = 0; }
    if ((p & BTN_TRIANGLE) && l + 1 < sizeof(A.kbuf)) { A.kbuf[l] = ' '; A.kbuf[l + 1] = 0; }
    if ((p & BTN_SQUARE) && l > 0) A.kbuf[l - 1] = 0;
    if (g_catN > 1 && A.mode == M_LAN) {
        if (p & BTN_R1) A.kcat = (A.kcat + 1) % g_catN;
        if (p & BTN_L1) A.kcat = (A.kcat + g_catN - 1) % g_catN;
    }
    if (p & BTN_CIRCLE) A.scr = S_LIST;
    if (p & BTN_OPTIONS) {
        A.catSel = A.kcat;
        snprintf(A.query, sizeof(A.query), "%s", A.kbuf);
        A.scr = S_LIST;
        A.page = 1;
        start_search();
    }
}

static void input_settings(uint32_t p) {
    if (p & BTN_RIGHT) A.field = clampi(A.field + 1, 0, 5);
    if (p & BTN_LEFT) A.field = clampi(A.field - 1, 0, 5);
    if (A.field == 0) {
        if (p & (BTN_UP | BTN_DOWN | BTN_L1 | BTN_R1)) A.editMode = (A.editMode == M_GITHUB) ? M_LAN : M_GITHUB;
    } else {
        int idx = A.field - 1;  // 0..3 = octetos, 4 = puerto
        int step = 0;
        if (p & BTN_UP) step += 1;
        if (p & BTN_DOWN) step -= 1;
        if (p & BTN_R1) step += (idx == 4 ? 100 : 10);
        if (p & BTN_L1) step -= (idx == 4 ? 100 : 10);
        if (step) {
            if (idx < 4) A.edit.ip[idx] = clampi(A.edit.ip[idx] + step, 0, 255);
            else A.edit.port = clampi(A.edit.port + step, 1, 65535);
        }
    }
    if (p & BTN_CIRCLE) A.scr = S_LIST;
    if (p & BTN_CROSS) {
        A.srv = A.edit;
        A.mode = A.editMode;
        config_save();
        A.scr = S_LIST;
        A.catLoaded = false;
        A.n = 0;
        A.page = 1;
        A.catSel = 0;
        g_catsTried = false;
        g_catN = 0;
        start_search(true);
    }
}

// ---------- main ----------

int main(void) {
    apply_theme(0);
    (void)C_BAR;

    memset(&A, 0, sizeof(A));
    A.srv.ip[0] = 192; A.srv.ip[1] = 168; A.srv.ip[2] = 1; A.srv.ip[3] = 100;
    A.srv.port = 8080;
    A.mode = M_GITHUB;
    A.page = A.pages = 1;
    A.statusCol = C_DIM;

    if (!plat_init()) {
        // Sin video no hay nada que mostrar.
        for (;;) plat_sleep_ms(1000);
    }

    mkdir_p(plat_data_dir());
    ui_load();  // filtros y tema guardados
    pkg_cleanup();
    A.statusCol = C_DIM;
    got_load();
    config_load();
    source_load();
    A.scr = S_LIST;
    start_search();
    uint64_t lastAuto = plat_ms();

    for (;;) {
        uint32_t p = poll_input();
        job_poll();
        // Cada AUTO_CHECK_MS, con la lista abierta y sin nada en curso, mira GitHub en silencio.
        if (!g_job && !g_bulk && !A.busy && A.scr == S_LIST && A.mode == M_GITHUB && A.catLoaded &&
            plat_ms() - lastAuto > AUTO_CHECK_MS) {
            lastAuto = plat_ms();
            g_catSilent = true;
            start_search(true);
            if (!g_job) g_catSilent = false;
        }
        if (A.busy && !quiet_job()) {
            if (p & BTN_CIRCLE) job_cancel();
        } else if (A.scr == S_FILTER) input_filter(p);
        else if (A.scr == S_DETAIL) input_detail(p);
        else if (A.scr == S_LIST) input_list(p);
        else if (A.scr == S_KEYBOARD) input_keyboard(p);
        else if (A.scr == S_INSTALL) input_install(p);
        else input_settings(p);
        render();
    }
    return 0;
}
