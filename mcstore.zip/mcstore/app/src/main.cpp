// McStore: busca y descarga add-ons (.mcpack/.mcaddon/.mcworld).
// Fuentes: catalogo en GitHub (HTTPS, sin PC) o servidor propio en la red local.
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/stat.h>
#include <atomic>
#include <thread>

#include "platform.h"
#include "gfx.h"
#include "net.h"
#include "install.h"

#define MAX_ITEMS 200
#define MAX_JSON (512 * 1024)

// Lo define el Makefile con tu repositorio de GitHub; se puede cambiar con /data/mcstore/source.txt
#ifndef APP_VERSION
#define APP_VERSION "1.00"
#endif
#ifndef CATALOG_URL
#define CATALOG_URL "https://raw.githubusercontent.com/OWNER/REPO/main/catalog.json"
#endif

enum Screen { S_LIST, S_KEYBOARD, S_SETTINGS, S_INSTALL };
enum Mode { M_GITHUB = 0, M_LAN = 1 };

// Colores
static uint32_t C_BG, C_PANEL, C_SEL, C_TEXT, C_DIM, C_ACCENT, C_OK, C_ERR, C_BAR;

struct App {
    Screen scr;
    Server srv;
    int mode;
    char catalogUrl[300];
    Item *cat;
    int catN;
    bool catLoaded;
    Item items[MAX_ITEMS];
    int n, sel, top;
    char query[40];
    char status[260];
    uint32_t statusCol;
    bool busy;
    uint64_t jobStart;
    // descarga en curso
    char dlName[96];
    long dlDone, dlTotal;
    // teclado
    int kr, kc;
    char kbuf[40];
    // ajustes
    int field;
    Server edit;
    int editMode;
};

static App A;

// ---------- pantalla "Instalar en Minecraft" ----------
#define MAX_PACKS 120
struct PackRow {
    char file[128];
    long size;
    bool isMcpack, isAddon;
    McPack info;  // solo para .mcpack
};
enum Modal { MD_NONE, MD_NOGAME, MD_VERSION, MD_REPLACE, MD_DONE, MD_ERROR };
struct Inst {
    PackRow *rows;
    int n, sel, top;
    int modal;
    char line[8][220];
    int nlines;
    McTargets tg;
    int consoleVer[3];
    bool haveVer;
    bool installing; bool resumeOk;
};
static Inst I;

static const char *KB_ROWS[4] = {"abcdefghij", "klmnopqrst", "uvwxyz0123", "456789'-_."};

// ---------- utilidades ----------

static void mkdir_p(const char *dir) {
    char tmp[256];
    snprintf(tmp, sizeof(tmp), "%s", dir);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') { *p = 0; mkdir(tmp, 0777); *p = '/'; }
    }
    mkdir(tmp, 0777);
}

static void set_status(uint32_t col, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
static void set_status(uint32_t col, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(A.status, sizeof(A.status), fmt, ap);
    va_end(ap);
    A.statusCol = col;
}

static void fmt_size(long b, char *out, size_t cap) {
    if (b <= 0) snprintf(out, cap, "?");
    else if (b < 1024) snprintf(out, cap, "%ld B", b);
    else if (b < 1024 * 1024) snprintf(out, cap, "%.1f KB", b / 1024.0);
    else snprintf(out, cap, "%.1f MB", b / 1048576.0);
}

// ---------- configuración ----------

static void config_path(char *out, size_t cap) { snprintf(out, cap, "%s/config.txt", plat_data_dir()); }

static bool config_load() {
    char p[300];
    config_path(p, sizeof(p));
    FILE *f = fopen(p, "r");
    if (!f) return false;
    int a, b, c, d, port, mode = 0;
    int k = fscanf(f, "%d.%d.%d.%d:%d %d", &a, &b, &c, &d, &port, &mode);
    fclose(f);
    if (k < 5) return false;
    A.srv.ip[0] = a; A.srv.ip[1] = b; A.srv.ip[2] = c; A.srv.ip[3] = d; A.srv.port = port;
    A.mode = (k >= 6 && mode == M_LAN) ? M_LAN : M_GITHUB;
    return true;
}

static void config_save() {
    char p[300];
    mkdir_p(plat_data_dir());
    config_path(p, sizeof(p));
    FILE *f = fopen(p, "w");
    if (!f) { set_status(C_ERR, "No se pudo guardar la configuracion en %s", p); return; }
    fprintf(f, "%d.%d.%d.%d:%d\n%d\n", A.srv.ip[0], A.srv.ip[1], A.srv.ip[2], A.srv.ip[3], A.srv.port, A.mode);
    fclose(f);
}

// Catalogo: el del Makefile, o el de /data/mcstore/source.txt (primera linea) si existe.
static void source_load() {
    snprintf(A.catalogUrl, sizeof(A.catalogUrl), "%s", CATALOG_URL);
    char p[300];
    snprintf(p, sizeof(p), "%s/source.txt", plat_data_dir());
    FILE *f = fopen(p, "r");
    if (!f) return;
    char line[300];
    if (fgets(line, sizeof(line), f)) {
        size_t l = strlen(line);
        while (l && (line[l - 1] == '\n' || line[l - 1] == '\r' || line[l - 1] == ' ')) line[--l] = 0;
        if (!strncmp(line, "http", 4)) snprintf(A.catalogUrl, sizeof(A.catalogUrl), "%s", line);
    }
    fclose(f);
}

// ---------- dibujo ----------

static void draw_header(const char *title) {
    fill(0, 0, SCREEN_W, 90, C_PANEL);
    fill(0, 88, SCREEN_W, 2, C_ACCENT);
    text(40, 28, title, 3, C_ACCENT);
    char s[96];
    if (A.mode == M_GITHUB) snprintf(s, sizeof(s), "Fuente: GitHub");
    else snprintf(s, sizeof(s), "Fuente: PC %d.%d.%d.%d:%d", A.srv.ip[0], A.srv.ip[1], A.srv.ip[2], A.srv.ip[3], A.srv.port);
    text(SCREEN_W - 40 - text_w(s, 2), 30, s, 2, C_DIM);
}

static void draw_footer(const char *hints) {
    fill(0, SCREEN_H - 120, SCREEN_W, 120, C_PANEL);
    fill(0, SCREEN_H - 120, SCREEN_W, 2, C_ACCENT);
    text(40, SCREEN_H - 108, A.status, 2, A.statusCol, 110);
    text(40, SCREEN_H - 52, hints, 2, C_DIM, 110);
}

#define ROW_H 46
#define LIST_Y 190
#define LIST_ROWS 15

static bool g_updCheck = false;  // true mientras se busca una version nueva de la app

static void draw_list() {
    draw_header("McStore - Add-ons");

    char q[80];
    snprintf(q, sizeof(q), "Busqueda: %s", A.query[0] ? A.query : "(todo el catalogo)");
    text(40, 108, q, 2, C_TEXT, 90);
    char cnt[48];
    snprintf(cnt, sizeof(cnt), "%d resultados", A.n);
    text(SCREEN_W - 40 - text_w(cnt, 2), 108, cnt, 2, C_DIM);

    if (A.n == 0 && !A.busy) {
        if (A.mode == M_GITHUB && A.catLoaded && A.catN == 0)
            text(60, LIST_Y + 20, "El catalogo esta vacio: agrega add-ons a catalog.json en tu repositorio.", 2, C_DIM);
        else
            text(60, LIST_Y + 20, "Sin resultados. Cuadrado: buscar | Triangulo: ajustes", 2, C_DIM);
    }
    for (int i = 0; i < LIST_ROWS; i++) {
        int idx = A.top + i;
        if (idx >= A.n) break;
        int y = LIST_Y + i * ROW_H;
        bool sel = idx == A.sel;
        if (sel) fill(30, y - 4, SCREEN_W - 60, ROW_H - 2, C_SEL);
        int nx = 50;
        if (A.items[idx].flag) {
            const char *tg = A.items[idx].flag == 1 ? "[NUEVO] " : "[ACTUALIZADO] ";
            text(nx, y + 4, tg, 2, A.items[idx].flag == 1 ? C_OK : C_ACCENT);
            nx += (int)strlen(tg) * 16;
        }
        text(nx, y + 4, A.items[idx].name, 2, sel ? C_TEXT : C_DIM, 66);
        char sz[24], right[160];
        fmt_size(A.items[idx].size, sz, sizeof(sz));
        snprintf(right, sizeof(right), "%s  %s", A.items[idx].file, sz);
        int maxc = 44;
        int len = (int)strlen(right);
        text(SCREEN_W - 50 - (len > maxc ? maxc : len) * 16, y + 4, right, 2, C_DIM, maxc);
    }
    // detalle del seleccionado
    if (A.n > 0) {
        int y = LIST_Y + LIST_ROWS * ROW_H + 6;
        text(50, y, A.items[A.sel].summary, 2, C_DIM, 114);
    }

    // barra de scroll
    if (A.n > LIST_ROWS) {
        int h = LIST_ROWS * ROW_H;
        int bh = h * LIST_ROWS / A.n;
        if (bh < 30) bh = 30;
        int by = LIST_Y + (h - bh) * A.top / (A.n - LIST_ROWS);
        fill(SCREEN_W - 22, LIST_Y, 8, h, C_PANEL);
        fill(SCREEN_W - 22, by, 8, bh, C_ACCENT);
    }

    // ventana de trabajo en curso (busqueda o descarga)
    if (A.busy) {
        int w = 1300, h = 240, x = (SCREEN_W - w) / 2, y = (SCREEN_H - h) / 2;
        fill(x - 4, y - 4, w + 8, h + 8, C_ACCENT);
        fill(x, y, w, h, C_PANEL);
        unsigned long secs = (unsigned long)((plat_ms() - A.jobStart) / 1000);
        char s[160];
        if (A.dlName[0]) {
            text(x + 40, y + 30, "Descargando", 2, C_ACCENT);
            text(x + 40, y + 70, A.dlName, 2, C_TEXT, 70);
            int bx = x + 40, by = y + 120, bw = w - 80, bh = 30;
            fill(bx, by, bw, bh, C_BG);
            if (A.dlTotal > 0) fill(bx, by, (int)((long long)bw * A.dlDone / A.dlTotal), bh, C_OK);
            char a1[24], b1[24];
            fmt_size(A.dlDone, a1, sizeof(a1));
            fmt_size(A.dlTotal, b1, sizeof(b1));
            snprintf(s, sizeof(s), "%s / %s   %lus   (Circulo: cancelar)", a1, b1, secs);
            text(bx, by + 50, s, 2, C_DIM);
        } else {
            if (A.mode == M_GITHUB) {
                text(x + 40, y + 30, g_updCheck ? "Buscando actualizacion de McStore..." : "Cargando catalogo...", 2, C_ACCENT);
                snprintf(s, sizeof(s), "Conectando con GitHub   %lus", secs);
            } else {
                text(x + 40, y + 30, "Buscando...", 2, C_ACCENT);
                snprintf(s, sizeof(s), "Conectando con %d.%d.%d.%d:%d   %lus", A.srv.ip[0], A.srv.ip[1], A.srv.ip[2], A.srv.ip[3], A.srv.port, secs);
            }
            text(x + 40, y + 80, s, 2, C_TEXT);
            text(x + 40, y + 130, "Circulo: cancelar", 2, C_DIM);
            if (secs >= 6)
                text(x + 40, y + 175, A.mode == M_GITHUB ? "Tarda mucho: revisa tu conexion a internet." : "Tarda mucho: revisa la IP (cancela y pulsa Triangulo).", 2, C_ERR, 70);
        }
    }

    draw_footer("X: descargar | L2: bajar novedades | Options: buscar novedades | L3: update de la app | R2: instalar | Triangulo: ajustes");
}

static void draw_keyboard() {
    draw_header("Buscar");
    char q[80];
    snprintf(q, sizeof(q), "%s_", A.kbuf);
    fill(300, 150, 1320, 70, C_PANEL);
    text(330, 168, q, 3, C_TEXT, 40);

    int cell = 100, gx = (SCREEN_W - 10 * cell) / 2, gy = 290;
    for (int r = 0; r < 4; r++) {
        for (int c = 0; c < 10; c++) {
            int x = gx + c * cell, y = gy + r * (cell + 10);
            bool sel = (r == A.kr && c == A.kc);
            fill(x, y, cell - 8, cell, sel ? C_ACCENT : C_PANEL);
            char ch[2] = {KB_ROWS[r][c], 0};
            text(x + (cell - 8 - 24) / 2, y + (cell - 48) / 2, ch, 3, sel ? C_BG : C_TEXT);
        }
    }
    draw_footer("X: escribir | Cuadrado: borrar | Triangulo: espacio | Options: buscar | Circulo: cancelar");
}

static void draw_settings() {
    draw_header("Ajustes");
    text(200, 140, "Fuente de add-ons:", 2, C_TEXT);
    bool selMode = A.field == 0;
    fill(200, 185, 1000, 80, selMode ? C_ACCENT : C_PANEL);
    text(230, 205, A.editMode == M_GITHUB ? "GitHub (sin PC, por internet)" : "PC en mi red (server.py)", 3, selMode ? C_BG : C_TEXT);

    uint32_t lbl = A.editMode == M_LAN ? C_TEXT : C_DIM;
    text(200, 320, "Direccion del PC (solo para la fuente PC):", 2, lbl);
    int x = 200, y = 370;
    for (int i = 0; i < 5; i++) {
        char s[16];
        int v = i < 4 ? A.edit.ip[i] : A.edit.port;
        snprintf(s, sizeof(s), "%d", v);
        int w = i < 4 ? 180 : 260;
        bool sel = (i + 1) == A.field;
        fill(x, y, w, 100, sel ? C_ACCENT : C_PANEL);
        text(x + (w - text_w(s, 4)) / 2, y + 18, s, 4, sel ? C_BG : lbl);
        x += w + 10;
        if (i < 3) { text(x - 8, y + 36, ".", 4, C_DIM); }
        if (i == 3) { text(x - 8, y + 36, ":", 4, C_DIM); }
        x += 24;
    }
    text(200, 520, "Izquierda/Derecha: elegir campo   Arriba/Abajo: cambiar   L1/R1: +-10 (puerto: +-100)", 2, C_DIM);
    text(200, 560, "GitHub: lee catalog.json de tu repositorio. PC: usa server.py en tu red.", 2, C_DIM);
    draw_footer("X: guardar | Circulo: cancelar");
}

static const char *pack_kind_label(const PackRow &r, uint32_t *col) {
    *col = C_DIM;
    if (r.isAddon) return ".mcaddon (pendiente)";
    if (!r.isMcpack) return "formato no soportado";
    if (r.info.kind == PK_RES) { *col = C_OK; return "Texturas -> resource_packs"; }
    if (r.info.kind == PK_BEH) { *col = C_OK; return "Comportamiento -> behavior_packs"; }
    *col = C_ERR;
    return "no instalable";
}

static void draw_install() {
    draw_header("McStore - Instalar en Minecraft");
    char d[300];
    snprintf(d, sizeof(d), "Descargas: %s/downloads   (Minecraft debe estar abierto)", plat_data_dir());
    text(40, 108, d, 2, C_TEXT, 100);
    char cnt[48];
    snprintf(cnt, sizeof(cnt), "%d archivo(s)", I.n);
    text(SCREEN_W - 40 - text_w(cnt, 2), 108, cnt, 2, C_DIM);

    if (I.n == 0) text(60, LIST_Y + 20, "No hay archivos descargados. Vuelve (Circulo) y descarga uno con X.", 2, C_DIM);
    for (int i = 0; i < LIST_ROWS; i++) {
        int idx = I.top + i;
        if (idx >= I.n) break;
        const PackRow &r = I.rows[idx];
        int y = LIST_Y + i * ROW_H;
        bool sel = idx == I.sel;
        if (sel) fill(30, y - 4, SCREEN_W - 60, ROW_H - 2, C_SEL);
        text(50, y + 4, r.file, 2, sel ? C_TEXT : C_DIM, 52);
        uint32_t col;
        const char *k = pack_kind_label(r, &col);
        char sz[24];
        fmt_size(r.size, sz, sizeof(sz));
        char right[96];
        snprintf(right, sizeof(right), "%s  %s", k, sz);
        text(SCREEN_W - 50 - (int)strlen(right) * 16, y + 4, right, 2, col, 60);
    }
    if (I.n > 0) {
        const PackRow &r = I.rows[I.sel];
        char s[300] = "";
        if (r.isMcpack && r.info.kind != PK_BAD) {
            if (r.info.hasMin) snprintf(s, sizeof(s), "%s  |  Requiere Minecraft %d.%d.%d o mas nuevo", r.info.name[0] ? r.info.name : "(sin nombre)", r.info.minEng[0], r.info.minEng[1], r.info.minEng[2]);
            else snprintf(s, sizeof(s), "%s  |  Sin min_engine_version", r.info.name[0] ? r.info.name : "(sin nombre)");
        } else if (r.isMcpack) {
            snprintf(s, sizeof(s), "%s", r.info.err);
        } else if (r.isAddon) {
            snprintf(s, sizeof(s), "Los .mcaddon traen varios packs: el soporte llega mas adelante.");
        }
        text(50, LIST_Y + LIST_ROWS * ROW_H + 6, s, 2, (r.isMcpack && r.info.kind == PK_BAD) ? C_ERR : C_DIM, 114);
    }

    if (I.installing) {
        int w = 1100, h = 160, x = (SCREEN_W - w) / 2, y = (SCREEN_H - h) / 2;
        fill(x - 4, y - 4, w + 8, h + 8, C_ACCENT);
        fill(x, y, w, h, C_PANEL);
        text(x + 40, y + 55, "Instalando... no apagues la consola", 3, C_TEXT);
    } else if (I.modal != MD_NONE) {
        int w = 1500, h = 120 + I.nlines * 44 + 70, x = (SCREEN_W - w) / 2, y = (SCREEN_H - h) / 2 - 40;
        uint32_t edge = (I.modal == MD_DONE) ? C_OK : (I.modal == MD_NOGAME || I.modal == MD_ERROR) ? C_ERR : C_ACCENT;
        fill(x - 4, y - 4, w + 8, h + 8, edge);
        fill(x, y, w, h, C_PANEL);
        static const char *titles[] = {"", "Minecraft no esta abierto", "Version de Minecraft", "El pack ya existe", "Listo", "No se pudo instalar"};
        text(x + 40, y + 28, titles[I.modal], 3, edge);
        for (int i = 0; i < I.nlines; i++) text(x + 40, y + 100 + i * 44, I.line[i], 2, C_TEXT, 88);
        const char *hint = (I.modal == MD_VERSION) ? "X: instalar igual | Circulo: cancelar"
                         : (I.modal == MD_REPLACE) ? "X: reemplazar | Circulo: cancelar"
                         : (I.modal == MD_DONE) ? "Triangulo: volver a Minecraft | X o Circulo: cerrar"
                                                   : "X o Circulo: cerrar";
        text(x + 40, y + h - 56, hint, 2, C_DIM);
    }
    draw_footer("X: instalar | L2: instalar todos (actualizar) | Options: actualizar lista | Circulo: volver");
}

static void render() {
    gfx_begin();
    fill(0, 0, SCREEN_W, SCREEN_H, C_BG);
    if (A.scr == S_LIST) draw_list();
    else if (A.scr == S_KEYBOARD) draw_keyboard();
    else if (A.scr == S_INSTALL) draw_install();
    else draw_settings();
    plat_present();
}

// ---------- trabajos de red (en un hilo, para no congelar la pantalla) ----------

struct Job {
    std::atomic<int> refs;       // 2: hilo de red + hilo principal; el ultimo lo libera
    std::atomic<int> finished;
    std::atomic<bool> cancel;
    std::atomic<long> done, total;
    int kind;                    // 1 = buscar, 2 = descargar
    int mode;                    // M_GITHUB o M_LAN
    char url[420];               // modo GitHub: URL completa
    Server srv;
    char path[320];
    char finalPath[400];
    int ok;
    char err[200];
    Item *items;
    int n;
};
static Job *g_job = NULL;
static Item g_prevCat[MAX_ITEMS];  // catalogo anterior, para detectar novedades al actualizar
static int g_prevN = 0;

static void job_release(Job *j) {
    if (j->refs.fetch_sub(1) == 1) {
        delete[] j->items;
        delete j;
    }
}

static bool job_progress(long done, long total, void *ctx) {
    Job *j = (Job *)ctx;
    j->done = done;
    j->total = total;
    return !j->cancel.load();
}

static void job_main(Job *j) {
    if (j->kind == 1 || j->kind == 3) {
        char *json = NULL;
        long len = 0;
        int st = (j->mode == M_GITHUB)
                     ? fetch(j->url, &json, &len, MAX_JSON, NULL, job_progress, j, j->err, sizeof(j->err))
                     : http_get(j->srv, j->path, &json, &len, MAX_JSON, NULL, job_progress, j, j->err, sizeof(j->err));
        if (st == 200) {
            j->items = new Item[MAX_ITEMS];
            j->n = parse_items(json, j->items, MAX_ITEMS);
            j->ok = 1;
        }
        free(json);
    } else {
        char part[420];
        snprintf(part, sizeof(part), "%s.part", j->finalPath);
        FILE *fp = fopen(part, "wb");
        if (!fp) {
            snprintf(j->err, sizeof(j->err), "No se pudo crear %s", part);
        } else {
            int st = (j->mode == M_GITHUB)
                         ? fetch(j->url, NULL, NULL, 0, fp, job_progress, j, j->err, sizeof(j->err))
                         : http_get(j->srv, j->path, NULL, NULL, 0, fp, job_progress, j, j->err, sizeof(j->err));
            fclose(fp);
            if (st != 200) {
                remove(part);
            } else {
                remove(j->finalPath);
                if (rename(part, j->finalPath) == 0) j->ok = 1;
                else snprintf(j->err, sizeof(j->err), "No se pudo renombrar a %s", j->finalPath);
            }
        }
    }
    j->finished = 1;
    job_release(j);
}

static Job *job_new(int kind) {
    Job *j = new Job();
    j->refs = 2;
    j->finished = 0;
    j->cancel = false;
    j->done = 0;
    j->total = 0;
    j->kind = kind;
    j->mode = A.mode;
    j->url[0] = 0;
    j->srv = A.srv;
    j->path[0] = 0;
    j->finalPath[0] = 0;
    j->ok = 0;
    j->err[0] = 0;
    j->items = NULL;
    j->n = 0;
    return j;
}

static void job_start(Job *j) {
    g_job = j;
    A.busy = true;
    A.jobStart = plat_ms();
    try {
        std::thread(job_main, j).detach();
    } catch (...) {
        g_job = NULL;
        A.busy = false;
        A.dlName[0] = 0;
        set_status(C_ERR, "No se pudo iniciar el hilo de red");
        job_release(j);
        job_release(j);
    }
}

static void lower_in_place(char *t) {
    for (; *t; t++) if (*t >= 'A' && *t <= 'Z') *t = (char)(*t + 32);
}

// Copia a la lista los add-ons del catalogo que coinciden con la busqueda (sin usar la red).
static void filter_catalog() {
    char q[48];
    snprintf(q, sizeof(q), "%s", A.query);
    lower_in_place(q);
    A.n = 0;
    for (int i = 0; i < A.catN && A.n < MAX_ITEMS; i++) {
        char hay[320];
        snprintf(hay, sizeof(hay), "%s %s", A.cat[i].name, A.cat[i].summary);
        lower_in_place(hay);
        if (!q[0] || strstr(hay, q)) A.items[A.n++] = A.cat[i];
    }
    A.sel = A.top = 0;
    if (A.catN == 0) set_status(C_DIM, "El catalogo esta vacio (agrega add-ons a catalog.json en tu repositorio).");
    else if (A.n == 0) set_status(C_DIM, "No hay resultados para esa busqueda.");
    else set_status(C_OK, "%d add-on(s). Pulsa X para descargar.", A.n);
}

// ---------- novedades del catalogo (nuevo / actualizado) ----------
// Se compara con el catalogo anterior (en memoria) o, al abrir la app, con la lista guardada de la ultima vez.
struct Seen { char key[96]; long size; };
static Seen g_seen[MAX_ITEMS];
static int g_seenN = 0;
static bool g_seenHave = false;

static const char *item_key(const Item &it) { return it.file[0] ? it.file : it.name; }

static void seen_path(char *out, size_t cap) { snprintf(out, cap, "%s/catalog_seen.txt", plat_data_dir()); }

static void seen_load() {
    g_seenN = 0;
    g_seenHave = false;
    char p[300];
    seen_path(p, sizeof(p));
    FILE *f = fopen(p, "r");
    if (!f) return;
    g_seenHave = true;
    char line[200];
    while (g_seenN < MAX_ITEMS && fgets(line, sizeof(line), f)) {
        char *bar = strrchr(line, '|');
        if (!bar) continue;
        *bar = 0;
        snprintf(g_seen[g_seenN].key, sizeof(g_seen[g_seenN].key), "%s", line);
        g_seen[g_seenN].size = atol(bar + 1);
        g_seenN++;
    }
    fclose(f);
}

static void seen_save(const Item *c, int n) {
    char p[300];
    seen_path(p, sizeof(p));
    FILE *f = fopen(p, "w");
    if (!f) return;
    for (int i = 0; i < n; i++) fprintf(f, "%s|%ld\n", item_key(c[i]), c[i].size);
    fclose(f);
}

// Marca cada item de `fresh` como nuevo/actualizado y devuelve cuantos hay de cada uno.
static void mark_changes(Item *fresh, int n, const Item *old, int oldN, int *nNew, int *nUpd) {
    *nNew = *nUpd = 0;
    bool haveBase = oldN > 0 || g_seenHave;
    for (int i = 0; i < n; i++) {
        Item &it = fresh[i];
        it.flag = 0;
        if (!haveBase) continue;  // primera vez: no marcar todo como nuevo
        const char *k = item_key(it);
        bool found = false;
        long oldSize = 0;
        unsigned char oldFlag = 0;
        if (oldN > 0) {
            for (int j = 0; j < oldN; j++)
                if (!strcmp(item_key(old[j]), k)) { found = true; oldSize = old[j].size; oldFlag = old[j].flag; break; }
        } else {
            for (int j = 0; j < g_seenN; j++)
                if (!strcmp(g_seen[j].key, k)) { found = true; oldSize = g_seen[j].size; break; }
        }
        if (!found) it.flag = 1;
        else if (it.size > 0 && oldSize > 0 && it.size != oldSize) it.flag = 2;
        else it.flag = oldFlag;  // conserva la marca de antes dentro de la misma sesion
        if (it.flag == 1) (*nNew)++;
        else if (it.flag == 2) (*nUpd)++;
    }
}

static void start_search(bool reload = false) {
    if (g_job) return;
    if (A.mode == M_GITHUB && A.catLoaded && !reload) { filter_catalog(); return; }
    Job *j = job_new(1);
    if (A.mode == M_GITHUB) {
        snprintf(j->url, sizeof(j->url), "%s", A.catalogUrl);
        set_status(C_TEXT, "Cargando catalogo...");
    } else {
        char enc[160];
        urlenc(A.query, enc, sizeof(enc));
        snprintf(j->path, sizeof(j->path), "/search?q=%s", enc);
        set_status(C_TEXT, "Buscando...");
    }
    A.dlName[0] = 0;
    job_start(j);
}

static bool g_bulk = false;
static int g_bulkTotal = 0, g_bulkDone = 0;
static int g_dlIdx = -1;  // indice (en A.items) de la descarga en curso

// ---------- actualizacion de la propia app (app_update.json junto a catalog.json) ----------
// Formato: [{"name":"1.01","summary":"que cambia","url":"McStore.pkg","size":123456}]
struct AppUpd { bool avail; char ver[32]; char url[420]; long size; };
static AppUpd g_upd = {false, "", "", 0};
static bool g_pkgDl = false;  // true si la descarga en curso es el PKG de la app

static void check_app_update() {
    if (g_job) return;
    if (A.mode != M_GITHUB) { set_status(C_DIM, "La actualizacion de la app solo funciona con la fuente GitHub."); return; }
    if (g_upd.avail) {
        // segunda pulsacion: bajar el PKG nuevo a /data/pkg (se instala luego desde Debug Settings > Package Installer)
        mkdir_p("/data/pkg");
        Job *j = job_new(2);
        snprintf(j->finalPath, sizeof(j->finalPath), "/data/pkg/McStore-%s.pkg", g_upd.ver);
        snprintf(j->url, sizeof(j->url), "%s", g_upd.url);
        snprintf(A.dlName, sizeof(A.dlName), "McStore %s (PKG)", g_upd.ver);
        A.dlDone = 0;
        A.dlTotal = g_upd.size;
        g_bulk = false;
        g_dlIdx = -1;
        g_pkgDl = true;
        set_status(C_TEXT, "Descargando McStore %s...", g_upd.ver);
        job_start(j);
        return;
    }
    Job *j = job_new(3);
    resolve_url(A.catalogUrl, "app_update.json", j->url, sizeof(j->url));
    A.dlName[0] = 0;
    g_updCheck = true;
    set_status(C_TEXT, "Buscando actualizacion de McStore...");
    job_start(j);
}

// Descarga en cadena de todo lo marcado [NUEVO] / [ACTUALIZADO] (boton L2).

static int next_flagged() {
    for (int i = 0; i < A.n; i++)
        if (A.items[i].flag && A.items[i].url[0]) return i;
    return -1;
}

static void start_download_idx(int idx) {
    if (g_job || idx < 0 || idx >= A.n) return;
    const Item &it = A.items[idx];
    if (A.mode == M_GITHUB && !it.url[0]) {
        set_status(C_ERR, "Esta entrada no tiene \"url\" en catalog.json");
        g_bulk = false;
        return;
    }
    g_dlIdx = idx;

    char fname[128], dir[256];
    safe_filename(it.file[0] ? it.file : it.name, fname, sizeof(fname));
    snprintf(dir, sizeof(dir), "%s/downloads", plat_data_dir());
    mkdir_p(dir);

    Job *j = job_new(2);
    snprintf(j->finalPath, sizeof(j->finalPath), "%s/%s", dir, fname);
    if (A.mode == M_GITHUB) snprintf(j->url, sizeof(j->url), "%s", it.url);
    else snprintf(j->path, sizeof(j->path), "/download/%s", it.id);
    snprintf(A.dlName, sizeof(A.dlName), "%s", it.name);
    A.dlDone = 0;
    A.dlTotal = it.size;
    if (g_bulk) set_status(C_TEXT, "Descargando %d de %d: %s", g_bulkDone + 1, g_bulkTotal, fname);
    else set_status(C_TEXT, "Descargando %s...", fname);
    job_start(j);
}

static void start_download() {
    if (g_job || A.n == 0) return;
    g_bulk = false;
    start_download_idx(A.sel);
}

static void start_bulk() {
    if (g_job || A.n == 0) return;
    int c = 0;
    for (int i = 0; i < A.n; i++)
        if (A.items[i].flag && A.items[i].url[0]) c++;
    if (!c) { set_status(C_DIM, "No hay nada [NUEVO] ni [ACTUALIZADO]. Pulsa Options para buscar novedades en GitHub."); return; }
    g_bulk = true;
    g_bulkTotal = c;
    g_bulkDone = 0;
    start_download_idx(next_flagged());
}

// Se llama en cada fotograma: pasa el progreso a la pantalla y recoge el resultado.
static void job_poll() {
    Job *j = g_job;
    if (!j) return;
    A.dlDone = j->done.load();
    if (j->total.load() > 0) A.dlTotal = j->total.load();
    if (!j->finished.load()) return;

    if (j->kind == 3) {
        g_updCheck = false;
        if (!j->ok) {
            set_status(C_ERR, "No pude mirar GitHub: %s (falta app_update.json en tu repo?)", j->err);
        } else if (j->n == 0) {
            set_status(C_ERR, "app_update.json no tiene datos.");
        } else {
            const Item &u = j->items[0];
            int a[3] = {0, 0, 0}, b[3] = {0, 0, 0};
            sscanf(APP_VERSION, "%d.%d.%d", &a[0], &a[1], &a[2]);
            sscanf(u.name, "%d.%d.%d", &b[0], &b[1], &b[2]);
            int cmp = 0;
            for (int i = 0; i < 3 && !cmp; i++) cmp = b[i] > a[i] ? 1 : (b[i] < a[i] ? -1 : 0);
            if (cmp > 0 && u.url[0]) {
                g_upd.avail = true;
                snprintf(g_upd.ver, sizeof(g_upd.ver), "%s", u.name);
                resolve_url(j->url, u.url, g_upd.url, sizeof(g_upd.url));
                g_upd.size = u.size;
                set_status(C_OK, "Hay version nueva %s (tienes %s): %s. Pulsa L3 para bajar el PKG.", u.name, APP_VERSION, u.summary);
            } else {
                g_upd.avail = false;
                set_status(C_OK, "McStore %s esta al dia.", APP_VERSION);
            }
        }
    } else if (j->kind == 1) {
        if (j->ok && j->mode == M_GITHUB) {
            if (!A.cat) A.cat = new Item[MAX_ITEMS];
            g_prevN = A.catLoaded ? A.catN : 0;
            if (g_prevN > 0) memcpy(g_prevCat, A.cat, sizeof(Item) * (size_t)g_prevN);
            for (int i = 0; i < j->n; i++) {
                Item &it = j->items[i];
                if (!it.url[0] && it.file[0]) snprintf(it.url, sizeof(it.url), "addons/%s", it.file);
                if (!it.file[0] && it.url[0]) {
                    const char *b = strrchr(it.url, '/');
                    snprintf(it.file, sizeof(it.file), "%s", b ? b + 1 : it.url);
                }
                if (it.url[0]) {
                    char full[420];
                    resolve_url(j->url, it.url, full, sizeof(full));
                    snprintf(it.url, sizeof(it.url), "%s", full);
                }
                A.cat[i] = it;
            }
            int nNew = 0, nUpd = 0;
            bool wasLoaded = A.catLoaded;
            if (!wasLoaded) seen_load();
            // A.cat ya contiene lo nuevo: comparamos contra una copia de lo anterior
            mark_changes(A.cat, j->n, wasLoaded ? g_prevCat : NULL, wasLoaded ? g_prevN : 0, &nNew, &nUpd);
            seen_save(A.cat, j->n);
            A.catN = j->n;
            A.catLoaded = true;
            filter_catalog();
            if (wasLoaded) {
                if (nNew + nUpd == 0) set_status(C_OK, "Catalogo al dia: %d add-on(s), sin novedades.", A.catN);
                else set_status(C_OK, "Catalogo actualizado: %d nuevo(s), %d actualizado(s).", nNew, nUpd);
            } else if (nNew + nUpd > 0) {
                set_status(C_OK, "Desde la ultima vez: %d nuevo(s), %d actualizado(s).", nNew, nUpd);
            }
        } else if (j->ok) {
            memcpy(A.items, j->items, sizeof(Item) * (size_t)j->n);
            A.n = j->n;
            A.sel = A.top = 0;
            if (A.n) set_status(C_OK, "%d resultado(s). Pulsa X para descargar.", A.n);
            else set_status(C_DIM, "No hay resultados para esa busqueda.");
        } else {
            A.n = 0;
            set_status(C_ERR, "Error: %s", j->err);
        }
    } else {
        if (j->ok) {
            if (g_pkgDl) set_status(C_OK, "PKG nuevo en %s: instalalo desde Debug Settings > Package Installer.", j->finalPath);
            else set_status(C_OK, "Guardado en %s", j->finalPath);
            if (g_dlIdx >= 0 && g_dlIdx < A.n) {
                // ya descargado: quita la marca de nuevo/actualizado
                const char *k = item_key(A.items[g_dlIdx]);
                for (int i = 0; A.cat && i < A.catN; i++)
                    if (!strcmp(item_key(A.cat[i]), k)) A.cat[i].flag = 0;
                A.items[g_dlIdx].flag = 0;
            }
            if (g_bulk) g_bulkDone++;
        } else {
            set_status(C_ERR, "Error: %s", j->err);
            g_bulk = false;
        }
    }
    A.busy = false;
    A.dlName[0] = 0;
    g_pkgDl = false;
    g_job = NULL;
    job_release(j);
    if (g_bulk) {
        int nx = next_flagged();
        if (nx >= 0) start_download_idx(nx);
        else {
            g_bulk = false;
            set_status(C_OK, "Listo: %d add-on(s) descargado(s). Pulsa R2 para instalar.", g_bulkDone);
        }
    }
}

// Abandona el trabajo actual. El hilo termina solo (o por timeout) y limpia lo suyo.
static void job_cancel() {
    Job *j = g_job;
    if (!j) return;
    j->cancel = true;
    g_bulk = false;
    g_job = NULL;
    A.busy = false;
    A.dlName[0] = 0;
    set_status(C_DIM, "Cancelado.");
    job_release(j);
}

// ---------- instalacion de packs en Minecraft ----------

struct ScanCtx { PackRow *rows; int n; };
static bool ends_with_ci(const char *s, const char *suf) {
    size_t a = strlen(s), b = strlen(suf);
    if (a < b) return false;
    for (size_t i = 0; i < b; i++) {
        char c = s[a - b + i];
        if (c >= 'A' && c <= 'Z') c = (char)(c + 32);
        if (c != suf[i]) return false;
    }
    return true;
}
static void scan_cb(const char *name, void *ctx) {
    ScanCtx *c = (ScanCtx *)ctx;
    if (c->n >= MAX_PACKS || ends_with_ci(name, ".part")) return;
    PackRow &r = c->rows[c->n];
    memset(&r, 0, sizeof(r));
    snprintf(r.file, sizeof(r.file), "%s", name);
    r.isMcpack = ends_with_ci(name, ".mcpack");
    r.isAddon = ends_with_ci(name, ".mcaddon");
    c->n++;
}

static void install_rescan() {
    if (!I.rows) I.rows = new PackRow[MAX_PACKS];
    char dir[300];
    snprintf(dir, sizeof(dir), "%s/downloads", plat_data_dir());
    ScanCtx c = {I.rows, 0};
    plat_listdir(dir, scan_cb, &c);
    for (int i = 1; i < c.n; i++)  // orden alfabetico (insercion)
        for (int j = i; j > 0 && strcmp(I.rows[j].file, I.rows[j - 1].file) < 0; j--) {
            PackRow t = I.rows[j]; I.rows[j] = I.rows[j - 1]; I.rows[j - 1] = t;
        }
    for (int i = 0; i < c.n; i++) {
        char p[460];
        snprintf(p, sizeof(p), "%s/%s", dir, I.rows[i].file);
        I.rows[i].size = mc_file_size(p);
        if (I.rows[i].isMcpack) mc_pack_inspect(p, &I.rows[i].info);
    }
    I.n = c.n;
    if (I.sel >= I.n) I.sel = I.n ? I.n - 1 : 0;
    if (I.top > I.sel) I.top = I.sel;
}

// Diagnostico: lo que la app realmente ve dentro de /app_tmp (arbol de hasta 4 niveles, recortado).
struct DiagCtx { char *out; size_t cap; int depth; char path[300]; };
static void diag_walk(const char *path, int depth, char *out, size_t cap);
static void diag_cb(const char *name, void *c) {
    DiagCtx *d = (DiagCtx *)c;
    size_t l = strlen(d->out);
    if (l + strlen(name) + 4 >= d->cap) return;
    snprintf(d->out + l, d->cap - l, "%s", name);
    if (d->depth < 4) {
        char sub[300];
        snprintf(sub, sizeof(sub), "%s/%s", d->path, name);
        bool isDir = false; long sz = 0;
        if (plat_stat(sub, &isDir, &sz) && isDir) {
            l = strlen(d->out);
            snprintf(d->out + l, d->cap - l, "/");
            diag_walk(sub, d->depth + 1, d->out, d->cap);
        }
    }
    l = strlen(d->out);
    if (l + 3 < d->cap) snprintf(d->out + l, d->cap - l, " ; ");
}
static void diag_walk(const char *path, int depth, char *out, size_t cap) {
    DiagCtx d; d.out = out; d.cap = cap; d.depth = depth;
    snprintf(d.path, sizeof(d.path), "%s", path);
    if (!plat_listdir(path, diag_cb, &d)) {
        size_t l = strlen(out);
        if (l + 8 < cap) snprintf(out + l, cap - l, "(ilegible)");
    }
}

static void modal_open(int kind, int nlines, ...) {
    I.modal = kind;
    I.nlines = nlines;
    va_list ap;
    va_start(ap, nlines);
    for (int i = 0; i < nlines; i++) snprintf(I.line[i], sizeof(I.line[i]), "%s", va_arg(ap, const char *));
    va_end(ap);
}

static void modal_nogame() {
            static char tree[600];
            tree[0] = 0;
            diag_walk(plat_apptmp_dir(), 1, tree, sizeof(tree));
            char d0[220], d1[220] = "", d2[220] = "", d3[220] = "";
            snprintf(d0, sizeof(d0), "Diagnostico: jailbreak=%d ; juego(id)=%d ; ruta: %s", plat_jb_status(), plat_big_app_id(), plat_apptmp_dir());
            size_t n = strlen(tree);
            if (n == 0) snprintf(d1, sizeof(d1), "%s esta vacia o la app no la ve.", plat_apptmp_dir());
            else {
                snprintf(d1, sizeof(d1), "%.86s", tree);
                if (n > 86) snprintf(d2, sizeof(d2), "%.86s", tree + 86);
                if (n > 172) snprintf(d3, sizeof(d3), "%.86s", tree + 172);
            }
            modal_open(MD_NOGAME, 7, "Minecraft no esta abierto o no veo su carpeta.",
                       "Abrelo hasta el menu, pulsa PS y abre McStore (sin cerrarlo).", "", d0, d1, d2, d3);
}

// Instala de una vez todos los .mcpack de la lista (reemplaza los que ya estan): sirve para "actualizar".
static void install_all() {
    if (I.n == 0) return;
    if (mc_detect(&I.tg) == 0) { modal_nogame(); return; }
    I.modal = MD_NONE;
    I.installing = true;
    render();
    int ok = 0, fail = 0, skip = 0;
    char firstErr[200] = "";
    for (int i = 0; i < I.n; i++) {
        const PackRow &r = I.rows[i];
        if (!r.isMcpack || (r.info.kind != PK_RES && r.info.kind != PK_BEH)) { skip++; continue; }
        char src[460];
        snprintf(src, sizeof(src), "%s/downloads/%s", plat_data_dir(), r.file);
        McInstallResult res;
        mc_install(src, r.file, r.info.kind, &I.tg, &res);
        if (res.ok > 0) ok++;
        else {
            fail++;
            if (!firstErr[0]) snprintf(firstErr, sizeof(firstErr), "%s: %s", r.file, res.err[0] ? res.err : "error desconocido");
        }
    }
    I.installing = false;
    char a[200], b[200];
    snprintf(a, sizeof(a), "Instalados %d pack(s)%s.", ok, skip ? " (se omitieron los que no son .mcpack)" : "");
    if (fail) snprintf(b, sizeof(b), "Fallaron %d. Primero: %s", fail, firstErr);
    else snprintf(b, sizeof(b), "Pulsa TRIANGULO para volver a Minecraft.");
    if (ok > 0) {
        modal_open(MD_DONE, 5, a, "1) Cierra y vuelve a abrir Minecraft para que los packs aparezcan.",
                   "2) Activalos en el mundo (Recursos o Comportamiento).", "Se pierden al cerrar Minecraft o apagar la consola: vuelve a instalar.", b);
        set_status(C_OK, "Instalados %d pack(s)", ok);
    } else {
        modal_open(MD_ERROR, 2, firstErr[0] ? firstErr : "no habia .mcpack validos para instalar", "No se copio nada.");
        set_status(C_ERR, "No se pudo instalar");
    }
}

// Un paso del flujo de instalacion. Cada confirmacion del usuario vuelve a llamar con el salto correspondiente.
static void install_begin(bool skipVersion, bool skipReplace) {
    if (I.n == 0) return;
    const PackRow &r = I.rows[I.sel];
    if (r.isAddon) { set_status(C_DIM, ".mcaddon: soporte pendiente (por ahora solo .mcpack)."); return; }
    if (!r.isMcpack) { set_status(C_DIM, "Formato no soportado: solo .mcpack."); return; }
    if (r.info.kind != PK_RES && r.info.kind != PK_BEH) {
        modal_open(MD_ERROR, 2, r.info.err, "No se copio nada.");
        return;
    }

    // 1) Minecraft abierto? (detecta la ruta cada vez; nada fijo)
    if (mc_detect(&I.tg) == 0) {
        modal_nogame();
        return;
    }

    // 2) El pack pide una version mas nueva que la de la consola?
    I.haveVer = mc_version_load(I.consoleVer);
    if (!skipVersion && I.haveVer && r.info.hasMin && mc_ver_cmp(I.consoleVer, r.info.minEng) < 0) {
        char a[160], b[160];
        snprintf(a, sizeof(a), "Este pack pide Minecraft %d.%d.%d o mas nuevo.", r.info.minEng[0], r.info.minEng[1], r.info.minEng[2]);
        snprintf(b, sizeof(b), "Tu consola tiene %d.%d.%d (mcversion.txt): puede no cargar.", I.consoleVer[0], I.consoleVer[1], I.consoleVer[2]);
        modal_open(MD_VERSION, 2, a, b);
        return;
    }

    // 3) Ya existe?
    if (!skipReplace && mc_already_there(&I.tg, r.info.kind, r.file)) {
        char a[200];
        snprintf(a, sizeof(a), "%s ya esta en %s.", r.file, mc_sub(r.info.kind));
        modal_open(MD_REPLACE, 2, a, "Quieres reemplazarlo?");
        return;
    }

    // 4) Copiar tal cual (.mcpack) a la carpeta que toca segun el manifest
    I.modal = MD_NONE;
    I.installing = true;
    render();  // muestra "Instalando..." antes de empezar a copiar
    char src[460];
    snprintf(src, sizeof(src), "%s/downloads/%s", plat_data_dir(), r.file);
    McInstallResult res;
    mc_install(src, r.file, r.info.kind, &I.tg, &res);
    I.installing = false;

    if (res.ok > 0) {
        char a[200], b[200] = "";
        snprintf(a, sizeof(a), "Copiado en %s de %d carpeta(s) de usuario.", mc_sub(r.info.kind), res.ok);
        if (res.fail) snprintf(b, sizeof(b), "Fallo en %d carpeta(s): %s", res.fail, res.err);
        modal_open(MD_DONE, 5, a, "1) Cierra y vuelve a abrir Minecraft para que el pack aparezca.",
                   "2) Activalo en el mundo (Recursos o Comportamiento).", "Se pierde al cerrar Minecraft o apagar la consola: vuelve a instalar.",
                   b[0] ? b : "Pulsa TRIANGULO para volver a Minecraft.");
        I.resumeOk = true;
        set_status(C_OK, "Instalado: %s", r.file);
    } else {
        modal_open(MD_ERROR, 2, res.err[0] ? res.err : "error desconocido", "No se cambio de metodo: avisame para decidir el siguiente intento.");
        set_status(C_ERR, "No se pudo instalar %s", r.file);
    }
}

// ---------- entrada ----------

static uint32_t g_prev = 0;
static int g_hold[16];

// Devuelve los botones recien pulsados, con repeticion para direcciones y L1/R1.
static uint32_t poll_input() {
    uint32_t cur = plat_buttons();
    uint32_t pressed = cur & ~g_prev;
    const uint32_t repeatable = BTN_UP | BTN_DOWN | BTN_LEFT | BTN_RIGHT | BTN_L1 | BTN_R1;
    for (int i = 0; i < 14; i++) {
        uint32_t bit = 1u << i;
        if (!(cur & bit)) { g_hold[i] = 0; continue; }
        g_hold[i]++;
        if ((repeatable & bit) && g_hold[i] > 24 && (g_hold[i] - 24) % 4 == 0) pressed |= bit;
    }
    g_prev = cur;
    return pressed;
}

static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

static void scroll_to_sel() {
    if (A.sel < A.top) A.top = A.sel;
    if (A.sel >= A.top + LIST_ROWS) A.top = A.sel - LIST_ROWS + 1;
}

static void input_list(uint32_t p) {
    if (p & BTN_DOWN) { A.sel = clampi(A.sel + 1, 0, A.n ? A.n - 1 : 0); scroll_to_sel(); }
    if (p & BTN_UP) { A.sel = clampi(A.sel - 1, 0, A.n ? A.n - 1 : 0); scroll_to_sel(); }
    if (p & BTN_R1) { A.sel = clampi(A.sel + LIST_ROWS, 0, A.n ? A.n - 1 : 0); scroll_to_sel(); }
    if (p & BTN_L1) { A.sel = clampi(A.sel - LIST_ROWS, 0, A.n ? A.n - 1 : 0); scroll_to_sel(); }
    if (p & BTN_CROSS) start_download();
    if (p & BTN_L2) start_bulk();
    if (p & BTN_L3) check_app_update();
    if (p & BTN_OPTIONS) start_search(true);
    if (p & BTN_R2) {
        I.modal = MD_NONE;
        install_rescan();
        I.top = 0;
        set_status(C_DIM, "Elige un pack y pulsa X (Minecraft abierto).");
        A.scr = S_INSTALL;
    }
    if (p & BTN_SQUARE) {
        snprintf(A.kbuf, sizeof(A.kbuf), "%s", A.query);
        A.kr = A.kc = 0;
        A.scr = S_KEYBOARD;
    }
    if (p & BTN_TRIANGLE) {
        A.edit = A.srv;
        A.editMode = A.mode;
        A.field = 0;
        A.scr = S_SETTINGS;
    }
}

static void input_install(uint32_t p) {
    if (I.modal != MD_NONE) {
        if (I.modal == MD_VERSION) {
            if (p & BTN_CROSS) { I.modal = MD_NONE; install_begin(true, false); }
            else if (p & BTN_CIRCLE) { I.modal = MD_NONE; set_status(C_DIM, "Cancelado."); }
        } else if (I.modal == MD_REPLACE) {
            if (p & BTN_CROSS) { I.modal = MD_NONE; install_begin(true, true); }
            else if (p & BTN_CIRCLE) { I.modal = MD_NONE; set_status(C_DIM, "Cancelado."); }
        } else if (I.modal == MD_DONE && (p & BTN_TRIANGLE)) {
            I.modal = MD_NONE;
            char cusa[16] = "";
            const char *t = strstr(I.tg.path[0], "CUSA");
            if (t) { snprintf(cusa, sizeof(cusa), "%.9s", t); }
            if (!cusa[0] || plat_resume_game(cusa) != 0) set_status(C_ERR, "No pude volver a Minecraft: usa el menu de la consola.");
        } else if (p & (BTN_CROSS | BTN_CIRCLE)) {
            I.modal = MD_NONE;
        }
        return;
    }
    if (p & BTN_DOWN) { I.sel = clampi(I.sel + 1, 0, I.n ? I.n - 1 : 0); }
    if (p & BTN_UP) { I.sel = clampi(I.sel - 1, 0, I.n ? I.n - 1 : 0); }
    if (p & BTN_R1) { I.sel = clampi(I.sel + LIST_ROWS, 0, I.n ? I.n - 1 : 0); }
    if (p & BTN_L1) { I.sel = clampi(I.sel - LIST_ROWS, 0, I.n ? I.n - 1 : 0); }
    if (I.sel < I.top) I.top = I.sel;
    if (I.sel >= I.top + LIST_ROWS) I.top = I.sel - LIST_ROWS + 1;
    if (p & BTN_OPTIONS) { install_rescan(); set_status(C_DIM, "Lista actualizada."); }
    if (p & BTN_L2) install_all();
    if (p & BTN_CROSS) install_begin(false, false);
    if (p & BTN_CIRCLE) A.scr = S_LIST;
}

static void input_keyboard(uint32_t p) {
    if (p & BTN_RIGHT) A.kc = (A.kc + 1) % 10;
    if (p & BTN_LEFT) A.kc = (A.kc + 9) % 10;
    if (p & BTN_DOWN) A.kr = (A.kr + 1) % 4;
    if (p & BTN_UP) A.kr = (A.kr + 3) % 4;
    size_t l = strlen(A.kbuf);
    if ((p & BTN_CROSS) && l + 1 < sizeof(A.kbuf)) { A.kbuf[l] = KB_ROWS[A.kr][A.kc]; A.kbuf[l + 1] = 0; }
    if ((p & BTN_TRIANGLE) && l + 1 < sizeof(A.kbuf)) { A.kbuf[l] = ' '; A.kbuf[l + 1] = 0; }
    if ((p & BTN_SQUARE) && l > 0) A.kbuf[l - 1] = 0;
    if (p & BTN_CIRCLE) A.scr = S_LIST;
    if (p & BTN_OPTIONS) {
        snprintf(A.query, sizeof(A.query), "%s", A.kbuf);
        A.scr = S_LIST;
        start_search();
    }
}

static void input_settings(uint32_t p) {
    if (p & BTN_RIGHT) A.field = clampi(A.field + 1, 0, 5);
    if (p & BTN_LEFT) A.field = clampi(A.field - 1, 0, 5);
    if (A.field == 0) {
        if (p & (BTN_UP | BTN_DOWN | BTN_L1 | BTN_R1)) A.editMode = (A.editMode == M_GITHUB) ? M_LAN : M_GITHUB;
    } else {
        int idx = A.field - 1;  // 0..3 = octetos, 4 = puerto
        int step = 0;
        if (p & BTN_UP) step += 1;
        if (p & BTN_DOWN) step -= 1;
        if (p & BTN_R1) step += (idx == 4 ? 100 : 10);
        if (p & BTN_L1) step -= (idx == 4 ? 100 : 10);
        if (step) {
            if (idx < 4) A.edit.ip[idx] = clampi(A.edit.ip[idx] + step, 0, 255);
            else A.edit.port = clampi(A.edit.port + step, 1, 65535);
        }
    }
    if (p & BTN_CIRCLE) A.scr = S_LIST;
    if (p & BTN_CROSS) {
        A.srv = A.edit;
        A.mode = A.editMode;
        config_save();
        A.scr = S_LIST;
        A.catLoaded = false;
        A.n = 0;
        start_search(true);
    }
}

// ---------- main ----------

int main(void) {
    C_BG = RGB(18, 22, 20);
    C_PANEL = RGB(30, 38, 34);
    C_SEL = RGB(44, 84, 56);
    C_TEXT = RGB(235, 240, 235);
    C_DIM = RGB(150, 165, 155);
    C_ACCENT = RGB(96, 200, 96);
    C_OK = RGB(110, 220, 120);
    C_ERR = RGB(240, 100, 90);
    C_BAR = RGB(60, 70, 64);
    (void)C_BAR;

    memset(&A, 0, sizeof(A));
    A.srv.ip[0] = 192; A.srv.ip[1] = 168; A.srv.ip[2] = 1; A.srv.ip[3] = 100;
    A.srv.port = 8080;
    A.mode = M_GITHUB;
    A.statusCol = C_DIM;

    if (!plat_init()) {
        // Sin video no hay nada que mostrar.
        for (;;) plat_sleep_ms(1000);
    }

    mkdir_p(plat_data_dir());
    config_load();
    source_load();
    A.scr = S_LIST;
    start_search();

    for (;;) {
        uint32_t p = poll_input();
        job_poll();
        if (A.busy) {
            if (p & BTN_CIRCLE) job_cancel();
        } else if (A.scr == S_LIST) input_list(p);
        else if (A.scr == S_KEYBOARD) input_keyboard(p);
        else if (A.scr == S_INSTALL) input_install(p);
        else input_settings(p);
        render();
    }
    return 0;
}
