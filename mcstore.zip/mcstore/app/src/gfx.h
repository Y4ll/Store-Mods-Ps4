// Dibujo 2D mínimo sobre el framebuffer: rectángulos y texto con fuente bitmap 8x16.
#pragma once
#include "platform.h"
#include "font.h"
#include <string.h>

static uint32_t *FB = 0;

static inline uint32_t RGB(int r, int g, int b) {
    return 0x80000000u | ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
}

static void gfx_begin() { FB = plat_framebuffer(); }

static void fill(int x, int y, int w, int h, uint32_t c) {
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > SCREEN_W) w = SCREEN_W - x;
    if (y + h > SCREEN_H) h = SCREEN_H - y;
    if (w <= 0 || h <= 0) return;
    for (int yy = y; yy < y + h; yy++) {
        uint32_t *row = FB + (size_t)yy * SCREEN_W + x;
        for (int xx = 0; xx < w; xx++) row[xx] = c;
    }
}

static inline int text_w(const char *s, int scale) { return (int)strlen(s) * 8 * scale; }

// Dibuja texto; si maxChars > 0 recorta con ".." al pasarse.
static void text(int x, int y, const char *s, int scale, uint32_t col, int maxChars = 0) {
    int len = (int)strlen(s);
    bool cut = maxChars > 0 && len > maxChars;
    int n = cut ? maxChars : len;
    for (int i = 0; i < n; i++) {
        unsigned char ch = (unsigned char)s[i];
        if (cut && i >= n - 2) ch = '.';
        if (ch < 32 || ch > 126) ch = '?';
        const unsigned char *g = FONT8X16[ch - 32];
        for (int r = 0; r < 16; r++) {
            unsigned char bits = g[r];
            if (!bits) continue;
            for (int c = 0; c < 8; c++)
                if (bits & (0x80 >> c))
                    fill(x + (i * 8 + c) * scale, y + r * scale, scale, scale, col);
        }
    }
}

// Dibuja una imagen 0x80RRGGBB (sw x sh) escalada a dw x dh (vecino mas cercano).
static void blit(int x, int y, int dw, int dh, const uint32_t *src, int sw, int sh) {
    if (!src || sw <= 0 || sh <= 0 || dw <= 0 || dh <= 0) return;
    for (int yy = 0; yy < dh; yy++) {
        int py = y + yy;
        if (py < 0 || py >= SCREEN_H) continue;
        const uint32_t *srow = src + (size_t)(yy * sh / dh) * sw;
        for (int xx = 0; xx < dw; xx++) {
            int px = x + xx;
            if (px < 0 || px >= SCREEN_W) continue;
            FB[(size_t)py * SCREEN_W + px] = srow[xx * sw / dw];
        }
    }
}
