// Favoritos, descargados y filtrado de la lista
// (Movido tal cual desde main.cpp; se incluye en el mismo punto, asi que el orden no cambia.)
#pragma once

// ---------- favoritos y descargados ----------
#define MAX_FAVS 400
static char g_fav[MAX_FAVS][96];
static int g_favN = 0;
static char g_haveFiles[700][128];
static int g_haveN = 0;
static const char *fkey(const Item &it) { return it.file[0] ? it.file : it.name; }
static void fav_path(char *o, size_t c) { snprintf(o, c, "%s/favs.txt", plat_data_dir()); }
static void fav_load() {
    char p[300], line[160];
    g_favN = 0;
    fav_path(p, sizeof(p));
    FILE *f = fopen(p, "r");
    if (!f) return;
    while (g_favN < MAX_FAVS && fgets(line, sizeof(line), f)) {
        size_t l = strlen(line);
        while (l && (line[l - 1] == '\n' || line[l - 1] == '\r')) line[--l] = 0;
        if (l) snprintf(g_fav[g_favN++], sizeof(g_fav[0]), "%s", line);
    }
    fclose(f);
}
static void fav_save() {
    char p[300];
    fav_path(p, sizeof(p));
    FILE *f = fopen(p, "w");
    if (!f) return;
    for (int i = 0; i < g_favN; i++) fprintf(f, "%s\n", g_fav[i]);
    fclose(f);
}
static bool fav_has(const Item &it) {
    for (int i = 0; i < g_favN; i++) if (!strcmp(g_fav[i], fkey(it))) return true;
    return false;
}
static bool fav_toggle(Item &it) {  // devuelve true si quedo como favorito
    const char *k = fkey(it);
    int at = -1;
    for (int i = 0; i < g_favN; i++) if (!strcmp(g_fav[i], k)) at = i;
    bool now;
    if (at >= 0) { for (int i = at; i < g_favN - 1; i++) memcpy(g_fav[i], g_fav[i + 1], sizeof(g_fav[0])); g_favN--; now = false; }
    else if (g_favN < MAX_FAVS) { snprintf(g_fav[g_favN++], sizeof(g_fav[0]), "%s", k); now = true; }
    else return it.fav != 0;
    for (int i = 0; A.cat && i < A.catN; i++) if (!strcmp(fkey(A.cat[i]), k)) A.cat[i].fav = now;
    for (int i = 0; i < A.n; i++) if (!strcmp(fkey(A.items[i]), k)) A.items[i].fav = now;
    it.fav = now;
    fav_save();
    return now;
}
static void have_cb(const char *name, void *) {
    if (g_haveN < 700) snprintf(g_haveFiles[g_haveN++], sizeof(g_haveFiles[0]), "%s", name);
}
static void have_scan() {
    char dir[300];
    snprintf(dir, sizeof(dir), "%s/downloads", plat_data_dir());
    g_haveN = 0;
    plat_listdir(dir, have_cb, NULL);
}
static bool have_has(const Item &it) {
    char f[128];
    safe_filename(fkey(it), f, sizeof(f));
    for (int i = 0; i < g_haveN; i++) if (!strcmp(g_haveFiles[i], f)) return true;
    return false;
}
static void refresh_have() {  // tras bajar o borrar: actualiza las marcas sin tocar la lista
    have_scan();
    for (int i = 0; A.cat && i < A.catN; i++) A.cat[i].have = have_has(A.cat[i]);
    for (int i = 0; i < A.n; i++) A.items[i].have = have_has(A.items[i]);
}

static int g_idx[MAX_ITEMS];
static int cmp_idx(const void *a, const void *b) {
    int x = *(const int *)a, y = *(const int *)b;
    const Item &p = A.cat[x], &q = A.cat[y];
    int r = 0;
    if (g_sortEff == 1) r = q.dl > p.dl ? 1 : (q.dl < p.dl ? -1 : 0);
    else if (g_sortEff == 2) r = strcmp(q.upd, p.upd);
    else if (g_sortEff == 3) r = strcasecmp(p.name, q.name);
    else if (g_sortEff == 4) r = q.size > p.size ? 1 : (q.size < p.size ? -1 : 0);
    return r ? r : x - y;
}

static void filter_catalog() {
    char q[48];
    snprintf(q, sizeof(q), "%s", A.query);
    lower_in_place(q);
    have_scan();
    int m = 0;
    for (int i = 0; i < A.catN; i++) {
        A.cat[i].have = have_has(A.cat[i]);
        A.cat[i].fav = fav_has(A.cat[i]);
    }
    for (int i = 0; i < A.catN && m < MAX_ITEMS; i++) {
        char hay[320];
        snprintf(hay, sizeof(hay), "%s %s", A.cat[i].name, A.cat[i].summary);
        lower_in_place(hay);
        if ((!q[0] || strstr(hay, q)) && item_passes_filters(A.cat[i])) g_idx[m++] = i;
    }
    g_sortEff = g_fSet == 3 ? 2 : g_fSet == 4 ? 1 : g_fSort;  // Novedades = por fecha, Populares = por descargas
    if (g_sortEff) qsort(g_idx, (size_t)m, sizeof(int), cmp_idx);
    if ((g_fSet == 3 || g_fSet == 4) && m > SECTION_MAX) m = SECTION_MAX;
    A.n = 0;
    for (int i = 0; i < m; i++) A.items[A.n++] = A.cat[g_idx[i]];
    A.sel = A.top = 0;
    if (A.catN == 0) set_status(C_DIM, "El catalogo esta vacio (agrega add-ons a catalog.json en tu repositorio).");
    else if (A.n == 0 && g_fSet == 1) set_status(C_DIM, "Aun no tienes favoritos: pulsa R3 sobre un pack (o Cuadrado en el detalle).");
    else if (A.n == 0 && g_fSet == 2) set_status(C_DIM, "Aun no has descargado nada.");
    else if (A.n == 0 && g_fSet >= 3) set_status(C_DIM, "Sin resultados: cambia los filtros (Circulo).");
    else if (A.n == 0 && g_fVer[0] && g_verN == 0) set_status(C_DIM, "El catalogo aun no trae versiones: ejecuta Build catalog en GitHub y recarga (Options).");
    else if (A.n == 0) set_status(C_DIM, "No hay resultados con esa busqueda y esos filtros (Circulo: filtros).");
    else set_status(C_OK, "%d add-on(s). Pulsa X para descargar.", A.n);
}
