// Filtros: tipo de add-on, version de Minecraft y lista de versiones
// (Movido tal cual desde main.cpp; se incluye en el mismo punto, asi que el orden no cambia.)
#pragma once

static bool has_ci(const char *hay, const char *needle) {
    size_t n = strlen(needle);
    for (; *hay; hay++) if (!strncasecmp(hay, needle, n)) return true;
    return false;
}

// 1 = textura, 2 = addon, 3 = otro (mapa, skin...). Si el catalogo no trae "cls", se adivina por el texto.
static int item_type(const Item &it) {
    if (!strcmp(it.cls, "tex")) return 1;
    if (!strcmp(it.cls, "add")) return 2;
    if (it.cls[0]) return 3;
    if (has_ci(it.name, "texture") || has_ci(it.name, "textura") || has_ci(it.name, "resource pack") ||
        has_ci(it.summary, "texture pack") || has_ci(it.summary, "resource pack") || has_ci(it.summary, "textura")) return 1;
    return 2;
}

// "1.21.50" -> "1.21" (grupo). Devuelve false si no parece una version.
static bool ver_group(const char *v, char *out, size_t cap) {
    int a = 0, b = 0, n = 0;
    if (sscanf(v, "%d.%d%n", &a, &b, &n) < 2) return false;
    snprintf(out, cap, "%d.%d", a, b);
    return true;
}

static bool item_has_ver(const Item &it, const char *grp) {
    char tok[24], g[12];
    const char *p = it.vers[0] ? it.vers : it.ver;
    while (*p) {
        size_t l = strcspn(p, ",");
        if (l > 0 && l < sizeof(tok)) {
            memcpy(tok, p, l);
            tok[l] = 0;
            if (ver_group(tok, g, sizeof(g)) && !strcmp(g, grp)) return true;
        }
        p += l;
        if (*p == ',') p++;
    }
    return false;
}

static bool item_passes_filters(const Item &it) {
    if (g_fType && item_type(it) != g_fType) return false;
    if (g_fVer[0] && !item_has_ver(it, g_fVer)) return false;
    if (g_fSet == 1 && !it.fav) return false;
    if (g_fSet == 2 && !it.have) return false;
    return true;
}

static int ver_key(const char *g) { int a = 0, b = 0; sscanf(g, "%d.%d", &a, &b); return a * 1000 + b; }

// Junta los grupos de version que trae el catalogo (ordenados de mas nuevo a mas viejo).
static void build_ver_list() {
    g_verN = 0;
    for (int i = 0; i < A.catN; i++) {
        const Item &it = A.cat[i];
        const char *p = it.vers[0] ? it.vers : it.ver;
        while (*p) {
            size_t l = strcspn(p, ",");
            char tok[24], g[12];
            if (l > 0 && l < sizeof(tok)) {
                memcpy(tok, p, l);
                tok[l] = 0;
                if (ver_group(tok, g, sizeof(g))) {
                    bool have = false;
                    for (int k = 0; k < g_verN; k++) if (!strcmp(g_verList[k], g)) { have = true; break; }
                    if (!have && g_verN < 40) snprintf(g_verList[g_verN++], 12, "%s", g);
                }
            }
            p += l;
            if (*p == ',') p++;
        }
    }
    for (int i = 1; i < g_verN; i++) {  // orden descendente (insercion)
        char t[12];
        snprintf(t, sizeof(t), "%s", g_verList[i]);
        int j = i - 1;
        while (j >= 0 && ver_key(g_verList[j]) < ver_key(t)) { memcpy(g_verList[j + 1], g_verList[j], 12); j--; }
        snprintf(g_verList[j + 1], 12, "%s", t);
    }
}
