// Instalacion de packs en Minecraft (escaneo, avisos, instalar)
// (Movido tal cual desde main.cpp; se incluye en el mismo punto, asi que el orden no cambia.)
#pragma once

// ---------- instalacion de packs en Minecraft ----------

struct ScanCtx { PackRow *rows; int n; };
static bool ends_with_ci(const char *s, const char *suf) {
    size_t a = strlen(s), b = strlen(suf);
    if (a < b) return false;
    for (size_t i = 0; i < b; i++) {
        char c = s[a - b + i];
        if (c >= 'A' && c <= 'Z') c = (char)(c + 32);
        if (c != suf[i]) return false;
    }
    return true;
}
static void scan_cb(const char *name, void *ctx) {
    ScanCtx *c = (ScanCtx *)ctx;
    if (c->n >= MAX_PACKS || ends_with_ci(name, ".part")) return;
    PackRow &r = c->rows[c->n];
    memset(&r, 0, sizeof(r));
    snprintf(r.file, sizeof(r.file), "%s", name);
    r.isMcpack = ends_with_ci(name, ".mcpack");
    r.isAddon = ends_with_ci(name, ".mcaddon");
    c->n++;
}

static void install_rescan() {
    if (!I.rows) I.rows = new PackRow[MAX_PACKS];
    char dir[300];
    snprintf(dir, sizeof(dir), "%s/downloads", plat_data_dir());
    ScanCtx c = {I.rows, 0};
    plat_listdir(dir, scan_cb, &c);
    for (int i = 1; i < c.n; i++)  // orden alfabetico (insercion)
        for (int j = i; j > 0 && strcmp(I.rows[j].file, I.rows[j - 1].file) < 0; j--) {
            PackRow t = I.rows[j]; I.rows[j] = I.rows[j - 1]; I.rows[j - 1] = t;
        }
    for (int i = 0; i < c.n; i++) {
        char p[460];
        snprintf(p, sizeof(p), "%s/%s", dir, I.rows[i].file);
        I.rows[i].size = mc_file_size(p);
        if (I.rows[i].isMcpack) mc_pack_inspect(p, &I.rows[i].info);
    }
    I.n = c.n;
    if (I.sel >= I.n) I.sel = I.n ? I.n - 1 : 0;
    if (I.top > I.sel) I.top = I.sel;
}

// Diagnostico: lo que la app realmente ve dentro de /app_tmp (arbol de hasta 4 niveles, recortado).
struct DiagCtx { char *out; size_t cap; int depth; char path[300]; };
static void diag_walk(const char *path, int depth, char *out, size_t cap);
static void diag_cb(const char *name, void *c) {
    DiagCtx *d = (DiagCtx *)c;
    size_t l = strlen(d->out);
    if (l + strlen(name) + 4 >= d->cap) return;
    snprintf(d->out + l, d->cap - l, "%s", name);
    if (d->depth < 4) {
        char sub[300];
        snprintf(sub, sizeof(sub), "%s/%s", d->path, name);
        bool isDir = false; long sz = 0;
        if (plat_stat(sub, &isDir, &sz) && isDir) {
            l = strlen(d->out);
            snprintf(d->out + l, d->cap - l, "/");
            diag_walk(sub, d->depth + 1, d->out, d->cap);
        }
    }
    l = strlen(d->out);
    if (l + 3 < d->cap) snprintf(d->out + l, d->cap - l, " ; ");
}
static void diag_walk(const char *path, int depth, char *out, size_t cap) {
    DiagCtx d; d.out = out; d.cap = cap; d.depth = depth;
    snprintf(d.path, sizeof(d.path), "%s", path);
    if (!plat_listdir(path, diag_cb, &d)) {
        size_t l = strlen(out);
        if (l + 8 < cap) snprintf(out + l, cap - l, "(ilegible)");
    }
}

static void modal_open(int kind, int nlines, ...) {
    I.modal = kind;
    I.nlines = nlines;
    va_list ap;
    va_start(ap, nlines);
    for (int i = 0; i < nlines; i++) snprintf(I.line[i], sizeof(I.line[i]), "%s", va_arg(ap, const char *));
    va_end(ap);
}

static void modal_nogame() {
            static char tree[600];
            tree[0] = 0;
            diag_walk(plat_apptmp_dir(), 1, tree, sizeof(tree));
            char d0[220], d1[220] = "", d2[220] = "", d3[220] = "";
            snprintf(d0, sizeof(d0), "Diagnostico: jailbreak=%d ; juego(id)=%d ; ruta: %s", plat_jb_status(), plat_big_app_id(), plat_apptmp_dir());
            size_t n = strlen(tree);
            if (n == 0) snprintf(d1, sizeof(d1), "%s esta vacia o la app no la ve.", plat_apptmp_dir());
            else {
                snprintf(d1, sizeof(d1), "%.86s", tree);
                if (n > 86) snprintf(d2, sizeof(d2), "%.86s", tree + 86);
                if (n > 172) snprintf(d3, sizeof(d3), "%.86s", tree + 172);
            }
            modal_open(MD_NOGAME, 7, "Minecraft no esta abierto o no veo su carpeta.",
                       "Abrelo hasta el menu, pulsa PS y abre McStore (sin cerrarlo).", "", d0, d1, d2, d3);
}

// Instala de una vez todos los .mcpack de la lista (reemplaza los que ya estan): sirve para "actualizar".
static void install_all() {
    if (I.n == 0) return;
    if (mc_detect(&I.tg) == 0) { modal_nogame(); return; }
    I.modal = MD_NONE;
    I.installing = true;
    render();
    int ok = 0, fail = 0, skip = 0;
    char firstErr[200] = "";
    for (int i = 0; i < I.n; i++) {
        const PackRow &r = I.rows[i];
        if (!r.isMcpack || (r.info.kind != PK_RES && r.info.kind != PK_BEH)) { skip++; continue; }
        char src[460];
        snprintf(src, sizeof(src), "%s/downloads/%s", plat_data_dir(), r.file);
        McInstallResult res;
        mc_install(src, r.file, r.info.kind, &I.tg, &res);
        if (res.ok > 0) ok++;
        else {
            fail++;
            if (!firstErr[0]) snprintf(firstErr, sizeof(firstErr), "%s: %s", r.file, res.err[0] ? res.err : "error desconocido");
        }
    }
    I.installing = false;
    char a[200], b[200];
    snprintf(a, sizeof(a), "Instalados %d pack(s)%s.", ok, skip ? " (se omitieron los que no son .mcpack)" : "");
    if (fail) snprintf(b, sizeof(b), "Fallaron %d. Primero: %s", fail, firstErr);
    else snprintf(b, sizeof(b), "Pulsa TRIANGULO para volver a Minecraft.");
    if (ok > 0) {
        modal_open(MD_DONE, 5, a, "1) Cierra y vuelve a abrir Minecraft para que los packs aparezcan.",
                   "2) Activalos en el mundo (Recursos o Comportamiento).", "Se pierden al cerrar Minecraft o apagar la consola: vuelve a instalar.", b);
        set_status(C_OK, "Instalados %d pack(s)", ok); sfx(SFX_DONE);
    } else {
        modal_open(MD_ERROR, 2, firstErr[0] ? firstErr : "no habia .mcpack validos para instalar", "No se copio nada.");
        set_status(C_ERR, "No se pudo instalar");
    }
}

// Un paso del flujo de instalacion. Cada confirmacion del usuario vuelve a llamar con el salto correspondiente.
static void install_begin(bool skipVersion, bool skipReplace) {
    if (I.n == 0) return;
    const PackRow &r = I.rows[I.sel];
    if (r.isAddon) { set_status(C_DIM, ".mcaddon: soporte pendiente (por ahora solo .mcpack)."); return; }
    if (!r.isMcpack) { set_status(C_DIM, "Formato no soportado: solo .mcpack."); return; }
    if (r.info.kind != PK_RES && r.info.kind != PK_BEH) {
        modal_open(MD_ERROR, 2, r.info.err, "No se copio nada.");
        return;
    }

    // 1) Minecraft abierto? (detecta la ruta cada vez; nada fijo)
    if (mc_detect(&I.tg) == 0) {
        modal_nogame();
        return;
    }

    // 2) El pack pide una version mas nueva que la de la consola?
    I.haveVer = mc_version_load(I.consoleVer);
    if (!skipVersion && I.haveVer && r.info.hasMin && mc_ver_cmp(I.consoleVer, r.info.minEng) < 0) {
        char a[160], b[160];
        snprintf(a, sizeof(a), "Este pack pide Minecraft %d.%d.%d o mas nuevo.", r.info.minEng[0], r.info.minEng[1], r.info.minEng[2]);
        snprintf(b, sizeof(b), "Tu consola tiene %d.%d.%d (mcversion.txt): puede no cargar.", I.consoleVer[0], I.consoleVer[1], I.consoleVer[2]);
        modal_open(MD_VERSION, 2, a, b);
        return;
    }

    // 3) Ya existe?
    if (!skipReplace && mc_already_there(&I.tg, r.info.kind, r.file)) {
        char a[200];
        snprintf(a, sizeof(a), "%s ya esta en %s.", r.file, mc_sub(r.info.kind));
        modal_open(MD_REPLACE, 2, a, "Quieres reemplazarlo?");
        return;
    }

    // 4) Copiar tal cual (.mcpack) a la carpeta que toca segun el manifest
    I.modal = MD_NONE;
    I.installing = true;
    render();  // muestra "Instalando..." antes de empezar a copiar
    char src[460];
    snprintf(src, sizeof(src), "%s/downloads/%s", plat_data_dir(), r.file);
    McInstallResult res;
    mc_install(src, r.file, r.info.kind, &I.tg, &res);
    I.installing = false;

    if (res.ok > 0) {
        char a[200], b[200] = "";
        snprintf(a, sizeof(a), "Copiado en %s de %d carpeta(s) de usuario.", mc_sub(r.info.kind), res.ok);
        if (res.fail) snprintf(b, sizeof(b), "Fallo en %d carpeta(s): %s", res.fail, res.err);
        modal_open(MD_DONE, 5, a, "1) Cierra y vuelve a abrir Minecraft para que el pack aparezca.",
                   "2) Activalo en el mundo (Recursos o Comportamiento).", "Se pierde al cerrar Minecraft o apagar la consola: vuelve a instalar.",
                   b[0] ? b : "Pulsa TRIANGULO para volver a Minecraft.");
        I.resumeOk = true;
        set_status(C_OK, "Instalado: %s", r.file); sfx(SFX_DONE);
    } else {
        modal_open(MD_ERROR, 2, res.err[0] ? res.err : "error desconocido", "No se cambio de metodo: avisame para decidir el siguiente intento.");
        set_status(C_ERR, "No se pudo instalar %s", r.file);
    }
}
