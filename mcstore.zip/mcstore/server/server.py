#!/usr/bin/env python3
"""Servidor para McStore (app PS4). Solo usa la biblioteca estándar de Python 3.8+.

Endpoints:
  GET /search?q=texto   -> JSON [{id, name, summary, file, size}]
  GET /download/<id>    -> el archivo (.mcpack/.mcaddon/.mcworld/.mctemplate)

Fuentes de contenido (todas opcionales y combinables):
  1. Carpeta files/   -> suelta ahí tus .mcpack/.mcaddon/.mcworld y aparecen solos.
  2. catalog.json     -> lista con enlaces directos (ver catalog.example.json).
  3. CurseForge       -> export CF_API_KEY=tu_clave (gratis en https://console.curseforge.com).
                         Opcional: CF_GAME_ID (por defecto 78022, Minecraft Bedrock).

Uso:  python3 server.py [puerto]      (por defecto 8080)
"""
import json
import os
import sys
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
FILES_DIR = os.environ.get("MCSTORE_FILES", os.path.join(HERE, "files"))
CATALOG = os.environ.get("MCSTORE_CATALOG", os.path.join(HERE, "catalog.json"))
CF_KEY = os.environ.get("CF_API_KEY", "")
CF_GAME_ID = int(os.environ.get("CF_GAME_ID", "78022"))
EXTS = (".mcpack", ".mcaddon", ".mcworld", ".mctemplate", ".zip")

# id -> ("file", ruta_local) | ("url", enlace)
DOWNLOADS = {}


def _entry(mid, name, summary, fname, size):
    return {"id": mid, "name": name, "summary": summary, "file": fname, "size": size}


def search_files(q):
    out = []
    if not os.path.isdir(FILES_DIR):
        return out
    for i, fname in enumerate(sorted(os.listdir(FILES_DIR))):
        path = os.path.join(FILES_DIR, fname)
        if not fname.lower().endswith(EXTS) or not os.path.isfile(path):
            continue
        name = os.path.splitext(fname)[0]
        if q and q not in name.lower():
            continue
        mid = "F%d" % i
        DOWNLOADS[mid] = ("file", path)
        out.append(_entry(mid, name, "Archivo local de la carpeta files/",
                          fname, os.path.getsize(path)))
    return out


def search_catalog(q):
    path = CATALOG
    if not os.path.exists(path):
        return []
    try:
        with open(path, encoding="utf-8") as f:
            catalog = json.load(f)
    except (OSError, ValueError) as e:
        print("catalog.json invalido:", e)
        return []
    out = []
    for i, m in enumerate(catalog):
        if not isinstance(m, dict) or not m.get("url"):
            continue
        text = (m.get("name", "") + " " + m.get("summary", "")).lower()
        if q and q not in text:
            continue
        mid = "L%d" % i
        DOWNLOADS[mid] = ("url", m["url"])
        fname = m.get("file") or os.path.basename(urllib.parse.urlparse(m["url"]).path) or "descarga.mcpack"
        out.append(_entry(mid, m.get("name", fname), m.get("summary", ""), fname, m.get("size", 0)))
    return out


def search_curseforge(q):
    if not CF_KEY or not q:
        return []
    params = urllib.parse.urlencode({"gameId": CF_GAME_ID, "searchFilter": q, "pageSize": 20})
    req = urllib.request.Request(
        "https://api.curseforge.com/v1/mods/search?" + params,
        headers={"x-api-key": CF_KEY, "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            data = json.load(r)["data"]
    except Exception as e:  # red, clave inválida, etc.
        print("CurseForge error:", e)
        return []
    out = []
    for m in data:
        files = m.get("latestFiles") or []
        if not files or not files[0].get("downloadUrl"):
            continue  # el autor no permite descargas fuera de CurseForge
        f = files[0]
        mid = "C%d" % m["id"]
        DOWNLOADS[mid] = ("url", f["downloadUrl"])
        out.append(_entry(mid, m["name"], m.get("summary", ""), f["fileName"], f.get("fileLength", 0)))
    return out


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"  # sin chunked: más fácil para la PS4

    def _json(self, obj):
        body = json.dumps(obj, ensure_ascii=True).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _stream(self, src, size):
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        if size is not None:
            self.send_header("Content-Length", str(size))
        self.end_headers()
        while True:
            chunk = src.read(65536)
            if not chunk:
                break
            self.wfile.write(chunk)

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        if u.path == "/search":
            q = urllib.parse.parse_qs(u.query).get("q", [""])[0].strip().lower()
            return self._json(search_files(q) + search_catalog(q) + search_curseforge(q))
        if u.path.startswith("/download/"):
            kind_val = DOWNLOADS.get(u.path.rsplit("/", 1)[1])
            if not kind_val:
                return self.send_error(404, "id desconocido (busca primero)")
            kind, val = kind_val
            try:
                if kind == "file":
                    with open(val, "rb") as f:
                        return self._stream(f, os.path.getsize(val))
                with urllib.request.urlopen(val, timeout=30) as r:
                    size = r.headers.get("Content-Length")
                    return self._stream(r, int(size) if size else None)
            except Exception as e:
                print("descarga fallida:", e)
                return self.send_error(502, "no se pudo obtener el archivo")
        self.send_error(404)

    def log_message(self, fmt, *args):
        print("%s %s" % (self.client_address[0], fmt % args))


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
    os.makedirs(FILES_DIR, exist_ok=True)
    print("McStore server en el puerto %d | files/: %s | CurseForge: %s"
          % (port, FILES_DIR, "ON" if CF_KEY else "OFF"))
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
